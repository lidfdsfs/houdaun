# 注册验证地址修复（2026-11-19）

## 问题
线上 `/auth/register_link` 返回的 `verify_url` 是：

```text
https://127.0.0.1:7070/auth/verify/...
```

这是后端收到平台转发后拿到的内部地址，手机浏览器打不开，注册流程会在这里断掉。

## 修什么
新增 `PUBLIC_BASE_URL` 配置，优先级：

1. `PUBLIC_BASE_URL`（推荐，反代/端口映射必填）
2. `TRUST_PROXY_HEADERS=true` 时读取 `X-Forwarded-Proto` / `X-Forwarded-Host`
3. 最后才用 `request.base_url`

## 部署步骤

```bash
cd /data/home/myzuji/backend

# 1. 备份
cp .env .env.bak-20261119
cp app/config.py app/config.py.bak-20261119
cp app/routers/auth.py app/routers/auth.py.bak-20261119

# 2. 写入对外地址（已存在则替换，不存在则追加）
if grep -q '^PUBLIC_BASE_URL=' .env; then
  sed -i 's|^PUBLIC_BASE_URL=.*|PUBLIC_BASE_URL=https://7070-agq447ltbeo743hfuzt3otltqy.instabox.tech|' .env
else
  printf '\nPUBLIC_BASE_URL=https://7070-agq447ltbeo743hfuzt3otltqy.instabox.tech\n' >> .env
fi

# 3. 覆盖两个文件（从热修复包解压后执行）
cp /path/to/hotfix/backend/app/config.py app/config.py
cp /path/to/hotfix/backend/app/routers/auth.py app/routers/auth.py

# 4. 重启当前 nohup 进程（PID 以实际为准）
pkill -f "uvicorn app.main:app" || true
nohup .venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 7070 --workers 1 --proxy-headers \
  >> logs/uvicorn.out.log 2>&1 &

# 5. 健康检查
curl -fsS http://127.0.0.1:7070/healthz
```

## 验收
在 App 里点“没有账号？去注册”，拿到验证地址后确认它以
`https://7070-agq447ltbeo743hfuzt3otltqy.instabox.tech/auth/verify/` 开头，
不再是 `127.0.0.1`。

或者用服务器本地请求检查（需要先过图形验证码）：

```bash
# 返回 JSON 里的 verify_url 必须是公网 https 地址
curl -sS -X POST http://127.0.0.1:7070/auth/register_link \
  -H 'Content-Type: application/json' \
  -d '{"username":"qa_check_02","captcha_id":"...","captcha_text":"..."}'
```

## 注意
- `PUBLIC_BASE_URL` 末尾不要带 `/`。
- 如果以后换域名，只改 `.env` 这一行并重启，不用改代码。
- 该修复不涉及数据库结构，不需要迁移数据。
