"""运行时配置。

所有配置项都来自环境变量或 backend/.env，不硬编码任何口令/密钥进仓库。
启动时会做一次安全检查：生产环境（ENV=prod）若仍在用占位密钥，直接拒绝启动，
避免「照抄 .env.example 上线」这种事发生。
"""
from __future__ import annotations

import os
import secrets
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

# .env.example 里的占位值，出现在生产环境一律视为未配置
_PLACEHOLDER_SECRETS = {
    "change-me",
    "change-me-please",
    "changeme",
    "please-change-this-secret-key",
    "your-secret-key",
}


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # ---------- 基础 ----------
    app_name: str = "MY足迹后端API"
    app_version: str = "3.2.0"
    env: str = "dev"  # dev | prod
    host: str = "0.0.0.0"
    port: int = 8000
    log_level: str = "info"

    # ---------- 存储 ----------
    database_path: str = str(BASE_DIR / "data" / "app.db")
    storage_dir: str = str(BASE_DIR / "storage")
    backup_dir: str = str(BASE_DIR / "backups")

    # ---------- 安全 ----------
    # JWT 签名密钥；留空时自动生成并持久化到 data/.secret_key（仅限单机部署）
    secret_key: str = ""
    jwt_algorithm: str = "HS256"
    token_ttl_days: int = 30
    admin_token_ttl_hours: int = 12

    # 管理员账号（仅用于 /admin 后台，与 App 用户是两套体系）
    admin_username: str = "admin"
    admin_password: str = ""
    admin_name: str = "管理员"

    # 登录连续失败多少次后强制图形验证码 / 多少次后临时锁定
    login_captcha_after: int = 3
    login_lock_after: int = 8
    login_lock_minutes: int = 15

    # 图形验证码有效期（秒）与字符长度
    captcha_ttl_seconds: int = 300
    captcha_length: int = 4

    # ---------- 上传 ----------
    max_image_bytes: int = 20 * 1024 * 1024       # 20MB
    max_video_bytes: int = 500 * 1024 * 1024     # 500MB
    max_avatar_bytes: int = 5 * 1024 * 1024      # 5MB
    user_quota_bytes: int = 2 * 1024 * 1024 * 1024  # 每人 2GB
    # 允许的图片/视频 MIME（按文件头嗅探，不信客户端 Content-Type）
    allowed_image_mimes: str = "image/jpeg,image/png,image/webp,image/gif,image/heic,image/heif"
    allowed_video_mimes: str = "video/mp4,video/quicktime,video/3gpp,video/webm,video/x-msvideo"

    # ---------- 跨域 / 反向代理 ----------
    # 逗号分隔；App 是原生客户端不校验 CORS，这里主要给 Web 调试用
    cors_origins: str = "*"
    trust_proxy_headers: bool = False
    # 对外访问根地址（如 https://example.com）。注册验证地址必须用它，
    # 否则在反代/端口映射后可能生成 http://127.0.0.1:7070/... 这种设备打不开的链接。
    public_base_url: str = ""

    # ---------- 服务端网页索引（可选） ----------
    # 配置成自建 SearXNG 的 /search?format=json 地址后，/api/search 才会返回真实结果；
    # 未配置时返回空列表，App 会自动回退本机检索。
    search_endpoint: str = ""
    search_timeout_seconds: int = 8

    # ---------- 联网搜索（临时会话） ----------
    # auto = 配了 SEARCH_ENDPOINT 就先走 SearXNG，失败/未配置则用 Bing HTML
    search_provider: str = "auto"          # auto | searxng | bing
    search_online_enabled: bool = True
    search_session_ttl_seconds: int = 600  # 搜索结果保留 10 分钟，到期自动删除
    search_cleanup_seconds: int = 60       # 清理线程间隔
    search_excerpt_chars: int = 800        # 每篇正文摘要截断长度
    search_rate_per_minute: int = 8        # 每人每分钟最多发起几次联网搜索

    # ---------- 网页抓取与清洗 ----------
    content_enabled: bool = True              # 后台抓取 worker 总开关
    content_worker_seconds: int = 5           # 队列轮询间隔（秒）
    content_fetch_timeout: int = 12           # 单次请求超时（秒）
    content_max_bytes: int = 3 * 1024 * 1024  # 单个页面最大下载
    content_max_items_per_run: int = 12       # 单个内容源每轮最多抓多少条
    content_min_chars: int = 200              # 正文少于该长度视为模板页/失败
    content_user_agent: str = "MYZujiBot/1.0 (content-fetcher; +https://github.com/lidfdsfs/myzuji-backend)"
    # 是否允许抓内网 / 回环地址。**生产必须 false**（防 SSRF），开发环境会自动放开
    content_allow_private: bool = False

    # ---------- 站内私信 ----------
    message_max_length: int = 2000            # 单条文本上限
    message_recall_seconds: int = 120         # 发送后多久内可撤回
    message_rate_per_minute: int = 60         # 每人每分钟发消息上限
    message_page_size: int = 30               # 默认拉取条数

    # ---------- 初始数据 ----------
    seed_test_account: bool = True
    test_account_username: str = "user1"
    test_account_password: str = "123456"
    test_account_nickname: str = "联调测试"

    # ---------- 限流 ----------
    rate_limit_per_minute: int = 120      # 普通接口每 IP
    auth_rate_limit_per_minute: int = 20  # 认证接口每 IP

    # ---------- 派生属性 ----------
    @property
    def is_prod(self) -> bool:
        return self.env.lower() in {"prod", "production"}

    @property
    def image_mimes(self) -> set[str]:
        return {m.strip().lower() for m in self.allowed_image_mimes.split(",") if m.strip()}

    @property
    def video_mimes(self) -> set[str]:
        return {m.strip().lower() for m in self.allowed_video_mimes.split(",") if m.strip()}

    @property
    def cors_origin_list(self) -> list[str]:
        raw = self.cors_origins.strip()
        if not raw or raw == "*":
            return ["*"]
        return [o.strip() for o in raw.split(",") if o.strip()]

    @property
    def db_file(self) -> Path:
        return Path(self.database_path).expanduser().resolve()

    @property
    def content_private_allowed(self) -> bool:
        """生产环境一律禁止抓内网；开发环境需显式 CONTENT_ALLOW_PRIVATE=true 才放开。"""
        return bool(self.content_allow_private) and not self.is_prod

    @property
    def storage_path(self) -> Path:
        return Path(self.storage_dir).expanduser().resolve()

    @property
    def backup_path(self) -> Path:
        return Path(self.backup_dir).expanduser().resolve()

    @property
    def media_path(self) -> Path:
        return self.storage_path / "media"

    @property
    def avatar_path(self) -> Path:
        return self.storage_path / "avatars"

    @property
    def guide_cover_path(self) -> Path:
        return self.storage_path / "covers"

    def prepare_dirs(self) -> None:
        for p in (
            self.db_file.parent,
            self.storage_path,
            self.media_path,
            self.avatar_path,
            self.guide_cover_path,
            self.backup_path,
        ):
            p.mkdir(parents=True, exist_ok=True)

    def ensure_secret_key(self) -> str:
        """返回可用的 JWT 密钥。

        - 显式配置了 SECRET_KEY：直接用；
        - 没配置：生成一次并写入 data/.secret_key（0600），重启后 token 依然有效。
        生产环境未配置密钥会打警告，要求运维自己配。
        """
        configured = (self.secret_key or "").strip()
        if configured and configured.lower() not in _PLACEHOLDER_SECRETS and len(configured) >= 16:
            return configured
        if self.is_prod and configured:
            raise RuntimeError(
                "SECRET_KEY 仍是占位值。请在 .env 里填入 `python -c \"import secrets;print(secrets.token_urlsafe(48))\"` 生成的值。"
            )
        key_file = self.db_file.parent / ".secret_key"
        if key_file.exists():
            saved = key_file.read_text(encoding="utf-8").strip()
            if len(saved) >= 32:
                return saved
        generated = secrets.token_urlsafe(48)
        key_file.write_text(generated, encoding="utf-8")
        try:
            os.chmod(key_file, 0o600)
        except OSError:
            pass
        return generated

    def require_admin_password(self) -> str:
        pwd = (self.admin_password or "").strip()
        if pwd and pwd.lower() not in _PLACEHOLDER_SECRETS and len(pwd) >= 8:
            return pwd
        if self.is_prod:
            raise RuntimeError(
                "ADMIN_PASSWORD 未设置或过短（至少 8 位）。后台口令绝不能是默认值。"
            )
        # 开发环境给一个可预期的口令，方便本地打开 /admin
        return "admin-dev-2026"


@lru_cache(maxsize=1)
def get_jwt_secret() -> str:
    """JWT 签名密钥：进程内只解析一次。"""
    return settings.ensure_secret_key()


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    s = Settings()
    s.prepare_dirs()
    return s


settings = get_settings()
