# 微足迹独立后端服务（myzuji-microfeed）

MY足迹 App 里「微足迹」（抖音式公开足迹流）的**独立后端**。与原有功能后端（`backend/`，端口 7070）**完全分开**：

| | 原功能后端 | 本服务 |
|---|---|---|
| 目录 | `backend/`（Python / FastAPI） | `microfeed-backend/`（Node.js 24） |
| 端口 | 7070 | **7080** |
| 数据库 | `backend/data/*.db` | **`microfeed-backend/data/microfeed.db`** |
| 存储 | `backend/storage/` | **`microfeed-backend/storage/`** |
| 职责 | 账号、攻略、评论、足迹同步、私信 | 公开足迹流、互动、关注、搜索、媒体 |
| 依赖 | pip 一堆包 | **零第三方依赖** |

唯一共享的是 JWT 密钥：主后端签发用户 JWT，本服务只做验签，用户**不需要登录两次**，本服务也**不读主后端的用户表**。
两边密钥不必相等——把主后端的 key 追加到 `MF_SECRET_KEY_EXTRA` 即可（支持多把并列，便于对齐与轮换）。

---

## 1. 能力清单（每条都有自动化断言覆盖）

| 能力 | 接口 |
|---|---|
| 四条信息流（关注/推荐/同城/我的） | `GET /v1/feed?tab=&city=&tag=&q=&limit=&cursor=` |
| 同城候选城市 | `GET /v1/feed/cities` |
| 发布 | `POST /v1/posts` |
| 撤回（软删除） | `DELETE /v1/posts/{id}` |
| 单条详情（公开可读） | `GET /v1/posts/{id}` |
| 点赞 / 收藏 / 分享 / 不感兴趣 / 浏览 / 举报 | `POST /v1/posts/{id}/{like,favorite,share,hide,view,report}` |
| 评论列表 / 发表 / 删除 / 点赞 | `GET|POST /v1/posts/{id}/comments`、`DELETE /v1/comments/{id}`、`POST /v1/comments/{id}/like` |
| 关注 / 取关（互关可推导） | `POST /v1/users/{uid}/follow` |
| 作者主页 / 作品 / 粉丝 / 关注列表 | `GET /v1/users/{uid}`、`/posts`、`/followers`、`/following` |
| 我的资料与统计 | `GET|PUT /v1/me`、`GET /v1/me/stats`、`GET /v1/me/posts`、`GET /v1/me/favorites` |
| 搜索（帖子/用户/话题） | `GET /v1/search?q=` |
| 热门话题 | `GET /v1/tags/trending` |
| 媒体上传（原始二进制） | `POST /v1/media`（`Content-Type` 即文件类型） |
| 媒体读取（支持 Range） | `GET /media/{uid}/{yyyyMM}/{file}` |
| 监控 | `GET /healthz`、`GET /ping`、`GET /v1/meta` |

**计数口径**：`baseLikes` = 帖子基数 + 真实点赞数；`baseComments` = 未删除评论数；`baseShares` = 基数 + 真实分享数。
**幂等**：点赞/收藏/关注都是 toggle，重复请求不会把计数刷大；浏览与分享同一用户对同一帖只记一次。
**分页**：`cursor` 就是下一页 offset（返回在 `nextCursor`，最后一页为 `null`）。

---

## 2. 快速启动

### 方式 A：本机直接跑（最快）

```bash
cd microfeed-backend
cp .env.example .env          # Windows: copy .env.example .env
# 编辑 .env：MF_SECRET_KEY 填成主后端的 SECRET_KEY
npm run dev                   # 开发模式：跳过 JWT 校验，任何请求 = 演示用户 1001
# 生产：npm start
```

打开 <http://127.0.0.1:7080/v1/meta> 应返回 JSON。首次启动会自动灌入 **8 位作者 / 9 条带照片的演示足迹**，四个 feed 直接有内容。

> 要求 Node ≥ 22.5（内置 `node:sqlite`），推荐 Node 24 LTS。`npm start` 已带 `--no-warnings` 压掉 SQLite 的实验性告警。

### 方式 B：Docker Compose（推荐上线）

```bash
cd microfeed-backend
cp .env.example .env          # 填 MF_SECRET_KEY
docker compose up -d --build
docker compose logs -f microfeed
```

数据落在 `./data`（SQLite）与 `./storage`（媒体），重建容器不丢。

### 方式 C：systemd（裸机）

```bash
sudo cp -r microfeed-backend /opt/myzuji-microfeed
cd /opt/myzuji-microfeed && cp .env.example .env && vi .env
sudo cp deploy/myzuji-microfeed.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now myzuji-microfeed
journalctl -u myzuji-microfeed -f
```

### 方式 D：Windows 双击

`start.bat` 会检查 Node 版本、自动生成 `.env`、创建目录后启动。

---

## 3. 配置项

所有配置走环境变量（`.env` 同款），关键几项：

| 变量 | 默认 | 说明 |
|---|---|---|
| `MF_PORT` | `7080` | 监听端口 |
| `MF_AUTH_MODE` | `shared` | `shared` 校验主后端 JWT；`dev` 不校验（仅调试） |
| `MF_SECRET_KEY` | 空 | **必须与主后端一致**；为空时自动生成 `data/.secret_key`（会导致用户 token 验签失败） |
| `MF_SECRET_KEY_EXTRA` | 空 | 追加验签密钥，逗号/分号/空白分隔多把；主后端 key 可直接写这里，不动 `MF_SECRET_KEY` |
| `MF_JWT_ISSUER` | `myzuji-backend` | 与主后端 `create_token` 里的 `iss` 一致 |
| `MF_DATA_DIR` / `MF_STORAGE_DIR` | `./data` `./storage` | 数据库与媒体目录 |
| `MF_SEED_ON_START` | `1` | 库为空时灌演示数据 |
| `MF_MAX_VIDEO_BYTES` | 300MB | 视频上限；Nginx `client_max_body_size` 要 ≥ 这个值 |
| `MF_ADMIN_UIDS` | 空 | 可代删他人内容的管理员用户 id |
| `MF_CORS_ORIGINS` | `*` | 原生 App 不需要；网页/小程序调用时收紧 |

### 鉴权怎么对齐

主后端的 JWT 是 `HS256`，`iss=myzuji-backend`，`sub=<用户id>`，`typ=user`。本服务只验 `exp/iat/sub/iss/typ` 与签名。因此：

1. 两边密钥必须对得上。**不必改主后端**：把主后端的 `SECRET_KEY` 追加到本服务的 `MF_SECRET_KEY_EXTRA` 即可，
   重启后新旧 token 都有效，用户不用重新登录；
2. App 登录后拿到的 token 直接用于本服务，无需二次登录；
3. 主后端改密/封号使 `token_version` 变化后，主后端会让 token 失效，本服务因 `exp` 到期自然同步失效。

```bash
# 服务器上：取主后端的 key，追加到微足迹服务并重启
MAIN_KEY=$(grep -m1 '^SECRET_KEY=' /path/to/backend/.env | cut -d= -f2-)
sed -i "s|^MF_SECRET_KEY_EXTRA=.*|MF_SECRET_KEY_EXTRA=${MAIN_KEY}|" .env
docker compose restart          # 或 systemctl restart myzuji-microfeed
curl -s localhost:7080/healthz  # {"ok":true,...}
```

**怎么判断是不是密钥没对上**：`/healthz` 返回 200 但带 token 请求 `/v1/me` 返回 401，
就是验签失败（网络和证书都是好的）。App 内「微足迹 → 服务」面板的「检测」会直接标出这一项。

---

## 4. 验证

```bash
npm test          # = smoke + auth-multi
```

- `npm run smoke`：真起一个临时端口与临时数据目录的服务进程，把上面**每一个**接口打一遍（含 Range 读取、幂等、越权、gzip、错误码），**61 项断言全部通过**。
- `npm run test:auth`：`shared` 模式下逐把签发 token，验证 `MF_SECRET_KEY` 与 `MF_SECRET_KEY_EXTRA` 里的 key 都放行、未配置的 key / 过期 / 签发方不符 / 类型不符 / 签名篡改都被拒，**12 项断言全部通过**。

---

## 5. App 侧接入

App 端 `data/microfeed/MicroFeedApi.kt` 指向本服务，地址按优先级取：

1. 用户在「微足迹 → 服务」面板里填的地址（存 SharedPreferences `micro_feed_remote`）；
2. 编译期默认值 `CloudConfig.MICROFEED_URL`（当前为已部署的 HTTPS 域名 `https://7080-…instabox.tech`）。

换自建服务器时改 `CloudConfig.MICROFEED_URL` 或直接在 App 面板里改，不用重装。服务不可达时 App 自动回落到本地示例池 + 本地足迹，功能不中断。

---

## 6. 运维

**备份**（SQLite 建议用 `.backup`，直接拷文件在写入瞬间可能不一致）：

```bash
sqlite3 data/microfeed.db ".backup 'backup-$(date +%F).db'"
tar czf storage-$(date +%F).tar.gz storage/
```

**升级**：替换 `src/` → `docker compose up -d --build`（或 `systemctl restart`）。表结构用 `CREATE TABLE IF NOT EXISTS`，只增不改，老库直接可用。

> 注意必须带 `--build`：源码是 `COPY src ./src` 进镜像的，光 `restart` 跑的还是旧代码。
> 数据在 `./data`、`./storage` 卷里，重建镜像不会丢。

**从 1.0.0 升级到 1.0.1 修了什么**（两处都会让「看起来部署好了」实际用不了）：

| 修复 | 不修的后果 | 判断方法 |
|---|---|---|
| 媒体路由改尾部通配 | 演示帖是 `seed/xxx.jpg`（两段），原路由只认三段 → **feed 有数据但图片全部 404** | `curl -o /dev/null -w "%{http_code}" <域名>/media/seed/chongqing.jpg` |
| 验签支持多密钥（`MF_SECRET_KEY_EXTRA`） | 微足迹 key 自动生成、与主后端不同 → **App 带 token 全程 401**，静默回落本地池 | `/healthz` 200 但带 token 求 `/v1/me` 401 |

升级后建议顺手跑一遍 `npm test`（smoke 64 项 + auth 12 项）。

**日志**：一行一请求（方法/路径/状态/耗时），5xx 带堆栈；`docker compose logs -f` 或 `journalctl`。

**清理滥用内容**：

```bash
sqlite3 data/microfeed.db "SELECT id, author_uid, substr(caption,1,30) FROM mf_posts WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 20;"
sqlite3 data/microfeed.db "UPDATE mf_posts SET deleted_at=strftime('%s','now')*1000 WHERE id='<id>';"
```

**容量估算**：一条图文足迹 ≈ 1–3MB 媒体；10 万条 ≈ 200GB 存储、数据库 < 200MB。图片大时可把 `MF_MAX_IMAGE_BYTES` 调低，或在前面挂对象存储/CDN。

---

## 7. 目录结构

```
microfeed-backend/
├── src/
│   ├── server.js       # 入口：路由表、CORS、安全头、错误兜底、优雅退出
│   ├── config.js       # 环境变量
│   ├── db.js           # node:sqlite + 建表 + 事务
│   ├── auth.js         # JWT 验签、用户建档、限流
│   ├── http.js         # JSON/gzip、请求体、参数清洗
│   ├── router.js       # 极简路由（:param + 尾部 *rest 通配）
│   ├── storage.js      # 媒体落盘（嗅探真实类型）
│   ├── serialize.js    # 组装成 App 的 MicroPost 形状
│   ├── seed.js         # 演示数据
│   └── routes/         # me / feed / posts / users / search / media
├── tests/smoke.js      # 64 项端到端断言
├── tests/auth-multi.js # 12 项多密钥验签断言
├── seed-media/         # 演示用 9 张照片（ASCII 文件名）
├── deploy/             # nginx / systemd 示例
├── Dockerfile / docker-compose.yml / start.sh / start.bat
└── .env.example
```

## 8. 安全清单（上线前逐条确认）

- [ ] `MF_AUTH_MODE=shared`，`MF_SECRET_KEY` 与主后端一致且不写进代码仓库
- [ ] 前置 HTTPS（Nginx/Caddy/云厂商 LB），App 端地址用 `https://`
- [ ] `MF_CORS_ORIGINS` 收紧到自己的域名（如不需要网页访问可留空）
- [ ] `data/`、`storage/` 目录权限只给服务用户
- [ ] Nginx `client_max_body_size` ≥ `MF_MAX_VIDEO_BYTES`
- [ ] 备份任务已配置（数据库 + 媒体）
