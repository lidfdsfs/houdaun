'use strict';
/**
 * 微足迹独立服务 —— 配置
 *
 * 设计取舍：零第三方依赖。HTTP、SQLite、JWT 验签、gzip 全部用 Node 内置能力，
 * 部署包只要一个 Node 运行时 + 一个目录，不需要 npm install，也不引入供应链风险。
 *
 * 与主后端（7070）的关系：
 *   - 代码/数据库/存储目录完全独立；
 *   - 唯一共享的是 SECRET_KEY：主后端签发的用户 JWT 在这里只做验签，
 *     用户不必登录两次，本服务也不需要读主后端的用户表。
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');

const env = (key, def = '') => {
  const raw = process.env[key];
  return raw === undefined || raw === '' ? def : String(raw).trim();
};
const envInt = (key, def) => {
  const n = Number.parseInt(env(key, String(def)), 10);
  return Number.isFinite(n) ? n : def;
};
const envBool = (key, def) => ['1', 'true', 'yes', 'on'].includes(env(key, def ? '1' : '0').toLowerCase());
const envList = (key) => env(key, '').split(',').map((s) => s.trim()).filter(Boolean);

const DATA_DIR = path.resolve(env('MF_DATA_DIR', path.join(ROOT, 'data')));
const STORAGE_DIR = path.resolve(env('MF_STORAGE_DIR', path.join(ROOT, 'storage')));

const settings = {
  appName: 'MY足迹 微足迹服务',
  appVersion: '1.0.0',

  env: env('MF_ENV', 'prod'),
  host: env('MF_HOST', '0.0.0.0'),
  port: envInt('MF_PORT', 7080),
  logLevel: env('MF_LOG_LEVEL', 'info'),

  dataDir: DATA_DIR,
  storageDir: STORAGE_DIR,
  get dbFile() {
    return path.join(DATA_DIR, 'microfeed.db');
  },

  // shared = 校验主后端 JWT；dev = 任何请求都当作 MF_DEV_UID
  authMode: env('MF_AUTH_MODE', 'shared').toLowerCase(),
  devUid: envInt('MF_DEV_UID', 1001),
  secretKey: env('MF_SECRET_KEY', env('SECRET_KEY', '')),
  jwtAlgorithm: env('MF_JWT_ALGORITHM', 'HS256').toUpperCase(),
  jwtIssuer: env('MF_JWT_ISSUER', 'myzuji-backend'),
  adminUids: envList('MF_ADMIN_UIDS').map((x) => Number.parseInt(x, 10)).filter(Number.isFinite),

  maxImageBytes: envInt('MF_MAX_IMAGE_BYTES', 12 * 1024 * 1024),
  maxVideoBytes: envInt('MF_MAX_VIDEO_BYTES', 300 * 1024 * 1024),
  maxAudioBytes: envInt('MF_MAX_AUDIO_BYTES', 24 * 1024 * 1024),

  captionMax: envInt('MF_CAPTION_MAX', 600),
  commentMax: envInt('MF_COMMENT_MAX', 300),
  tagsMax: envInt('MF_TAGS_MAX', 8),
  pageDefault: envInt('MF_PAGE_DEFAULT', 8),
  pageMax: envInt('MF_PAGE_MAX', 30),
  seedOnStart: envBool('MF_SEED_ON_START', true),
  recommendCityBoost: Number(env('MF_RECOMMEND_CITY_BOOST', '8')) || 0,

  corsOrigins: env('MF_CORS_ORIGINS', '*'),
  gzipMinBytes: envInt('MF_GZIP_MIN_BYTES', 1024),
  maxBodyBytes: envInt('MF_MAX_IMAGE_BYTES', 12 * 1024 * 1024) + 1024 * 1024,
};

/** 允许的来源列表；`*` 表示放开（原生 App 不吃 CORS，只有网页预览需要） */
Object.defineProperty(settings, 'corsOriginList', {
  get() {
    const raw = String(settings.corsOrigins || '').trim();
    if (!raw || raw === '*') return ['*'];
    return raw.split(',').map((s) => s.trim()).filter(Boolean);
  },
});

settings.ensureDirs = () => {
  fs.mkdirSync(settings.dataDir, { recursive: true });
  fs.mkdirSync(settings.storageDir, { recursive: true });
};

/**
 * SECRET_KEY 为空时生成并落盘 data/.secret_key，保证重启后 token 仍可用。
 * shared 模式下必须与主后端一致，否则验签必失败 —— 启动日志会明确提示。
 */
settings.jwtSecret = () => {
  if (settings.secretKey) return settings.secretKey;
  settings.ensureDirs();
  const cache = path.join(settings.dataDir, '.secret_key');
  if (fs.existsSync(cache)) return fs.readFileSync(cache, 'utf8').trim();
  const value = crypto.randomBytes(48).toString('base64url');
  fs.writeFileSync(cache, value, { mode: 0o600 });
  return value;
};

module.exports = { settings };
