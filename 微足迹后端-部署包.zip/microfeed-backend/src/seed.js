'use strict';
/**
 * 演示数据：只在库为空时灌一次（`MF_SEED_ON_START=1` 默认开）。
 *
 * 为什么要有：一个新部署的微足迹服务如果「关注/推荐/同城」全是空白，
 * 用户第一次打开会以为坏了。这里准备 8 位作者 + 9 条带真实照片的足迹，
 * 覆盖图文、话题、配乐标题、不同城市，保证首屏就有内容可滑。
 *
 * 作者 uid 用负数：和真实用户 id（正数）天然隔离，不会被误当成真人；
 * 照片来自 App 仓库 assets/photos，发布时复制进 storage/seed/ 并转成 ASCII 文件名，
 * 避免中文 URL 在不同客户端上的编码差异。
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { settings } = require('./config');
const { get, run, nowMs } = require('./db');

const SEED_SRC = path.resolve(__dirname, '..', 'seed-media');

const AUTHORS = [
  { uid: -101, nickname: '阿岚', bio: '把周末过成远方' },
  { uid: -102, nickname: '山野', bio: '只走没走过的路' },
  { uid: -103, nickname: '洱海的风', bio: '在大理住了三年' },
  { uid: -104, nickname: '老周在路上', bio: '开车丈量中国' },
  { uid: -105, nickname: '小满', bio: '拍照是为了记住光' },
  { uid: -106, nickname: '阿依', bio: '雪山控 · 高原常客' },
  { uid: -107, nickname: '北纬三十', bio: '地理爱好者' },
  { uid: -108, nickname: '陈小舟', bio: '城市漫游者' },
];

const POSTS = [
  {
    author: -101, file: 'sanya.jpg', place: '三亚·后海村', city: '三亚',
    caption: '凌晨五点爬起来等日出，海面像被谁撒了一把碎金。冲浪的人比太阳起得更早。',
    tags: ['海边日出', '冲浪', '海南'], bgmTitle: '海风与清晨', bgmArtist: 'Tunetank',
    likes: 1286, comments: 96, shares: 42,
  },
  {
    author: -102, file: 'daocheng.jpg', place: '稻城亚丁·牛奶海', city: '甘孜',
    caption: '海拔 4600 米，走三步喘两下。但转过最后一道山脊，湖水的颜色会让你忘了喘气这件事。',
    tags: ['川西', '徒步', '高原湖泊'], bgmTitle: '山脊之上', bgmArtist: 'Ambient Works',
    likes: 2431, comments: 187, shares: 121,
  },
  {
    author: -103, file: 'lijiang.jpg', place: '丽江·白沙古镇', city: '丽江',
    caption: '比起大研，更喜欢白沙。下午的光斜斜打在土墙上，狗在门口睡得很沉。',
    tags: ['古镇', '慢生活', '云南'], bgmTitle: '古镇午后', bgmArtist: 'Tunetank',
    likes: 876, comments: 54, shares: 33,
  },
  {
    author: -106, file: 'tibet.jpg', place: '西藏·纳木错', city: '拉萨',
    caption: '风把经幡吹得哗哗响，湖面一直蓝到天边。到这儿才知道「辽阔」不是形容词。',
    tags: ['西藏', '圣湖', '自驾'], bgmTitle: '高原的风', bgmArtist: 'Tunetank',
    likes: 3520, comments: 268, shares: 204,
  },
  {
    author: -104, file: 'xinjiang.jpg', place: '新疆·独库公路', city: '伊犁',
    caption: '一天里翻过四季：早上是雪，中午是草原，傍晚又撞进一片金黄。方向盘后面全是风景。',
    tags: ['自驾', '独库公路', '新疆'], bgmTitle: '公路之歌', bgmArtist: 'Road Trip',
    likes: 4102, comments: 331, shares: 288,
  },
  {
    author: -105, file: 'kyoto.jpg', place: '京都·哲学之道', city: '京都',
    caption: '樱花落尽之后的小路反而更安静，只有水声和自行车铃。旅行最好的部分常常在计划之外。',
    tags: ['京都', '街拍', '樱花季'], bgmTitle: '春之余白', bgmArtist: 'Piano Diary',
    likes: 1975, comments: 142, shares: 96,
  },
  {
    author: -107, file: 'iceland.jpg', place: '冰岛·南岸黑沙滩', city: '维克',
    caption: '玄武岩柱像管风琴，浪一来就吞掉整片沙滩。站在这里会本能地往后退半步。',
    tags: ['冰岛', '黑沙滩', '极地'], bgmTitle: '北纬的雪', bgmArtist: 'Ambient Works',
    likes: 2210, comments: 165, shares: 137,
  },
  {
    author: -108, file: 'chongqing.jpg', place: '重庆·鹅岭二厂', city: '重庆',
    caption: '轻轨从楼里穿过去，江对岸的灯刚亮。这座城市的立体感，照片只能拍出一半。',
    tags: ['重庆', 'citywalk', '夜景'], bgmTitle: '山城夜色', bgmArtist: 'Tunetank',
    likes: 1568, comments: 118, shares: 74,
  },
  {
    author: -101, file: 'changsha.jpg', place: '长沙·文和友', city: '长沙',
    caption: '排队两小时，嗦粉十分钟。但这条街的霓虹和吆喝声，确实值得挤一挤。',
    tags: ['长沙', '烟火气', '夜宵'], bgmTitle: '夜市进行曲', bgmArtist: 'Tunetank',
    likes: 1043, comments: 87, shares: 51,
  },
];

function copySeedImage(file) {
  const src = path.join(SEED_SRC, file);
  if (!fs.existsSync(src)) return null;
  const rel = `seed/${file}`;
  const target = path.join(settings.storageDir, rel);
  if (!fs.existsSync(target)) {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(src, target);
  }
  return `/media/${rel}`;
}

function seed({ force = false } = {}) {
  const existing = get('SELECT COUNT(*) c FROM mf_posts').c;
  if (Number(existing) > 0 && !force) {
    return { seeded: false, posts: Number(existing) };
  }
  const ts = nowMs();
  for (const a of AUTHORS) {
    run(
      `INSERT INTO mf_users(ext_uid, nickname, avatar_url, bio, verified, created_at, updated_at)
       VALUES(?,?,?,?,?,?,?)
       ON CONFLICT(ext_uid) DO UPDATE SET nickname=excluded.nickname, bio=excluded.bio`,
      a.uid, a.nickname, null, a.bio, a.uid === -106 ? 1 : 0, ts, ts,
    );
  }
  let created = 0;
  POSTS.forEach((p, i) => {
    const url = copySeedImage(p.file);
    const media = url ? [{ type: 'image', url }] : [];
    const created_at = ts - (POSTS.length - i) * 37 * 60 * 1000; // 每条间隔约 37 分钟
    run(
      `INSERT INTO mf_posts(id, author_uid, place, city, caption, tags, media,
                            bgm_title, bgm_artist, bgm_url, base_likes, base_comments, base_shares, views, created_at)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      crypto.randomUUID(), p.author, p.place, p.city, p.caption,
      JSON.stringify(p.tags), JSON.stringify(media),
      p.bgmTitle, p.bgmArtist, null,
      p.likes, 0, p.shares, p.likes * 7, created_at,
    );
    created += 1;
  });
  return { seeded: true, posts: created, authors: AUTHORS.length };
}

module.exports = { seed };

if (require.main === module) {
  const { initDb } = require('./db');
  initDb();
  const force = process.argv.includes('--force');
  const out = seed({ force });
  console.log(out.seeded ? `已灌入演示数据：${out.posts} 条足迹 / ${out.authors} 位作者` : `已有 ${out.posts} 条足迹，跳过（--force 可强制追加）`);
}
