'use strict';
/**
 * 本地开发入口：跳过 JWT 校验，任何请求都当作演示用户 1001。
 * 用法：npm run dev （等价于 MF_AUTH_MODE=dev node src/server.js）
 * 生产请用 npm start，并配置与主后端一致的 MF_SECRET_KEY。
 */
process.env.MF_AUTH_MODE = process.env.MF_AUTH_MODE || 'dev';
process.env.MF_SEED_ON_START = process.env.MF_SEED_ON_START || '1';
require('./server').bootstrap();
