'use strict';
/**
 * 极简路由：精确段 + `:param` 占位 + 尾部 `*rest` 通配。
 * 只有二十来条路由，不需要前缀树；线性匹配在这个量级完全够用且更好读。
 *
 * 尾部通配只有一个用武之地：媒体读取。媒体路径的层级由存储层决定
 * （演示数据是 seed/xxx.jpg 两段，用户上传是 uid/month/xxx.jpg 三段），
 * 用固定段数去匹配会漏掉其中一种 —— 表现为「数据有、图片全 404」。
 */
function createRouter() {
  const routes = [];

  const add = (method, pattern, handler, opts = {}) => {
    const segments = pattern.split('/').filter(Boolean);
    const star = segments.length > 0 && segments[segments.length - 1].startsWith('*');
    routes.push({
      method,
      segments,
      star,
      starName: star ? segments[segments.length - 1].slice(1) : null,
      handler,
      auth: opts.auth !== false,
    });
  };

  const match = (method, pathname) => {
    const segments = pathname.split('/').filter(Boolean);
    for (const route of routes) {
      if (route.method !== method) continue;
      const fixed = route.star ? route.segments.length - 1 : route.segments.length;
      if (route.star) {
        if (segments.length <= fixed) continue;
      } else if (route.segments.length !== segments.length) continue;

      const params = {};
      let ok = true;
      for (let i = 0; i < fixed; i += 1) {
        const seg = route.segments[i];
        if (seg.startsWith(':')) {
          params[seg.slice(1)] = decodeURIComponent(segments[i]);
        } else if (seg !== segments[i]) {
          ok = false;
          break;
        }
      }
      if (!ok) continue;
      if (route.star) {
        params[route.starName] = segments.slice(fixed).map(decodeURIComponent).join('/');
      }
      return { route, params };
    }
    return null;
  };

  return {
    get: (p, h, o) => add('GET', p, h, o),
    post: (p, h, o) => add('POST', p, h, o),
    put: (p, h, o) => add('PUT', p, h, o),
    patch: (p, h, o) => add('PATCH', p, h, o),
    delete: (p, h, o) => add('DELETE', p, h, o),
    match,
    get routes() {
      return routes;
    },
  };
}

module.exports = { createRouter };
