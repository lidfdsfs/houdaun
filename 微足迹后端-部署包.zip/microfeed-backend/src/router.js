'use strict';
/**
 * 极简路由：精确段 + `:param` 占位。
 * 只有二十来条路由，不需要前缀树；线性匹配在这个量级完全够用且更好读。
 */
function createRouter() {
  const routes = [];

  const add = (method, pattern, handler, opts = {}) => {
    routes.push({
      method,
      segments: pattern.split('/').filter(Boolean),
      handler,
      auth: opts.auth !== false,
    });
  };

  const match = (method, pathname) => {
    const segments = pathname.split('/').filter(Boolean);
    for (const route of routes) {
      if (route.method !== method) continue;
      if (route.segments.length !== segments.length) continue;
      const params = {};
      let ok = true;
      for (let i = 0; i < route.segments.length; i += 1) {
        const seg = route.segments[i];
        if (seg.startsWith(':')) {
          params[seg.slice(1)] = decodeURIComponent(segments[i]);
        } else if (seg !== segments[i]) {
          ok = false;
          break;
        }
      }
      if (ok) return { route, params };
    }
    return null;
  };

  return {
    get: (p, h, o) => add('GET', p, h, o),
    post: (p, h, o) => add('POST', p, h, o),
    put: (p, h, o) => add('PUT', p, h, o),
    patch: (p, h, o) => add('PATCH', p, h, o),
    delete: (p, h, o) => add('DELETE', p, h, o),
    match,
    get routes() {
      return routes;
    },
  };
}

module.exports = { createRouter };
