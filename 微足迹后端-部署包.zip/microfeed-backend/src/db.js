'use strict';
/**
 * 存储层：node:sqlite（Node 内置，无需安装驱动）。
 *
 * 只属于微足迹服务，一张表都不与主后端共用。SQLite 开 WAL 后并发读够用，
 * 部署形态是「一个进程 + 一个目录」，不需要额外的数据库服务。
 * 将来要横向扩展，把这里换成 Postgres 即可，SQL 都是标准写法。
 *
 * 时间统一毫秒时间戳（与 App 端 publishedAt 同口径），避免时区歧义。
 */
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { settings } = require('./config');

const SCHEMA = `
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS mf_users (
  ext_uid    INTEGER PRIMARY KEY,
  nickname   TEXT NOT NULL DEFAULT '',
  avatar_url TEXT,
  bio        TEXT NOT NULL DEFAULT '',
  verified   INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS mf_posts (
  id            TEXT PRIMARY KEY,
  author_uid    INTEGER NOT NULL,
  place         TEXT NOT NULL DEFAULT '',
  city          TEXT NOT NULL DEFAULT '',
  caption       TEXT NOT NULL DEFAULT '',
  tags          TEXT NOT NULL DEFAULT '[]',
  media         TEXT NOT NULL DEFAULT '[]',
  bgm_title     TEXT,
  bgm_artist    TEXT,
  bgm_url       TEXT,
  lat           REAL,
  lon           REAL,
  base_likes    INTEGER NOT NULL DEFAULT 0,
  base_comments INTEGER NOT NULL DEFAULT 0,
  base_shares   INTEGER NOT NULL DEFAULT 0,
  views         INTEGER NOT NULL DEFAULT 0,
  created_at    INTEGER NOT NULL,
  deleted_at    INTEGER
);
CREATE INDEX IF NOT EXISTS idx_posts_created ON mf_posts(deleted_at, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_author  ON mf_posts(author_uid, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_city    ON mf_posts(city, created_at DESC);

CREATE TABLE IF NOT EXISTS mf_likes (
  post_id TEXT NOT NULL, uid INTEGER NOT NULL, created_at INTEGER NOT NULL,
  PRIMARY KEY (post_id, uid)
);
CREATE INDEX IF NOT EXISTS idx_likes_uid ON mf_likes(uid);

CREATE TABLE IF NOT EXISTS mf_favs (
  post_id TEXT NOT NULL, uid INTEGER NOT NULL, created_at INTEGER NOT NULL,
  PRIMARY KEY (post_id, uid)
);

CREATE TABLE IF NOT EXISTS mf_shares (
  post_id TEXT NOT NULL, uid INTEGER NOT NULL, created_at INTEGER NOT NULL,
  PRIMARY KEY (post_id, uid)
);

CREATE TABLE IF NOT EXISTS mf_hides (
  post_id TEXT NOT NULL, uid INTEGER NOT NULL, created_at INTEGER NOT NULL,
  PRIMARY KEY (post_id, uid)
);

CREATE TABLE IF NOT EXISTS mf_views (
  post_id TEXT NOT NULL, uid INTEGER NOT NULL, created_at INTEGER NOT NULL,
  PRIMARY KEY (post_id, uid)
);

CREATE TABLE IF NOT EXISTS mf_comments (
  id TEXT PRIMARY KEY, post_id TEXT NOT NULL, uid INTEGER NOT NULL,
  body TEXT NOT NULL, reply_to TEXT, created_at INTEGER NOT NULL, deleted_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_comments_post ON mf_comments(post_id, created_at DESC);

CREATE TABLE IF NOT EXISTS mf_comment_likes (
  comment_id TEXT NOT NULL, uid INTEGER NOT NULL, created_at INTEGER NOT NULL,
  PRIMARY KEY (comment_id, uid)
);

CREATE TABLE IF NOT EXISTS mf_follows (
  follower_uid INTEGER NOT NULL, target_uid INTEGER NOT NULL, created_at INTEGER NOT NULL,
  PRIMARY KEY (follower_uid, target_uid)
);
CREATE INDEX IF NOT EXISTS idx_follows_target ON mf_follows(target_uid);

CREATE TABLE IF NOT EXISTS mf_reports (
  id TEXT PRIMARY KEY, post_id TEXT, comment_id TEXT, uid INTEGER NOT NULL,
  reason TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
);
`;

let conn = null;

function open() {
  if (conn) return conn;
  settings.ensureDirs();
  fs.mkdirSync(path.dirname(settings.dbFile), { recursive: true });
  conn = new DatabaseSync(settings.dbFile);
  conn.exec(SCHEMA);
  return conn;
}

const stmtCache = new Map();
function stmt(sql) {
  let s = stmtCache.get(sql);
  if (!s) {
    s = open().prepare(sql);
    stmtCache.set(sql, s);
  }
  return s;
}

/** 查多行 */
function all(sql, ...params) {
  return stmt(sql).all(...params);
}
/** 查一行（没有则 undefined） */
function get(sql, ...params) {
  return stmt(sql).get(...params);
}
/** 写一行，返回 { changes, lastInsertRowid } */
function run(sql, ...params) {
  return stmt(sql).run(...params);
}

/** 显式事务：写操作要么全成，要么全不成 */
function tx(fn) {
  const db = open();
  db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn(db);
    db.exec('COMMIT');
    return out;
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch { /* 连接已断时忽略 */ }
    throw err;
  }
}

const nowMs = () => Date.now();
const uid4 = () => require('node:crypto').randomUUID();

function initDb() {
  open();
  return settings.dbFile;
}

function dbSizeBytes() {
  try {
    return fs.statSync(settings.dbFile).size;
  } catch {
    return 0;
  }
}

module.exports = { initDb, all, get, run, tx, nowMs, uid4, dbSizeBytes, open };
