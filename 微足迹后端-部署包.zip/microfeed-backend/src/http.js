'use strict';
/**
 * 极简 HTTP 工具：错误、JSON 响应（带 gzip）、请求体读取、查询串解析。
 * 不引框架是刻意的：路由一共二十来条，内置 http 足够，还能省掉一整层依赖。
 */
const zlib = require('node:zlib');

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const badRequest = (msg) => new ApiError(400, msg);
const unauthorized = (msg = '未登录') => new ApiError(401, msg);
const forbidden = (msg = '无权操作') => new ApiError(403, msg);
const notFound = (msg = '内容不存在') => new ApiError(404, msg);
const tooLarge = (msg = '内容过大') => new ApiError(413, msg);

function sendJson(req, res, status, payload, extraHeaders = {}) {
  let body = Buffer.from(JSON.stringify(payload), 'utf8');
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...extraHeaders,
  };
  const acceptsGzip = String(req.headers['accept-encoding'] || '').includes('gzip');
  const { settings } = require('./config');
  if (acceptsGzip && body.length >= settings.gzipMinBytes) {
    body = zlib.gzipSync(body, { level: 6 });
    headers['Content-Encoding'] = 'gzip';
    headers.Vary = 'Accept-Encoding';
  }
  headers['Content-Length'] = String(body.length);
  res.writeHead(status, headers);
  res.end(body);
}

function sendBuffer(req, res, status, buffer, contentType, extraHeaders = {}) {
  const headers = { 'Content-Type': contentType, ...extraHeaders };
  headers['Content-Length'] = String(buffer.length);
  res.writeHead(status, headers);
  res.end(buffer);
}

/** 读取请求体，超限立刻中断，避免把内存打满 */
function readBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    const declared = Number.parseInt(req.headers['content-length'] || '0', 10);
    if (Number.isFinite(declared) && declared > maxBytes) {
      reject(tooLarge(`请求体过大，上限 ${Math.floor(maxBytes / 1024 / 1024)}MB`));
      req.resume();
      return;
    }
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(tooLarge(`请求体过大，上限 ${Math.floor(maxBytes / 1024 / 1024)}MB`));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function readJson(req, maxBytes) {
  const raw = await readBody(req, maxBytes);
  if (!raw.length) return {};
  try {
    const parsed = JSON.parse(raw.toString('utf8'));
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw badRequest('请求体必须是 JSON 对象');
    }
    return parsed;
  } catch (err) {
    if (err instanceof ApiError) throw err;
    throw badRequest('请求体不是合法 JSON');
  }
}

function parseUrl(req) {
  const url = new URL(req.url, 'http://localhost');
  return { pathname: url.pathname, query: url.searchParams };
}

/** 取整型查询参数，带上下限 */
function intParam(query, name, def, min, max) {
  const raw = query.get(name);
  if (raw === null) return def;
  const n = Number.parseInt(raw, 10);
  if (!Number.isFinite(n)) return def;
  return Math.min(Math.max(n, min), max);
}

function strParam(query, name, maxLen = 120) {
  const raw = query.get(name);
  if (raw === null) return '';
  return raw.trim().slice(0, maxLen);
}

function cleanText(value, maxLen) {
  if (typeof value !== 'string') return '';
  // 去掉控制字符（保留换行），并裁到上限；不在这里做 HTML 转义，
  // 客户端是原生 Compose 文本渲染，服务端只保证长度与可存储性。
  return value
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .trim()
    .slice(0, maxLen);
}

module.exports = {
  ApiError,
  badRequest,
  unauthorized,
  forbidden,
  notFound,
  tooLarge,
  sendJson,
  sendBuffer,
  readBody,
  readJson,
  parseUrl,
  intParam,
  strParam,
  cleanText,
};
