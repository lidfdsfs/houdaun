'use strict';
/**
 * 把数据库行组装成 App 端 MicroPost 的形状（camelCase 字段一一对应）。
 *
 * 在服务端对齐形状，客户端就只有「解析」没有「翻译」，后端加字段也不会把
 * Android 侧改成一团。
 *
 * 计数口径（与 App 本地池一致）：
 *   baseLikes    = 帖子自带基数 + 真实点赞行数（App 里显示的 likeCount 再叠加本人一票）
 *   baseComments = 未删除评论数
 *   baseShares   = 帖子自带基数 + 真实分享行数
 *   favorites    = 收藏行数
 */
const { all, get, nowMs } = require('./db');

const marks = (n) => Array.from({ length: n }, () => '?').join(',');

function jsonList(raw) {
  if (!raw) return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
}

function relativeTime(ts) {
  const minutes = Math.max(0, Math.floor((nowMs() - Number(ts || 0)) / 60_000));
  if (minutes < 1) return '刚刚';
  if (minutes < 60) return `${minutes}分钟前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}小时前`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}天前`;
  if (days < 365) return `${Math.floor(days / 30)}个月前`;
  return `${Math.floor(days / 365)}年前`;
}

function countMap(table, ids, extraWhere = '') {
  if (ids.length === 0) return new Map();
  const rows = all(
    `SELECT post_id, COUNT(*) AS c FROM ${table} WHERE post_id IN (${marks(ids.length)})${extraWhere} GROUP BY post_id`,
    ...ids,
  );
  return new Map(rows.map((r) => [r.post_id, Number(r.c)]));
}

function mineSet(table, ids, uid) {
  if (!uid || ids.length === 0) return new Set();
  const rows = all(
    `SELECT post_id FROM ${table} WHERE uid = ? AND post_id IN (${marks(ids.length)})`,
    uid,
    ...ids,
  );
  return new Set(rows.map((r) => r.post_id));
}

function serializePosts(rows, viewerUid) {
  if (!rows || rows.length === 0) return [];
  const ids = rows.map((r) => r.id);
  const authorUids = [...new Set(rows.map((r) => Number(r.author_uid)))];

  const likes = countMap('mf_likes', ids);
  const shares = countMap('mf_shares', ids);
  const favs = countMap('mf_favs', ids);
  const comments = countMap('mf_comments', ids, ' AND deleted_at IS NULL');
  const myLikes = mineSet('mf_likes', ids, viewerUid);
  const myFavs = mineSet('mf_favs', ids, viewerUid);

  const authors = new Map();
  if (authorUids.length) {
    for (const row of all(`SELECT * FROM mf_users WHERE ext_uid IN (${marks(authorUids.length)})`, ...authorUids)) {
      authors.set(Number(row.ext_uid), row);
    }
  }

  const followerCount = new Map();
  const followed = new Set();
  if (authorUids.length) {
    for (const row of all(
      `SELECT target_uid, COUNT(*) c FROM mf_follows WHERE target_uid IN (${marks(authorUids.length)}) GROUP BY target_uid`,
      ...authorUids,
    )) {
      followerCount.set(Number(row.target_uid), Number(row.c));
    }
    if (viewerUid) {
      for (const row of all(
        `SELECT target_uid FROM mf_follows WHERE follower_uid = ? AND target_uid IN (${marks(authorUids.length)})`,
        viewerUid,
        ...authorUids,
      )) {
        followed.add(Number(row.target_uid));
      }
    }
  }

  return rows.map((r) => {
    const uid = Number(r.author_uid);
    const a = authors.get(uid);
    const media = jsonList(r.media);
    const imagePaths = media.filter((m) => m && m.type === 'image' && m.url).map((m) => m.url);
    const video = media.find((m) => m && m.type === 'video' && m.url);
    const nickname = (a && a.nickname) || `足迹用户${uid}`;
    return {
      id: r.id,
      author: {
        id: uid,
        name: nickname,
        avatarText: nickname.slice(0, 1) || '·',
        avatarPath: a ? a.avatar_url : null,
        bio: (a && a.bio) || '',
        followers: followerCount.get(uid) || 0,
        verified: a ? Boolean(a.verified) : false,
      },
      place: r.place || '',
      city: r.city || '',
      caption: r.caption || '',
      tags: jsonList(r.tags),
      imagePaths,
      videoPath: video ? video.url : null,
      bgmTitle: r.bgm_title || null,
      bgmPath: r.bgm_url || null,
      bgmArtist: r.bgm_artist || null,
      baseLikes: Number(r.base_likes) + (likes.get(r.id) || 0),
      baseComments: comments.get(r.id) || 0,
      baseShares: Number(r.base_shares) + (shares.get(r.id) || 0),
      favorites: favs.get(r.id) || 0,
      liked: myLikes.has(r.id),
      favored: myFavs.has(r.id),
      followed: followed.has(uid),
      isMine: Boolean(viewerUid) && uid === viewerUid,
      publishedAt: Number(r.created_at),
      views: Number(r.views || 0),
      mediaCount: media.length,
    };
  });
}

function serializeComments(rows, viewerUid) {
  if (!rows || rows.length === 0) return [];
  const ids = rows.map((r) => r.id);
  const uids = [...new Set(rows.map((r) => Number(r.uid)))];
  const names = new Map();
  if (uids.length) {
    for (const row of all(`SELECT ext_uid, nickname FROM mf_users WHERE ext_uid IN (${marks(uids.length)})`, ...uids)) {
      names.set(Number(row.ext_uid), row.nickname);
    }
  }
  const likeCounts = new Map();
  for (const row of all(
    `SELECT comment_id, COUNT(*) c FROM mf_comment_likes WHERE comment_id IN (${marks(ids.length)}) GROUP BY comment_id`,
    ...ids,
  )) {
    likeCounts.set(row.comment_id, Number(row.c));
  }
  const mine = new Set();
  if (viewerUid) {
    for (const row of all(
      `SELECT comment_id FROM mf_comment_likes WHERE uid = ? AND comment_id IN (${marks(ids.length)})`,
      viewerUid,
      ...ids,
    )) {
      mine.add(row.comment_id);
    }
  }
  return rows.map((r) => ({
    id: r.id,
    authorName: names.get(Number(r.uid)) || `足迹用户${r.uid}`,
    text: r.body,
    time: relativeTime(r.created_at),
    createdAt: Number(r.created_at),
    authorId: Number(r.uid),
    replyTo: r.reply_to || null,
    likes: likeCounts.get(r.id) || 0,
    liked: mine.has(r.id),
    deletable: Boolean(viewerUid) && Number(r.uid) === viewerUid,
  }));
}

function serializeUser(uid, viewerUid) {
  const row = get('SELECT * FROM mf_users WHERE ext_uid = ?', uid);
  const followers = get('SELECT COUNT(*) c FROM mf_follows WHERE target_uid = ?', uid).c;
  const following = get('SELECT COUNT(*) c FROM mf_follows WHERE follower_uid = ?', uid).c;
  const posts = get('SELECT COUNT(*) c FROM mf_posts WHERE author_uid = ? AND deleted_at IS NULL', uid).c;
  const likesReceived = get(
    'SELECT COUNT(*) c FROM mf_likes l JOIN mf_posts p ON p.id = l.post_id WHERE p.author_uid = ? AND p.deleted_at IS NULL',
    uid,
  ).c;

  let followingHim = false;
  let followsMe = false;
  if (viewerUid && viewerUid !== uid) {
    followingHim = Boolean(get('SELECT 1 FROM mf_follows WHERE follower_uid = ? AND target_uid = ?', viewerUid, uid));
    followsMe = Boolean(get('SELECT 1 FROM mf_follows WHERE follower_uid = ? AND target_uid = ?', uid, viewerUid));
  }
  const nickname = (row && row.nickname) || `足迹用户${uid}`;
  return {
    id: uid,
    name: nickname,
    avatarText: nickname.slice(0, 1) || '·',
    avatarPath: row ? row.avatar_url : null,
    bio: (row && row.bio) || '',
    followers: Number(followers),
    following: Number(following),
    posts: Number(posts),
    likesReceived: Number(likesReceived),
    verified: row ? Boolean(row.verified) : false,
    followingHim,
    followsMe,
    mutual: followingHim && followsMe,
    isMe: viewerUid === uid,
  };
}

module.exports = { serializePosts, serializeComments, serializeUser, relativeTime, jsonList };
