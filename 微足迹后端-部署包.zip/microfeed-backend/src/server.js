'use strict';
/**
 * 微足迹独立服务入口。
 *
 * 与主后端（7070）完全分开：自己的数据库、自己的存储目录、自己的进程与端口，
 * 唯一共享的是 SECRET_KEY（用于校验主后端签发的用户 JWT）。
 *
 * 启动：node src/server.js  （Node >= 22.5，需要内置 node:sqlite）
 * 部署：见 README 的 Docker / systemd / 宝塔三种方式。
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { settings } = require('./config');
const { initDb, dbSizeBytes } = require('./db');
const { createRouter } = require('./router');
const { currentUid, optionalUid } = require('./auth');
const { ApiError, sendJson, parseUrl } = require('./http');
const { seed } = require('./seed');

const router = createRouter();
require('./routes/me').register(router);
require('./routes/feed').register(router);
require('./routes/posts').register(router);
require('./routes/users').register(router);
require('./routes/search').register(router);
require('./routes/media').register(router);

const startedAt = Date.now();

function log(level, msg, extra) {
  const line = `${new Date().toISOString()} ${level.toUpperCase()} ${msg}${extra ? ` ${JSON.stringify(extra)}` : ''}`;
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
}

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin'); // 媒体要被 App 跨域加载
}

function applyCors(req, res) {
  const origin = req.headers.origin;
  const allow = settings.corsOriginList;
  if (allow.includes('*')) {
    res.setHeader('Access-Control-Allow-Origin', origin || '*');
  } else if (origin && allow.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization,Content-Type,Accept,Range');
  res.setHeader('Access-Control-Max-Age', '86400');
}

// ---- 基础设施接口 ----
router.get('/ping', (ctx) => {
  sendJson(ctx.req, ctx.res, 200, { ok: true, service: settings.appName, version: settings.appVersion });
}, { auth: false });

router.get('/healthz', (ctx) => {
  let dbOk = true;
  try {
    initDb();
  } catch {
    dbOk = false;
  }
  sendJson(ctx.req, ctx.res, dbOk ? 200 : 503, {
    ok: dbOk,
    db: dbOk,
    uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
    dbBytes: dbSizeBytes(),
  });
}, { auth: false });

router.get('/v1/meta', (ctx) => {
  sendJson(ctx.req, ctx.res, 200, {
    service: settings.appName,
    version: settings.appVersion,
    env: settings.env,
    authMode: settings.authMode,
    serverTime: Date.now(),
    limits: {
      captionMax: settings.captionMax,
      commentMax: settings.commentMax,
      tagsMax: settings.tagsMax,
      pageMax: settings.pageMax,
      maxImageBytes: settings.maxImageBytes,
      maxVideoBytes: settings.maxVideoBytes,
      maxAudioBytes: settings.maxAudioBytes,
    },
    features: {
      feedTabs: ['following', 'recommend', 'nearby', 'mine'],
      interactions: ['like', 'favorite', 'share', 'hide', 'view', 'report'],
      media: true,
      rangeRequests: true,
      search: true,
      trendingTags: true,
    },
  });
}, { auth: false });

const server = http.createServer(async (req, res) => {
  const began = process.hrtime.bigint();
  securityHeaders(res);
  applyCors(req, res);

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const { pathname, query } = parseUrl(req);

  try {
    const matched = router.match(req.method, pathname);
    if (!matched) {
      sendJson(req, res, 404, { detail: '接口不存在', path: pathname });
      return;
    }
    const ctx = { req, res, query, params: matched.params };
    // 路由级鉴权：需要登录的接口在这里统一 401，避免每个 handler 各写一遍
    ctx.uid = matched.route.auth ? currentUid(req) : optionalUid(req);
    await matched.route.handler(ctx, matched.params);

    const ms = Number(process.hrtime.bigint() - began) / 1e6;
    log('info', `${req.method} ${pathname} ${res.statusCode} ${ms.toFixed(1)}ms`);
  } catch (err) {
    const status = err instanceof ApiError ? err.status : Number(err.status) || 500;
    if (status >= 500) log('error', `${req.method} ${pathname} 500`, { error: err.message, stack: err.stack });
    if (!res.headersSent) {
      sendJson(req, res, status, { detail: status >= 500 ? '服务器内部错误，请稍后再试' : err.message });
    } else {
      res.end();
    }
  }
});

function bootstrap() {
  settings.ensureDirs();
  initDb();
  if (settings.authMode === 'shared' && !settings.secretKey) {
    log('warn', '未配置 MF_SECRET_KEY：已使用 data/.secret_key 自动生成；若与主后端不一致，用户 token 将无法通过校验');
    log('warn', '修法：把主后端的 SECRET_KEY 填进 MF_SECRET_KEY_EXTRA（可逗号分隔多把），重启即可，无需让用户重新登录');
  }
  if (settings.seedOnStart) {
    const out = seed();
    log('info', out.seeded ? `演示数据已灌入 ${out.posts} 条` : `已有 ${out.posts} 条足迹，跳过演示数据`);
  }
  server.listen(settings.port, settings.host, () => {
    log('info', `${settings.appName} v${settings.appVersion} 启动于 http://${settings.host}:${settings.port}`);
    log('info', `数据库 ${settings.dbFile}`);
    log('info', `存储目录 ${settings.storageDir}`);
    log('info', `鉴权模式 ${settings.authMode}${settings.authMode === 'dev' ? `（所有请求视为 uid=${settings.devUid}）` : ''}`);
    if (settings.authMode === 'shared') {
      log('info', `验签密钥 ${settings.jwtSecrets().length} 把（含 MF_SECRET_KEY_EXTRA）`);
    }
    log('info', `路由 ${router.routes.length} 条`);
  });
}

function shutdown(signal) {
  log('info', `收到 ${signal}，正在关闭…`);
  server.close(() => {
    log('info', '已关闭');
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', (err) => log('error', 'unhandledRejection', { error: String(err) }));

if (require.main === module) bootstrap();

module.exports = { server, bootstrap, router, log };
