'use strict';
/**
 * 媒体落地：判类型（按文件头，不信 Content-Type）、限量、按用户分目录写盘。
 *
 * 上传接口收的是「原始二进制 + Content-Type」，不用 multipart：
 * App 用 HttpURLConnection 直接写字节流即可，服务端也省掉一整层解析。
 *
 * 目录：storage/{uid}/{yyyyMM}/{uuid}.{ext}
 * 公开读：/media/{uid}/{yyyyMM}/{uuid}.{ext}（只读，禁止 ../ 穿越）
 * 不生成缩略图：App 端 Coil 会按显示尺寸采样，服务端再存一份只是双倍磁盘。
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { settings } = require('./config');
const { tooLarge, badRequest, ApiError } = require('./http');

const IMAGE_MIMES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/gif']);
const VIDEO_MIMES = new Set(['video/mp4', 'video/quicktime', 'video/webm']);
const AUDIO_MIMES = new Set(['audio/mpeg', 'audio/mp4', 'audio/aac', 'audio/wav', 'audio/x-m4a']);

const EXT = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/heic': 'heic',
  'image/gif': 'gif',
  'video/mp4': 'mp4',
  'video/quicktime': 'mov',
  'video/webm': 'webm',
  'audio/mpeg': 'mp3',
  'audio/mp4': 'm4a',
  'audio/aac': 'aac',
  'audio/wav': 'wav',
  'audio/x-m4a': 'm4a',
};

function sniff(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.subarray(0, 6).toString('ascii') === 'GIF87a' || buf.subarray(0, 6).toString('ascii') === 'GIF89a') return 'image/gif';
  if (buf.subarray(0, 4).toString('ascii') === 'RIFF' && buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'image/webp';
  if (buf.subarray(4, 8).toString('ascii') === 'ftyp') {
    const brand = buf.subarray(8, 12).toString('ascii');
    if (['heic', 'heix', 'hevc', 'mif1', 'msf1'].includes(brand)) return 'image/heic';
    if (brand === 'qt  ') return 'video/quicktime';
    return 'video/mp4';
  }
  if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return 'video/webm';
  if (buf.subarray(0, 3).toString('ascii') === 'ID3') return 'audio/mpeg';
  if (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0) return 'audio/mpeg';
  return null;
}

function limitFor(kind, mime) {
  if (IMAGE_MIMES.has(mime) || kind === 'image') return settings.maxImageBytes;
  if (VIDEO_MIMES.has(mime) || kind === 'video') return settings.maxVideoBytes;
  if (AUDIO_MIMES.has(mime) || kind === 'audio') return settings.maxAudioBytes;
  return settings.maxImageBytes;
}

function resolveKind(mime) {
  if (IMAGE_MIMES.has(mime)) return 'image';
  if (VIDEO_MIMES.has(mime)) return 'video';
  if (AUDIO_MIMES.has(mime)) return 'audio';
  return null;
}

/** 只允许 storage 目录内的相对路径，挡住路径穿越 */
function safeStoragePath(relPath) {
  const root = settings.storageDir;
  const target = path.resolve(root, relPath);
  if (!target.startsWith(root + path.sep)) return null;
  return target;
}

function saveBuffer(uid, buffer, contentType, kindHint) {
  if (!buffer || buffer.length === 0) throw badRequest('空文件');
  const declared = String(contentType || '').split(';')[0].trim().toLowerCase().replace('audio/m4a', 'audio/mp4');
  const mime = sniff(buffer.subarray(0, 32)) || (resolveKind(declared) ? declared : null);
  const kind = mime ? resolveKind(mime) : resolveKind(declared);
  if (!kind) throw new ApiError(415, '不支持的文件类型');

  const cap = limitFor(kindHint || kind, mime || declared);
  if (buffer.length > cap) throw tooLarge(`文件超过上限 ${Math.floor(cap / 1024 / 1024)}MB`);

  const d = new Date();
  const month = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}`;
  const ext = EXT[mime] || EXT[declared] || 'bin';
  const relPath = `${uid}/${month}/${crypto.randomUUID()}.${ext}`;
  const target = safeStoragePath(relPath);
  if (!target) throw badRequest('非法路径');
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, buffer);

  return {
    type: kind,
    path: relPath,
    url: `/media/${relPath}`,
    mime: mime || declared,
    bytes: buffer.length,
  };
}

module.exports = { saveBuffer, safeStoragePath, sniff, IMAGE_MIMES, VIDEO_MIMES, AUDIO_MIMES };
