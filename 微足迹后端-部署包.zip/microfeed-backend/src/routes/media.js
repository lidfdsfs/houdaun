'use strict';
/**
 * 媒体上传与读取。
 *
 * 上传收「原始二进制」而不是 multipart：App 用 HttpURLConnection 直接写字节流，
 * 服务端不必解析表单，也少一层内存拷贝。
 *
 * 读取支持 Range（206）：视频要能拖动进度条/边下边播，没有 Range 的静态文件
 * 在部分播放器上会退化成「必须整段下完」。
 */
const fs = require('node:fs');
const path = require('node:path');
const { settings } = require('../config');
const { currentUid, rateLimit } = require('../auth');
const { sendJson, readBody, tooLarge, notFound } = require('../http');
const { saveBuffer, safeStoragePath } = require('../storage');

const MIME_BY_EXT = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp',
  heic: 'image/heic', gif: 'image/gif',
  mp4: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm',
  mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', wav: 'audio/wav',
};

function serveFile(req, res, relPath) {
  const target = safeStoragePath(relPath);
  if (!target || !fs.existsSync(target) || !fs.statSync(target).isFile()) {
    throw notFound('文件不存在');
  }
  const ext = path.extname(target).slice(1).toLowerCase();
  const mime = MIME_BY_EXT[ext] || 'application/octet-stream';
  const size = fs.statSync(target).size;
  const range = req.headers.range;

  if (range) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
    if (m) {
      let start = m[1] === '' ? null : Number.parseInt(m[1], 10);
      let end = m[2] === '' ? null : Number.parseInt(m[2], 10);
      if (start === null && end !== null) {
        // bytes=-N：最后 N 字节
        start = Math.max(0, size - end);
        end = size - 1;
      }
      start = start === null ? 0 : start;
      end = end === null ? size - 1 : Math.min(end, size - 1);
      if (start > end || start >= size) {
        res.writeHead(416, { 'Content-Range': `bytes */${size}` });
        res.end();
        return;
      }
      res.writeHead(206, {
        'Content-Type': mime,
        'Content-Length': String(end - start + 1),
        'Content-Range': `bytes ${start}-${end}/${size}`,
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'public, max-age=31536000, immutable',
      });
      fs.createReadStream(target, { start, end }).pipe(res);
      return;
    }
  }

  res.writeHead(200, {
    'Content-Type': mime,
    'Content-Length': String(size),
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'public, max-age=31536000, immutable',
  });
  fs.createReadStream(target).pipe(res);
}

function register(router) {
  router.post('/v1/media', async (ctx) => {
    const uid = currentUid(ctx.req);
    rateLimit('media', uid);
    const declared = String(ctx.req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    // 先按声明类型给一个上限，真正的大小校验在 saveBuffer 里按嗅探到的实际类型再来一次
    const hint = declared.startsWith('video/') ? 'video' : declared.startsWith('audio/') ? 'audio' : 'image';
    const cap = hint === 'video' ? settings.maxVideoBytes : hint === 'audio' ? settings.maxAudioBytes : settings.maxImageBytes;
    const body = await readBody(ctx.req, cap);
    if (body.length > cap) throw tooLarge('文件超过上限');
    const saved = saveBuffer(uid, body, declared, hint);
    sendJson(ctx.req, ctx.res, 201, saved);
  });

  // 公开读媒体（不带 token，App 直接给 Coil / MediaPlayer 用）
  router.get('/media/:uid/:month/:name', (ctx) => {
    serveFile(ctx.req, ctx.res, `${ctx.params.uid}/${ctx.params.month}/${ctx.params.name}`);
  }, { auth: false });
}

module.exports = { register };
