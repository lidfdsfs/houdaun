'use strict';
/**
 * 信息流：关注 / 推荐 / 同城 / 我的。
 *
 * 分页统一用 offset（cursor 就是下一页的 offset 字符串）：
 * 微足迹的排序里「推荐」带热度权重，keyset 分页在热度序上不成立；
 * 数据量级（单机、万级）下 offset 完全够用，客户端逻辑也简单。
 */
const { settings } = require('../config');
const { all, get } = require('../db');
const { currentUid, optionalUid } = require('../auth');
const { sendJson, intParam, strParam, badRequest } = require('../http');
const { serializePosts } = require('../serialize');

const LIKES = '(SELECT COUNT(*) FROM mf_likes l WHERE l.post_id = p.id)';
const COMMENTS = '(SELECT COUNT(*) FROM mf_comments c WHERE c.post_id = p.id AND c.deleted_at IS NULL)';
const SHARES = '(SELECT COUNT(*) FROM mf_shares s WHERE s.post_id = p.id)';

const TAB_ALIASES = {
  following: 'following', follow: 'following', 0: 'following',
  recommend: 'recommend', foryou: 'recommend', 1: 'recommend',
  nearby: 'nearby', city: 'nearby', local: 'nearby', 2: 'nearby',
  mine: 'mine', my: 'mine', 3: 'mine',
};

function buildWhere({ tab, uid, city, tag, q }) {
  const where = ['p.deleted_at IS NULL'];
  const params = [];

  if (tab === 'following') {
    where.push('(p.author_uid = ? OR p.author_uid IN (SELECT target_uid FROM mf_follows WHERE follower_uid = ?))');
    params.push(uid, uid);
  } else if (tab === 'nearby') {
    where.push('(p.city = ? OR p.place LIKE ?)');
    params.push(city, `%${city}%`);
  } else if (tab === 'mine') {
    where.push('p.author_uid = ?');
    params.push(uid);
  } else {
    // 推荐流：剔除我点过「不感兴趣」的；自己的帖子不占推荐位
    where.push('p.id NOT IN (SELECT post_id FROM mf_hides WHERE uid = ?)');
    params.push(uid);
  }

  if (tag) {
    where.push('p.tags LIKE ?');
    params.push(`%"${tag}"%`);
  }
  if (q) {
    where.push('(p.caption LIKE ? OR p.place LIKE ? OR p.city LIKE ? OR p.tags LIKE ? OR p.author_uid IN (SELECT ext_uid FROM mf_users WHERE nickname LIKE ?))');
    const like = `%${q}%`;
    params.push(like, like, like, like, like);
  }
  return { sql: where.join(' AND '), params };
}

function recommendOrder(city, uid) {
  // 热度 = 赞*3 + 评*5 + 转发*4 + 浏览*0.1（+ 同城加权），再按「发布小时数+2」线性衰减。
  // 不用 pow()：SQLite 的数学函数并非所有构建都带，线性衰减在这个量级观感已经足够。
  const hot = `(p.base_likes + ${LIKES})*3 + (p.base_comments + ${COMMENTS})*5 + (p.base_shares + ${SHARES})*4 + p.views*0.1`;
  const boost = city ? settings.recommendCityBoost : 0;
  return {
    sql: `(${hot} + CASE WHEN p.city = ? THEN ? ELSE 0 END) / MAX(1.0, (? - p.created_at)/3600000.0 + 2) DESC, p.created_at DESC`,
    params: [city, boost, Date.now()],
  };
}

function register(router) {
  router.get('/v1/feed', (ctx) => {
    const uid = currentUid(ctx.req);
    const rawTab = strParam(ctx.query, 'tab', 16) || 'recommend';
    const tab = TAB_ALIASES[rawTab] || TAB_ALIASES[rawTab.toLowerCase()] || 'recommend';
    const limit = intParam(ctx.query, 'limit', settings.pageDefault, 1, settings.pageMax);
    const offset = intParam(ctx.query, 'cursor', 0, 0, 1_000_000);
    const city = strParam(ctx.query, 'city', 24);
    const tag = strParam(ctx.query, 'tag', 24);
    const q = strParam(ctx.query, 'q', 40);

    if (tab === 'nearby' && !city) throw badRequest('同城流需要 city 参数');

    const where = buildWhere({ tab, uid, city, tag, q });
    let sql = `SELECT p.* FROM mf_posts p WHERE ${where.sql}`;
    let params = [...where.params];

    if (tab === 'recommend') {
      const order = recommendOrder(city, uid);
      sql += ` ORDER BY ${order.sql} LIMIT ? OFFSET ?`;
      params = params.concat(order.params, [limit + 1, offset]);
    } else {
      sql += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
      params = params.concat([limit + 1, offset]);
    }

    const rows = all(sql, ...params);
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    sendJson(ctx.req, ctx.res, 200, {
      tab,
      items: serializePosts(page, uid),
      nextCursor: hasMore ? String(offset + limit) : null,
      hasMore,
    });
  });

  // 公开读：未登录也能看单条（分享链接落地页/预览），带 token 才有个人态
  router.get('/v1/posts/:id', (ctx, params) => {
    const viewer = optionalUid(ctx.req);
    const row = get('SELECT * FROM mf_posts WHERE id = ? AND deleted_at IS NULL', params.id);
    if (!row) {
      ctx.status = 404;
      sendJson(ctx.req, ctx.res, 404, { detail: '内容不存在' });
      return;
    }
    sendJson(ctx.req, ctx.res, 200, serializePosts([row], viewer)[0]);
  }, { auth: false });

  // 同城可选城市：按帖子数排序，给「同城」切换器用
  router.get('/v1/feed/cities', (ctx) => {
    currentUid(ctx.req);
    const rows = all(
      `SELECT city, COUNT(*) c FROM mf_posts
       WHERE deleted_at IS NULL AND city <> '' GROUP BY city ORDER BY c DESC LIMIT 30`,
    );
    sendJson(ctx.req, ctx.res, 200, {
      items: rows.map((r) => ({ city: r.city, posts: Number(r.c) })),
    });
  });
}

module.exports = { register };
