'use strict';
/**
 * 作者页：资料 + 与我的关注关系 + TA 的足迹 + 粉丝/关注列表。
 * 关注是双向可推导的（我关注你 / 你关注我 / 互关），前端按钮态全靠这三个布尔。
 */
const { all, get, run, nowMs } = require('../db');
const { currentUid, ensureUser, rateLimit } = require('../auth');
const { sendJson, intParam, badRequest, notFound } = require('../http');
const { serializePosts, serializeUser } = require('../serialize');

function register(router) {
  router.get('/v1/users/:uid', (ctx) => {
    const viewer = currentUid(ctx.req);
    const uid = Number.parseInt(ctx.params.uid, 10);
    if (!Number.isFinite(uid)) throw badRequest('uid 不合法');
    ensureUser(uid);
    sendJson(ctx.req, ctx.res, 200, serializeUser(uid, viewer));
  });

  router.get('/v1/users/:uid/posts', (ctx) => {
    const viewer = currentUid(ctx.req);
    const uid = Number.parseInt(ctx.params.uid, 10);
    if (!Number.isFinite(uid)) throw badRequest('uid 不合法');
    const limit = intParam(ctx.query, 'limit', 12, 1, 30);
    const offset = intParam(ctx.query, 'cursor', 0, 0, 1_000_000);
    const rows = all(
      'SELECT * FROM mf_posts WHERE author_uid = ? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT ? OFFSET ?',
      uid, limit + 1, offset,
    );
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    sendJson(ctx.req, ctx.res, 200, {
      items: serializePosts(page, viewer),
      nextCursor: hasMore ? String(offset + limit) : null,
      hasMore,
    });
  });

  // 关注 / 取消关注（幂等 toggle）
  router.post('/v1/users/:uid/follow', (ctx) => {
    const viewer = currentUid(ctx.req);
    rateLimit('follow', viewer);
    const uid = Number.parseInt(ctx.params.uid, 10);
    if (!Number.isFinite(uid)) throw badRequest('uid 不合法');
    if (uid === viewer) throw badRequest('不能关注自己');
    ensureUser(uid);

    const exists = get('SELECT 1 FROM mf_follows WHERE follower_uid = ? AND target_uid = ?', viewer, uid);
    if (exists) {
      run('DELETE FROM mf_follows WHERE follower_uid = ? AND target_uid = ?', viewer, uid);
    } else {
      run('INSERT INTO mf_follows(follower_uid, target_uid, created_at) VALUES(?,?,?)', viewer, uid, nowMs());
    }
    const followingHim = !exists;
    const followers = get('SELECT COUNT(*) c FROM mf_follows WHERE target_uid = ?', uid).c;
    const followsMe = get('SELECT 1 FROM mf_follows WHERE follower_uid = ? AND target_uid = ?', uid, viewer);
    sendJson(ctx.req, ctx.res, 200, {
      followingHim,
      followed: followingHim,
      followers: Number(followers),
      followsMe: Boolean(followsMe),
      mutual: followingHim && Boolean(followsMe),
    });
  });

  router.get('/v1/users/:uid/followers', (ctx) => {
    const viewer = currentUid(ctx.req);
    const uid = Number.parseInt(ctx.params.uid, 10);
    if (!Number.isFinite(uid)) throw badRequest('uid 不合法');
    const limit = intParam(ctx.query, 'limit', 50, 1, 100);
    const rows = all(
      `SELECT u.ext_uid AS uid, u.nickname, u.avatar_url, u.bio,
              EXISTS(SELECT 1 FROM mf_follows f2 WHERE f2.follower_uid = ? AND f2.target_uid = u.ext_uid) AS i_follow
         FROM mf_follows f JOIN mf_users u ON u.ext_uid = f.follower_uid
        WHERE f.target_uid = ? ORDER BY f.created_at DESC LIMIT ?`,
      viewer, uid, limit,
    );
    sendJson(ctx.req, ctx.res, 200, {
      items: rows.map((r) => ({
        id: Number(r.uid),
        name: r.nickname,
        avatarText: (r.nickname || '·').slice(0, 1),
        avatarPath: r.avatar_url,
        bio: r.bio || '',
        following: Boolean(r.i_follow),
      })),
    });
  });

  router.get('/v1/users/:uid/following', (ctx) => {
    const viewer = currentUid(ctx.req);
    const uid = Number.parseInt(ctx.params.uid, 10);
    if (!Number.isFinite(uid)) throw badRequest('uid 不合法');
    const limit = intParam(ctx.query, 'limit', 50, 1, 100);
    const rows = all(
      `SELECT u.ext_uid AS uid, u.nickname, u.avatar_url, u.bio,
              EXISTS(SELECT 1 FROM mf_follows f2 WHERE f2.follower_uid = ? AND f2.target_uid = u.ext_uid) AS i_follow
         FROM mf_follows f JOIN mf_users u ON u.ext_uid = f.target_uid
        WHERE f.follower_uid = ? ORDER BY f.created_at DESC LIMIT ?`,
      viewer, uid, limit,
    );
    sendJson(ctx.req, ctx.res, 200, {
      items: rows.map((r) => ({
        id: Number(r.uid),
        name: r.nickname,
        avatarText: (r.nickname || '·').slice(0, 1),
        avatarPath: r.avatar_url,
        bio: r.bio || '',
        following: Boolean(r.i_follow),
      })),
    });
  });

  // 我的收藏列表（「我的」页二级入口用）
  router.get('/v1/me/favorites', (ctx) => {
    const uid = currentUid(ctx.req);
    const limit = intParam(ctx.query, 'limit', 12, 1, 30);
    const offset = intParam(ctx.query, 'cursor', 0, 0, 1_000_000);
    const rows = all(
      `SELECT p.* FROM mf_favs f JOIN mf_posts p ON p.id = f.post_id
        WHERE f.uid = ? AND p.deleted_at IS NULL
        ORDER BY f.created_at DESC LIMIT ? OFFSET ?`,
      uid, limit + 1, offset,
    );
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    sendJson(ctx.req, ctx.res, 200, {
      items: serializePosts(page, uid),
      nextCursor: hasMore ? String(offset + limit) : null,
      hasMore,
    });
  });

  router.get('/v1/me/posts', (ctx) => {
    const uid = currentUid(ctx.req);
    const rows = all(
      'SELECT * FROM mf_posts WHERE author_uid = ? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 100',
      uid,
    );
    sendJson(ctx.req, ctx.res, 200, { items: serializePosts(rows, uid) });
  });
}

module.exports = { register };
