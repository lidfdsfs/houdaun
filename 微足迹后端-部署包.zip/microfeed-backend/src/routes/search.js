'use strict';
/** 搜索与热门话题：话题不做独立表，直接从帖子的 tags 聚合，避免两套数据不一致 */
const { all } = require('../db');
const { currentUid } = require('../auth');
const { sendJson, intParam, strParam } = require('../http');
const { serializePosts, jsonList } = require('../serialize');

function register(router) {
  router.get('/v1/search', (ctx) => {
    const uid = currentUid(ctx.req);
    const q = strParam(ctx.query, 'q', 40);
    const limit = intParam(ctx.query, 'limit', 12, 1, 30);
    if (!q) {
      sendJson(ctx.req, ctx.res, 200, { q: '', posts: [], users: [], tags: [] });
      return;
    }
    const like = `%${q}%`;
    const posts = all(
      `SELECT p.* FROM mf_posts p
        WHERE p.deleted_at IS NULL
          AND (p.caption LIKE ? OR p.place LIKE ? OR p.city LIKE ? OR p.tags LIKE ?
               OR p.author_uid IN (SELECT ext_uid FROM mf_users WHERE nickname LIKE ?))
        ORDER BY p.created_at DESC LIMIT ?`,
      like, like, like, like, like, limit,
    );
    const users = all(
      `SELECT ext_uid, nickname, avatar_url, bio FROM mf_users
        WHERE nickname LIKE ? OR bio LIKE ? ORDER BY updated_at DESC LIMIT ?`,
      like, like, Math.min(limit, 10),
    );
    const tags = all(
      `SELECT tags FROM mf_posts WHERE deleted_at IS NULL AND tags LIKE ? LIMIT 200`,
      `%${q}%`,
    );
    const tagCount = new Map();
    for (const row of tags) {
      for (const tag of jsonList(row.tags)) {
        if (typeof tag === 'string' && tag.includes(q)) {
          tagCount.set(tag, (tagCount.get(tag) || 0) + 1);
        }
      }
    }
    sendJson(ctx.req, ctx.res, 200, {
      q,
      posts: serializePosts(posts, uid),
      users: users.map((u) => ({
        id: Number(u.ext_uid),
        name: u.nickname,
        avatarText: (u.nickname || '·').slice(0, 1),
        avatarPath: u.avatar_url,
        bio: u.bio || '',
      })),
      tags: [...tagCount.entries()]
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([tag, count]) => ({ tag, posts: count })),
    });
  });

  // 热门话题：近 30 天帖子的 tags 聚合；没有数据时用空数组，客户端回落到本地示例
  router.get('/v1/tags/trending', (ctx) => {
    currentUid(ctx.req);
    const since = Date.now() - 30 * 24 * 3600 * 1000;
    const rows = all(
      'SELECT tags FROM mf_posts WHERE deleted_at IS NULL AND created_at >= ? LIMIT 500',
      since,
    );
    const counts = new Map();
    for (const row of rows) {
      for (const tag of jsonList(row.tags)) {
        if (typeof tag === 'string' && tag) counts.set(tag, (counts.get(tag) || 0) + 1);
      }
    }
    sendJson(ctx.req, ctx.res, 200, {
      items: [...counts.entries()]
        .sort((a, b) => b[1] - a[1])
        .slice(0, 20)
        .map(([tag, posts]) => ({ tag, posts })),
    });
  });
}

module.exports = { register };
