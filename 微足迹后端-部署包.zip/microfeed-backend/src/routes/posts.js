'use strict';
/**
 * 帖子：发布 / 撤回 + 全部单条互动（赞、收藏、分享、不感兴趣、浏览、举报）。
 *
 * 所有 toggle 都用「主键冲突即幂等」的写法：重复点赞不会把计数刷大，
 * 客户端重试也不会重复扣数。
 */
const crypto = require('node:crypto');
const { settings } = require('../config');
const { all, get, run, tx, nowMs } = require('../db');
const { currentUid, optionalUid, ensureUser, rateLimit } = require('../auth');
const { sendJson, readJson, cleanText, badRequest, notFound, forbidden } = require('../http');
const { serializePosts, serializeComments } = require('../serialize');

function parseTags(raw) {
  if (!Array.isArray(raw)) return [];
  const out = [];
  for (const item of raw) {
    if (typeof item !== 'string') continue;
    const tag = item.trim().replace(/^#+/, '').slice(0, 24);
    if (tag && !out.includes(tag)) out.push(tag);
    if (out.length >= settings.tagsMax) break;
  }
  return out;
}

function parseMedia(raw) {
  if (!Array.isArray(raw)) return [];
  const out = [];
  for (const item of raw) {
    if (!item || typeof item !== 'object') continue;
    const type = String(item.type || '').toLowerCase();
    const url = String(item.url || '').trim();
    if (!['image', 'video', 'audio'].includes(type)) continue;
    // 只接受本服务上传后的地址，或明确的外部 https 地址（导入历史数据用）
    const ok = url.startsWith('/media/') || url.startsWith('https://');
    if (!ok) continue;
    out.push({ type, url: url.slice(0, 512) });
    if (out.length >= 12) break;
  }
  return out;
}

function requirePost(id) {
  const row = get('SELECT * FROM mf_posts WHERE id = ? AND deleted_at IS NULL', id);
  if (!row) throw notFound('内容不存在');
  return row;
}

function register(router) {
  // 发布：媒体先走 /v1/media 上传，这里只收 URL，避免大请求体里混着 JSON
  router.post('/v1/posts', async (ctx) => {
    const uid = currentUid(ctx.req);
    ensureUser(uid);
    rateLimit('post', uid);
    const body = await readJson(ctx.req, 256 * 1024);

    const caption = cleanText(body.caption, settings.captionMax);
    const media = parseMedia(body.media);
    if (!caption && media.length === 0) throw badRequest('文案和媒体不能都为空');

    const id = crypto.randomUUID();
    const ts = nowMs();
    const lat = Number(body.lat);
    const lon = Number(body.lon);
    run(
      `INSERT INTO mf_posts(id, author_uid, place, city, caption, tags, media, bgm_title, bgm_artist, bgm_url,
                            lat, lon, created_at)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      id,
      uid,
      cleanText(body.place, 48),
      cleanText(body.city, 24),
      caption,
      JSON.stringify(parseTags(body.tags)),
      JSON.stringify(media),
      cleanText(body.bgmTitle, 64) || null,
      cleanText(body.bgmArtist, 48) || null,
      typeof body.bgmUrl === 'string' && body.bgmUrl.startsWith('/media/') ? body.bgmUrl.slice(0, 512) : null,
      Number.isFinite(lat) ? lat : null,
      Number.isFinite(lon) ? lon : null,
      ts,
    );

    const row = get('SELECT * FROM mf_posts WHERE id = ?', id);
    sendJson(ctx.req, ctx.res, 201, serializePosts([row], uid)[0]);
  });

  // 撤回：软删除。作者本人可删；管理员可代删（MF_ADMIN_UIDS）
  router.delete('/v1/posts/:id', (ctx) => {
    const uid = currentUid(ctx.req);
    const row = requirePost(ctx.params.id);
    const isAdmin = settings.adminUids.includes(uid);
    if (Number(row.author_uid) !== uid && !isAdmin) throw forbidden('只能撤回自己的足迹');
    run('UPDATE mf_posts SET deleted_at = ? WHERE id = ?', nowMs(), ctx.params.id);
    sendJson(ctx.req, ctx.res, 200, { ok: true, id: ctx.params.id });
  });

  // 点赞 / 取消
  router.post('/v1/posts/:id/like', (ctx) => {
    const uid = currentUid(ctx.req);
    rateLimit('like', uid);
    requirePost(ctx.params.id);
    const liked = tx(() => {
      const exists = get('SELECT 1 FROM mf_likes WHERE post_id = ? AND uid = ?', ctx.params.id, uid);
      if (exists) {
        run('DELETE FROM mf_likes WHERE post_id = ? AND uid = ?', ctx.params.id, uid);
        return false;
      }
      run('INSERT INTO mf_likes(post_id, uid, created_at) VALUES(?,?,?)', ctx.params.id, uid, nowMs());
      return true;
    });
    const row = get('SELECT base_likes FROM mf_posts WHERE id = ?', ctx.params.id);
    const count = get('SELECT COUNT(*) c FROM mf_likes WHERE post_id = ?', ctx.params.id).c;
    sendJson(ctx.req, ctx.res, 200, { liked, likes: Number(row.base_likes) + Number(count) });
  });

  // 收藏 / 取消
  router.post('/v1/posts/:id/favorite', (ctx) => {
    const uid = currentUid(ctx.req);
    requirePost(ctx.params.id);
    const favored = tx(() => {
      const exists = get('SELECT 1 FROM mf_favs WHERE post_id = ? AND uid = ?', ctx.params.id, uid);
      if (exists) {
        run('DELETE FROM mf_favs WHERE post_id = ? AND uid = ?', ctx.params.id, uid);
        return false;
      }
      run('INSERT INTO mf_favs(post_id, uid, created_at) VALUES(?,?,?)', ctx.params.id, uid, nowMs());
      return true;
    });
    const favorites = get('SELECT COUNT(*) c FROM mf_favs WHERE post_id = ?', ctx.params.id).c;
    sendJson(ctx.req, ctx.res, 200, { favored, favorites: Number(favorites) });
  });

  // 分享：同一用户对同一帖只记一次（防抖），返回可复制的落地链接
  router.post('/v1/posts/:id/share', (ctx) => {
    const uid = currentUid(ctx.req);
    requirePost(ctx.params.id);
    run(
      'INSERT OR IGNORE INTO mf_shares(post_id, uid, created_at) VALUES(?,?,?)',
      ctx.params.id, uid, nowMs(),
    );
    const row = get('SELECT base_shares FROM mf_posts WHERE id = ?', ctx.params.id);
    const count = get('SELECT COUNT(*) c FROM mf_shares WHERE post_id = ?', ctx.params.id).c;
    sendJson(ctx.req, ctx.res, 200, {
      shared: true,
      shares: Number(row.base_shares) + Number(count),
      shareUrl: `/v1/posts/${ctx.params.id}`,
    });
  });

  // 不感兴趣：只影响自己的推荐流，不移除作者的帖子
  router.post('/v1/posts/:id/hide', (ctx) => {
    const uid = currentUid(ctx.req);
    requirePost(ctx.params.id);
    run('INSERT OR IGNORE INTO mf_hides(post_id, uid, created_at) VALUES(?,?,?)', ctx.params.id, uid, nowMs());
    sendJson(ctx.req, ctx.res, 200, { hidden: true });
  });

  // 浏览：同一用户对同一帖只计一次，避免刷量
  router.post('/v1/posts/:id/view', (ctx) => {
    const uid = currentUid(ctx.req);
    requirePost(ctx.params.id);
    const inserted = run(
      'INSERT OR IGNORE INTO mf_views(post_id, uid, created_at) VALUES(?,?,?)',
      ctx.params.id, uid, nowMs(),
    );
    if (Number(inserted.changes) > 0) {
      run('UPDATE mf_posts SET views = views + 1 WHERE id = ?', ctx.params.id);
    }
    sendJson(ctx.req, ctx.res, 200, { ok: true });
  });

  // 举报：只落库给运营，不自动下架（避免被恶意举报打击）
  router.post('/v1/posts/:id/report', async (ctx) => {
    const uid = currentUid(ctx.req);
    rateLimit('report', uid);
    requirePost(ctx.params.id);
    const body = await readJson(ctx.req, 8 * 1024);
    run(
      'INSERT INTO mf_reports(id, post_id, comment_id, uid, reason, created_at) VALUES(?,?,?,?,?,?)',
      crypto.randomUUID(), ctx.params.id, null, uid, cleanText(body.reason, 200), nowMs(),
    );
    sendJson(ctx.req, ctx.res, 200, { ok: true });
  });

  // 单条评论列表（登录后才有 deletable/liked；匿名读只是没有个人态）
  router.get('/v1/posts/:id/comments', (ctx) => {
    const viewer = optionalUid(ctx.req);
    requirePost(ctx.params.id);
    const limit = Math.min(Math.max(Number.parseInt(ctx.query.get('limit') || '50', 10) || 50, 1), 100);
    const offset = Math.max(Number.parseInt(ctx.query.get('cursor') || '0', 10) || 0, 0);
    const rows = all(
      'SELECT * FROM mf_comments WHERE post_id = ? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT ? OFFSET ?',
      ctx.params.id, limit + 1, offset,
    );
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    sendJson(ctx.req, ctx.res, 200, {
      items: serializeComments(page, viewer),
      nextCursor: hasMore ? String(offset + limit) : null,
      hasMore,
    });
  });

  // 发表评论 / 回复
  router.post('/v1/posts/:id/comments', async (ctx) => {
    const uid = currentUid(ctx.req);
    ensureUser(uid);
    rateLimit('comment', uid);
    requirePost(ctx.params.id);
    const body = await readJson(ctx.req, 16 * 1024);
    const text = cleanText(body.text, settings.commentMax);
    if (!text) throw badRequest('评论不能为空');
    const id = crypto.randomUUID();
    run(
      'INSERT INTO mf_comments(id, post_id, uid, body, reply_to, created_at) VALUES(?,?,?,?,?,?)',
      id, ctx.params.id, uid, text, cleanText(body.replyTo, 64) || null, nowMs(),
    );
    const row = get('SELECT * FROM mf_comments WHERE id = ?', id);
    const total = get('SELECT COUNT(*) c FROM mf_comments WHERE post_id = ? AND deleted_at IS NULL', ctx.params.id).c;
    sendJson(ctx.req, ctx.res, 201, {
      comment: serializeComments([row], uid)[0],
      commentCount: Number(total),
    });
  });

  // 删除自己的评论
  router.delete('/v1/comments/:id', (ctx) => {
    const uid = currentUid(ctx.req);
    const row = get('SELECT * FROM mf_comments WHERE id = ? AND deleted_at IS NULL', ctx.params.id);
    if (!row) throw notFound('评论不存在');
    if (Number(row.uid) !== uid && !settings.adminUids.includes(uid)) throw forbidden('只能删除自己的评论');
    run('UPDATE mf_comments SET deleted_at = ? WHERE id = ?', nowMs(), ctx.params.id);
    sendJson(ctx.req, ctx.res, 200, { ok: true, id: ctx.params.id });
  });

  // 评论点赞
  router.post('/v1/comments/:id/like', (ctx) => {
    const uid = currentUid(ctx.req);
    const row = get('SELECT * FROM mf_comments WHERE id = ? AND deleted_at IS NULL', ctx.params.id);
    if (!row) throw notFound('评论不存在');
    const liked = tx(() => {
      const exists = get('SELECT 1 FROM mf_comment_likes WHERE comment_id = ? AND uid = ?', ctx.params.id, uid);
      if (exists) {
        run('DELETE FROM mf_comment_likes WHERE comment_id = ? AND uid = ?', ctx.params.id, uid);
        return false;
      }
      run('INSERT INTO mf_comment_likes(comment_id, uid, created_at) VALUES(?,?,?)', ctx.params.id, uid, nowMs());
      return true;
    });
    const likes = get('SELECT COUNT(*) c FROM mf_comment_likes WHERE comment_id = ?', ctx.params.id).c;
    sendJson(ctx.req, ctx.res, 200, { liked, likes: Number(likes) });
  });
}

module.exports = { register };
