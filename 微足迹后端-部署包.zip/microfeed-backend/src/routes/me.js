'use strict';
/** 个人资料与统计：微足迹侧的「我是谁」 */

const { settings } = require('../config');
const { get, run, nowMs } = require('../db');
const { currentUid, ensureUser } = require('../auth');
const { sendJson, readJson, cleanText, badRequest } = require('../http');
const { serializeUser } = require('../serialize');

function register(router) {
  // 我的资料（首次访问即建档，昵称占位）
  router.get('/v1/me', (ctx) => {
    const uid = currentUid(ctx.req);
    ensureUser(uid);
    sendJson(ctx.req, ctx.res, 200, serializeUser(uid, uid));
  });

  // App 登录后把主后端的昵称/头像/签名推过来：微足迹服务只存展示用的副本
  router.put('/v1/me', async (ctx) => {
    const uid = currentUid(ctx.req);
    ensureUser(uid);
    const body = await readJson(ctx.req, 64 * 1024);
    const nickname = cleanText(body.nickname, 32);
    const bio = cleanText(body.bio, 120);
    const avatarUrl = typeof body.avatarUrl === 'string' ? body.avatarUrl.trim().slice(0, 512) : '';
    if (nickname === '' && avatarUrl === '' && bio === '') throw badRequest('没有要更新的内容');
    run(
      `UPDATE mf_users SET
         nickname = CASE WHEN ? <> '' THEN ? ELSE nickname END,
         bio      = CASE WHEN ? <> '' THEN ? ELSE bio END,
         avatar_url = CASE WHEN ? <> '' THEN ? ELSE avatar_url END,
         updated_at = ?
       WHERE ext_uid = ?`,
      nickname, nickname, bio, bio, avatarUrl, avatarUrl, nowMs(), uid,
    );
    sendJson(ctx.req, ctx.res, 200, serializeUser(uid, uid));
  });

  // 我的汇总：个人页顶部那几个数字
  router.get('/v1/me/stats', (ctx) => {
    const uid = currentUid(ctx.req);
    ensureUser(uid);
    const posts = get('SELECT COUNT(*) c FROM mf_posts WHERE author_uid = ? AND deleted_at IS NULL', uid).c;
    const likes = get(
      'SELECT COUNT(*) c FROM mf_likes l JOIN mf_posts p ON p.id = l.post_id WHERE p.author_uid = ? AND p.deleted_at IS NULL',
      uid,
    ).c;
    const followers = get('SELECT COUNT(*) c FROM mf_follows WHERE target_uid = ?', uid).c;
    const following = get('SELECT COUNT(*) c FROM mf_follows WHERE follower_uid = ?', uid).c;
    const views = get('SELECT COALESCE(SUM(views),0) v FROM mf_posts WHERE author_uid = ? AND deleted_at IS NULL', uid).v;
    sendJson(ctx.req, ctx.res, 200, {
      posts: Number(posts), likesReceived: Number(likes),
      followers: Number(followers), following: Number(following),
      views: Number(views),
      serverTime: nowMs(),
      limits: {
        captionMax: settings.captionMax,
        commentMax: settings.commentMax,
        tagsMax: settings.tagsMax,
        maxImageBytes: settings.maxImageBytes,
        maxVideoBytes: settings.maxVideoBytes,
        maxAudioBytes: settings.maxAudioBytes,
      },
    });
  });
}

module.exports = { register };
