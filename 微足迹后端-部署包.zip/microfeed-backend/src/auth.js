'use strict';
/**
 * 鉴权：只验签，不签发、不存密码。
 *
 * 主后端（7070）负责登录并签发 JWT；本服务用同一个 SECRET_KEY 验签，`sub` 即用户 id。
 * 好处：用户不必在微足迹里二次登录；本服务不读主后端用户表，部署上真正独立；
 * 主后端改密/封号让 token 失效后，这里的 token 也自然失效。
 *
 * MF_AUTH_MODE=dev：不校验 token，任何请求都映射到 MF_DEV_UID，仅本地试跑用。
 */
const crypto = require('node:crypto');
const { settings } = require('./config');
const { all, get, run, nowMs } = require('./db');
const { unauthorized } = require('./http');

const ALGOS = { HS256: 'sha256', HS384: 'sha384', HS512: 'sha512' };

function b64url(input) {
  return Buffer.from(String(input).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
}

function verifyJwt(token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw unauthorized('登录凭证无效');
  const [rawHeader, rawPayload, rawSig] = parts;

  let header;
  let payload;
  try {
    header = JSON.parse(b64url(rawHeader).toString('utf8'));
    payload = JSON.parse(b64url(rawPayload).toString('utf8'));
  } catch {
    throw unauthorized('登录凭证无效');
  }

  const hash = ALGOS[String(header.alg || '').toUpperCase()];
  if (!hash) throw unauthorized('登录凭证算法不受支持');

  const actual = b64url(rawSig);
  const input = `${rawHeader}.${rawPayload}`;
  // 多密钥并列验签：主后端的 key 可以用 MF_SECRET_KEY_EXTRA 追加进来，
  // 不必改主后端、也不必让用户重新登录。任一匹配即通过。
  const ok = settings.jwtSecrets().some((secret) => {
    const expected = crypto.createHmac(hash, secret).update(input).digest();
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  });
  if (!ok) throw unauthorized('登录凭证无效');

  const nowSec = Math.floor(Date.now() / 1000);
  if (payload.iss && payload.iss !== settings.jwtIssuer) throw unauthorized('登录凭证签发方不匹配');
  if (typeof payload.exp !== 'number' || payload.exp <= nowSec) throw unauthorized('登录已过期，请重新登录');
  if (typeof payload.iat === 'number' && payload.iat > nowSec + 300) throw unauthorized('登录凭证无效');
  if (payload.typ && payload.typ !== 'user') throw unauthorized('登录凭证类型不匹配');
  if (!Number.isFinite(Number(payload.sub))) throw unauthorized('登录凭证无效');

  return payload;
}

function bearer(req) {
  const raw = req.headers.authorization || '';
  if (!raw.toLowerCase().startsWith('bearer ')) return '';
  return raw.slice(7).trim();
}

/** 必须登录 */
function currentUid(req) {
  if (settings.authMode === 'dev') return settings.devUid;
  const token = bearer(req);
  if (!token) throw unauthorized();
  return Number(verifyJwt(token).sub);
}

/** 公开可读接口：没登录返回 null，登录了就带「我点过赞吗」这类个人态 */
function optionalUid(req) {
  if (settings.authMode === 'dev') return settings.devUid;
  const token = bearer(req);
  if (!token) return null;
  try {
    return Number(verifyJwt(token).sub);
  } catch {
    return null;
  }
}

/** 首次出现即建档，昵称先占位，App 随后 PUT /v1/me 推真实资料 */
function ensureUser(uid, profile = null) {
  const existing = get('SELECT ext_uid FROM mf_users WHERE ext_uid = ?', uid);
  const ts = nowMs();
  if (!existing) {
    run(
      'INSERT INTO mf_users(ext_uid, nickname, avatar_url, bio, verified, created_at, updated_at) VALUES(?,?,?,?,?,?,?)',
      uid,
      (profile && profile.nickname) || `足迹用户${uid}`,
      (profile && profile.avatarUrl) || null,
      (profile && profile.bio) || '',
      0,
      ts,
      ts,
    );
  }
}

// ---------------- 轻量限流 ----------------
// 单进程内存计数即可：写接口本就不该被脚本刷。多实例部署时是「每实例」限额，
// 需要全局严格限流请交给网关（deploy/nginx.conf.example 里有 limit_req 示例）。
const WINDOW_MS = 60_000;
const buckets = new Map();
const LIMITS = { post: 6, comment: 20, like: 120, follow: 60, media: 20, report: 10 };

function rateLimit(action, uid) {
  const limit = LIMITS[action];
  if (!limit) return;
  const key = `${action}:${uid}`;
  const now = Date.now();
  const hits = (buckets.get(key) || []).filter((t) => now - t < WINDOW_MS);
  if (hits.length >= limit) {
    const err = new Error('操作太频繁，请稍后再试');
    err.status = 429;
    throw err;
  }
  hits.push(now);
  buckets.set(key, hits);
}

/** 关注集合，供 feed/作者页复用 */
function followingSet(uid, candidates) {
  if (!uid || !candidates || candidates.length === 0) return new Set();
  const marks = candidates.map(() => '?').join(',');
  const rows = all(
    `SELECT target_uid FROM mf_follows WHERE follower_uid = ? AND target_uid IN (${marks})`,
    uid,
    ...candidates,
  );
  return new Set(rows.map((r) => Number(r.target_uid)));
}

module.exports = { verifyJwt, currentUid, optionalUid, ensureUser, rateLimit, followingSet };
