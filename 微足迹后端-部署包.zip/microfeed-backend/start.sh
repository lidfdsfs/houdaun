#!/usr/bin/env bash
# 微足迹独立服务启动脚本（Linux / macOS）
# 用法：./start.sh          前台运行
#       ./start.sh daemon   后台运行（日志写 logs/server.log）
set -euo pipefail

cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "未找到 node。请先安装 Node.js 24（>= 22.5 才带内置 SQLite）。" >&2
  exit 1
fi

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
NODE_MINOR="$(node -p 'process.versions.node.split(".")[1]')"
if [ "$NODE_MAJOR" -lt 22 ] || { [ "$NODE_MAJOR" -eq 22 ] && [ "$NODE_MINOR" -lt 5 ]; }; then
  echo "当前 Node $(node -v) 过低：node:sqlite 需要 Node >= 22.5，建议 24 LTS。" >&2
  exit 1
fi

if [ ! -f .env ]; then
  cp .env.example .env
  echo "已从 .env.example 生成 .env，请填写 MF_SECRET_KEY（必须与主后端一致）后再启动。"
fi

mkdir -p data storage logs

# 只把 .env 里的键值注入环境，不 source，避免值里有空格/特殊字符时被 shell 解释
if [ -f .env ]; then
  while IFS='=' read -r key value; do
    case "$key" in ''|\#*) continue ;; esac
    key="$(echo "$key" | tr -d '[:space:]')"
    [ -z "$key" ] && continue
    export "$key=$value"
  done < .env
fi

if [ "${1:-}" = "daemon" ]; then
  nohup node --no-warnings src/server.js >> logs/server.log 2>&1 &
  echo "已后台启动，PID $!，日志：logs/server.log"
else
  exec node --no-warnings src/server.js
fi
