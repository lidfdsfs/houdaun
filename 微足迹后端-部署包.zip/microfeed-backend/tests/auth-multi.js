'use strict';
/**
 * 多密钥验签回归：shared 模式下必须同时接受 MF_SECRET_KEY 与 MF_SECRET_KEY_EXTRA 里的每一把 key。
 *
 * 这条链路最容易「看起来通了实际没通」：App 拿主后端 token 请求，若微足迹只认自己那把 key，
 * 全程 401 并静默回落本地池，界面上只显示「未连接」，完全看不出是密钥问题。
 * 所以这里直接签发多把 key 的 token，逐把验证放行 / 拒绝。
 *
 * 用法：node --no-warnings tests/auth-multi.js
 */
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const PORT = Number(process.env.AUTH_PORT || 7098);
const BASE = `http://127.0.0.1:${PORT}`;
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mf-auth-'));

const KEY_A = 'key-owner-service-aaaaaaaaaaaaaaaaaaaa';
const KEY_B = 'key-main-backend-bbbbbbbbbbbbbbbbbbbbb';
const KEY_C = 'key-rotating-cccccccccccccccccccccccc';
const KEY_X = 'key-not-configured-xxxxxxxxxxxxxxxxxxx';

let passed = 0;
const failures = [];

function ok(name, cond, extra) {
  if (cond) {
    passed += 1;
    console.log(`  ✓ ${name}`);
  } else {
    failures.push(name);
    console.log(`  ✗ ${name}${extra ? ` -> ${JSON.stringify(extra)}` : ''}`);
  }
}

function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/** 现场签一枚 HS256 token，模拟主后端的签发结果 */
function sign(secret, { uid = 1001, expOffsetSec = 3600, iss = 'myzuji-backend', typ = 'user' } = {}) {
  const header = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(
    JSON.stringify({ sub: uid, iat: now, exp: now + expOffsetSec, iss, typ }),
  );
  const sig = crypto.createHmac('sha256', secret).update(`${header}.${payload}`).digest();
  return `${header}.${payload}.${b64url(sig)}`;
}

async function me(token) {
  const headers = { Accept: 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${BASE}/v1/me`, { headers });
  const text = await res.text();
  let json = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = text;
  }
  return { status: res.status, body: json };
}

function startServer() {
  const child = spawn(process.execPath, ['--no-warnings', path.join(__dirname, '..', 'src', 'server.js')], {
    env: {
      ...process.env,
      MF_AUTH_MODE: 'shared',
      MF_SECRET_KEY: KEY_A,
      MF_SECRET_KEY_EXTRA: `${KEY_B},${KEY_C}`,
      MF_PORT: String(PORT),
      MF_DATA_DIR: path.join(TMP, 'data'),
      MF_STORAGE_DIR: path.join(TMP, 'storage'),
      MF_SEED_ON_START: '0',
      MF_LOG_LEVEL: 'warn',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.on('data', () => {});
  child.stderr.on('data', () => {});
  return child;
}

async function waitHealthy(timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`${BASE}/healthz`);
      if (res.ok) return true;
    } catch {
      /* 还没起来 */
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  return false;
}

(async () => {
  const server = startServer();
  try {
    ok('服务按时启动', await waitHealthy());

    console.log('\n[多密钥放行]');
    const a = await me(sign(KEY_A));
    ok('MF_SECRET_KEY 本服务的 key 通过', a.status === 200, a.status);
    const b = await me(sign(KEY_B));
    ok('主后端 key（EXTRA 第一把）通过', b.status === 200, b.status);
    const c = await me(sign(KEY_C));
    ok('轮换 key（EXTRA 第二把）通过', c.status === 200, c.status);
    ok('三把 key 映射到同一个 ext_uid', 
      a.body?.id !== undefined && b.body?.id !== undefined,
      { a: a.body, b: b.body });

    console.log('\n[拒绝非法凭证]');
    const x = await me(sign(KEY_X));
    ok('未配置的 key 被拒 401', x.status === 401, x.status);
    const none = await me(null);
    ok('无 token 被拒 401', none.status === 401, none.status);
    const expired = await me(sign(KEY_B, { expOffsetSec: -60 }));
    ok('过期 token 被拒 401', expired.status === 401, expired.status);
    const wrongIss = await me(sign(KEY_B, { iss: 'someone-else' }));
    ok('签发方不匹配被拒 401', wrongIss.status === 401, wrongIss.status);
    const wrongTyp = await me(sign(KEY_B, { typ: 'admin' }));
    ok('凭证类型不匹配被拒 401', wrongTyp.status === 401, wrongTyp.status);
    const tampered = `${sign(KEY_X).split('.').slice(0, 2).join('.')}.${b64url(crypto.randomBytes(32))}`;
    ok('签名被篡改被拒 401', (await me(tampered)).status === 401);

    console.log('\n[public 读接口不因缺 token 报错]');
    const meta = await fetch(`${BASE}/v1/meta`);
    ok('/v1/meta 公开可读', meta.status === 200, meta.status);

    console.log(`\n结果：通过 ${passed} 项，失败 ${failures.length} 项`);
    if (failures.length) {
      console.log('失败项：', failures.join(' / '));
      process.exitCode = 1;
    } else {
      console.log('全部通过 ✅');
    }
  } finally {
    server.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 300));
    fs.rmSync(TMP, { recursive: true, force: true });
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
