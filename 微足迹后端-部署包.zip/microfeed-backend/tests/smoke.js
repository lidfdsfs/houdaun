'use strict';
/**
 * 端到端冒烟：真的起一个服务进程，把微足迹用到的**每一个**接口都打一遍。
 *
 * 覆盖：元信息 / 资料 / 四条 feed / 发布 / 媒体上传与 Range 读取 / 点赞·收藏·
 * 分享·浏览·不感兴趣 / 评论增删赞 / 关注与作者页 / 搜索 / 热门话题 / 撤回 / 404。
 *
 * 用法：npm run smoke
 * 退出码非 0 表示有断言失败，可直接接进 CI。
 */
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert');

const PORT = Number(process.env.SMOKE_PORT || 7099);
const BASE = `http://127.0.0.1:${PORT}`;
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mf-smoke-'));

let passed = 0;
const failures = [];

function ok(name, cond, extra) {
  if (cond) {
    passed += 1;
    console.log(`  ✓ ${name}`);
  } else {
    failures.push(name);
    console.log(`  ✗ ${name}${extra ? ` -> ${JSON.stringify(extra)}` : ''}`);
  }
}

async function call(method, url, { body, headers = {}, raw } = {}) {
  const init = { method, headers: { ...headers } };
  if (raw) {
    init.body = raw;
  } else if (body !== undefined) {
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  if (process.env.SMOKE_TOKEN) init.headers.Authorization = `Bearer ${process.env.SMOKE_TOKEN}`;
  const res = await fetch(`${BASE}${url}`, init);
  const text = await res.text();
  let json = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = text;
  }
  return { status: res.status, body: json, headers: res.headers };
}

function startServer() {
  const child = spawn(process.execPath, ['--no-warnings', path.join(__dirname, '..', 'src', 'server.js')], {
    env: {
      ...process.env,
      MF_AUTH_MODE: 'dev',
      MF_DEV_UID: '1001',
      MF_PORT: String(PORT),
      MF_DATA_DIR: path.join(TMP, 'data'),
      MF_STORAGE_DIR: path.join(TMP, 'storage'),
      MF_SEED_ON_START: '1',
      MF_LOG_LEVEL: 'warn',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.on('data', () => {});
  child.stderr.on('data', (d) => process.stderr.write(`[server] ${d}`));
  return child;
}

async function waitReady(timeoutMs = 15000) {
  const began = Date.now();
  while (Date.now() - began < timeoutMs) {
    try {
      const res = await fetch(`${BASE}/healthz`);
      if (res.ok) return true;
    } catch { /* 还没起来 */ }
    await new Promise((r) => setTimeout(r, 200));
  }
  return false;
}

async function main() {
  console.log(`\n微足迹服务冒烟测试（临时目录 ${TMP}）\n`);
  const server = startServer();
  try {
    if (!(await waitReady())) throw new Error('服务未在 15 秒内就绪');

    console.log('[基础设施]');
    const health = await call('GET', '/healthz');
    ok('healthz 200 且 db ok', health.status === 200 && health.body.db === true, health.body);
    const ping = await call('GET', '/ping');
    ok('ping 返回服务名', ping.status === 200 && !!ping.body.service, ping.body);
    const meta = await call('GET', '/v1/meta');
    ok('meta 返回四条 feed tab', meta.body?.features?.feedTabs?.length === 4, meta.body);
    ok('meta 带上传上限', meta.body?.limits?.maxVideoBytes > 0, meta.body?.limits);

    console.log('[资料]');
    const me = await call('GET', '/v1/me');
    ok('GET /v1/me 自动建档', me.status === 200 && me.body.id === 1001, me.body);
    const put = await call('PUT', '/v1/me', { body: { nickname: '冒烟测试号', bio: '自动化测试', avatarUrl: '' } });
    ok('PUT /v1/me 更新昵称', put.status === 200 && put.body.name === '冒烟测试号', put.body);
    const stats = await call('GET', '/v1/me/stats');
    ok('stats 返回计数与限额', stats.status === 200 && typeof stats.body.posts === 'number', stats.body);

    console.log('[信息流]');
    const recommend = await call('GET', '/v1/feed?tab=recommend&limit=5');
    ok('推荐流有内容（演示数据）', recommend.status === 200 && recommend.body.items.length >= 5, recommend.body?.items?.length);
    ok('推荐流带作者与图片', !!recommend.body.items[0]?.author?.name && recommend.body.items[0].imagePaths.length > 0, recommend.body.items[0]);
    ok('推荐流分页游标', typeof recommend.body.nextCursor === 'string', recommend.body.nextCursor);
    const nearby = await call('GET', '/v1/feed?tab=nearby&city=重庆');
    ok('同城流只返回该城市', nearby.status === 200 && nearby.body.items.every((p) => p.city === '重庆' || p.place.includes('重庆')), nearby.body?.items?.map((p) => p.city));
    const nearbyNoCity = await call('GET', '/v1/feed?tab=nearby');
    ok('同城流缺 city 返回 400', nearbyNoCity.status === 400, nearbyNoCity.status);
    const trend = await call('GET', '/v1/tags/trending');
    ok('热门话题非空', trend.status === 200 && trend.body.items.length > 0, trend.body?.items?.slice(0, 3));
    const cities = await call('GET', '/v1/feed/cities');
    ok('城市列表非空', cities.status === 200 && cities.body.items.length > 0, cities.body?.items?.slice(0, 3));

    console.log('[媒体上传]');
    const jpeg = fs.readFileSync(path.join(__dirname, '..', 'seed-media', 'chongqing.jpg'));
    const up = await call('POST', '/v1/media', { raw: jpeg, headers: { 'Content-Type': 'image/jpeg' } });
    ok('上传图片 201 并返回 url', up.status === 201 && String(up.body.url).startsWith('/media/'), up.body);
    const mediaRes = await fetch(`${BASE}${up.body.url}`, { headers: { Range: 'bytes=0-99' } });
    ok('媒体 Range 读取 206 + 100 字节', mediaRes.status === 206 && (await mediaRes.arrayBuffer()).byteLength === 100, mediaRes.status);
    const fullMedia = await fetch(`${BASE}${up.body.url}`);
    ok('媒体整段读取 200', fullMedia.status === 200 && Number(fullMedia.headers.get('content-length')) === jpeg.length);
    const badType = await call('POST', '/v1/media', { raw: Buffer.from('not-a-real-media-file'), headers: { 'Content-Type': 'text/plain' } });
    ok('非媒体类型被拒 415', badType.status === 415, badType.status);

    console.log('[发布]');
    const created = await call('POST', '/v1/posts', {
      body: {
        place: '重庆·洪崖洞', city: '重庆',
        caption: '冒烟测试：夜景确实顶。',
        tags: ['#重庆', '夜景', '夜景'],
        media: [{ type: 'image', url: up.body.url }],
        bgmTitle: '测试配乐', bgmArtist: 'Smoke', lat: 29.56, lon: 106.58,
      },
    });
    ok('发布 201', created.status === 201, created.body);
    const postId = created.body?.id;
    ok('发布后 isMine 为真', created.body?.isMine === true, created.body?.isMine);
    ok('话题去重且去掉 #', JSON.stringify(created.body?.tags) === JSON.stringify(['重庆', '夜景']), created.body?.tags);
    const detail = await call('GET', `/v1/posts/${postId}`);
    ok('单条详情可读', detail.status === 200 && detail.body.id === postId, detail.body?.id);
    const empty = await call('POST', '/v1/posts', { body: { caption: '', media: [] } });
    ok('空内容被拒 400', empty.status === 400, empty.status);

    console.log('[互动]');
    const like1 = await call('POST', `/v1/posts/${postId}/like`);
    ok('点赞后 liked=true 且计数 +1', like1.body.liked === true && like1.body.likes === 1, like1.body);
    const like2 = await call('POST', `/v1/posts/${postId}/like`);
    ok('再点取消 liked=false', like2.body.liked === false && like2.body.likes === 0, like2.body);
    const fav = await call('POST', `/v1/posts/${postId}/favorite`);
    ok('收藏 favored=true', fav.body.favored === true && fav.body.favorites === 1, fav.body);
    const share = await call('POST', `/v1/posts/${postId}/share`);
    ok('分享返回计数与链接', share.body.shares === 1 && share.body.shareUrl.includes(postId), share.body);
    const share2 = await call('POST', `/v1/posts/${postId}/share`);
    ok('重复分享不重复计数', share2.body.shares === 1, share2.body);
    const view = await call('POST', `/v1/posts/${postId}/view`);
    ok('浏览成功', view.status === 200 && view.body.ok === true, view.body);
    const view2 = await call('POST', `/v1/posts/${postId}/view`);
    ok('重复浏览幂等', view2.status === 200, view2.status);

    console.log('[评论]');
    const c1 = await call('POST', `/v1/posts/${postId}/comments`, { body: { text: '第一条评论' } });
    ok('发评论 201 且计数 1', c1.status === 201 && c1.body.commentCount === 1, c1.body);
    const c2 = await call('POST', `/v1/posts/${postId}/comments`, { body: { text: '回复你', replyTo: c1.body.comment.id } });
    ok('回复评论带 replyTo', c2.body?.comment?.replyTo === c1.body.comment.id, c2.body?.comment);
    const cEmpty = await call('POST', `/v1/posts/${postId}/comments`, { body: { text: '   ' } });
    ok('空评论被拒 400', cEmpty.status === 400, cEmpty.status);
    const list = await call('GET', `/v1/posts/${postId}/comments`);
    ok('评论列表 2 条且新在前', list.body.items.length === 2 && list.body.items[0].id === c2.body.comment.id, list.body?.items?.length);
    const clike = await call('POST', `/v1/comments/${c1.body.comment.id}/like`);
    ok('评论点赞 liked=true', clike.body.liked === true && clike.body.likes === 1, clike.body);
    const cdel = await call('DELETE', `/v1/comments/${c1.body.comment.id}`);
    ok('删除自己的评论', cdel.status === 200 && cdel.body.ok === true, cdel.body);
    const list2 = await call('GET', `/v1/posts/${postId}/comments`);
    ok('删除后列表剩 1 条', list2.body.items.length === 1, list2.body?.items?.length);

    console.log('[关注与作者页]');
    const follow = await call('POST', '/v1/users/-101/follow');
    ok('关注成功且粉丝 +1', follow.body.followingHim === true && follow.body.followers === 1, follow.body);
    const meInfo = await call('GET', '/v1/users/-101');
    ok('作者页 followingHim=true', meInfo.status === 200 && meInfo.body.followingHim === true, meInfo.body);
    const followFeed = await call('GET', '/v1/feed?tab=following');
    ok('关注流只含已关注作者', followFeed.body.items.length > 0 && followFeed.body.items.every((p) => p.author.id === -101 || p.isMine), followFeed.body?.items?.map((p) => p.author.id));
    const hisPosts = await call('GET', '/v1/users/-101/posts');
    ok('作者作品列表非空', hisPosts.body.items.length > 0, hisPosts.body?.items?.length);
    const followers = await call('GET', '/v1/users/-101/followers');
    ok('粉丝列表含我', followers.body.items.some((u) => u.id === 1001), followers.body?.items);
    const selfFollow = await call('POST', '/v1/users/1001/follow');
    ok('不能关注自己（400）', selfFollow.status === 400, selfFollow.status);
    const unfollow = await call('POST', '/v1/users/-101/follow');
    ok('再点取消关注', unfollow.body.followingHim === false, unfollow.body);

    console.log('[我的]');
    const mine = await call('GET', '/v1/feed?tab=mine');
    ok('我的流含刚发布的帖子', mine.body.items.some((p) => p.id === postId), mine.body?.items?.length);
    const myPosts = await call('GET', '/v1/me/posts');
    ok('我的作品接口一致', myPosts.body.items.some((p) => p.id === postId), myPosts.body?.items?.length);
    const favs = await call('GET', '/v1/me/favorites');
    ok('收藏列表含刚收藏的帖子', favs.body.items.some((p) => p.id === postId), favs.body?.items?.length);

    console.log('[搜索]');
    const search = await call('GET', '/v1/search?q=重庆');
    ok('搜索命中帖子', search.body.posts.length > 0, search.body?.posts?.length);
    ok('搜索结果含标签聚合', Array.isArray(search.body.tags), search.body?.tags);
    const searchUser = await call('GET', '/v1/search?q=阿岚');
    ok('搜索命中用户', searchUser.body.users.length > 0, searchUser.body?.users);
    const emptySearch = await call('GET', '/v1/search');
    ok('空关键词返回空结果', emptySearch.status === 200 && emptySearch.body.posts.length === 0, emptySearch.body);

    console.log('[不感兴趣]');
    const hidden = recommend.body.items[0].id;
    const hide = await call('POST', `/v1/posts/${hidden}/hide`);
    ok('标记不感兴趣', hide.status === 200 && hide.body.hidden === true, hide.body);
    const recommend2 = await call('GET', '/v1/feed?tab=recommend&limit=10');
    ok('推荐流已剔除该帖', !recommend2.body.items.some((p) => p.id === hidden), recommend2.body?.items?.map((p) => p.id));

    console.log('[举报与撤回]');
    const report = await call('POST', `/v1/posts/${postId}/report`, { body: { reason: '冒烟测试' } });
    ok('举报落库成功', report.status === 200 && report.body.ok === true, report.body);
    const del = await call('DELETE', `/v1/posts/${postId}`);
    ok('撤回成功', del.status === 200 && del.body.ok === true, del.body);
    const gone = await call('GET', `/v1/posts/${postId}`);
    ok('撤回后详情 404', gone.status === 404, gone.status);

    console.log('[错误处理]');
    const nf = await call('GET', '/v1/nope');
    ok('未知路由 404', nf.status === 404, nf.status);
    const badId = await call('POST', '/v1/posts/does-not-exist/like');
    ok('对不存在的帖子点赞 404', badId.status === 404, badId.status);
    const badUid = await call('GET', '/v1/users/abc');
    ok('非法 uid 400', badUid.status === 400, badUid.status);
    const gzipRes = await fetch(`${BASE}/v1/feed?tab=recommend&limit=30`, {
      headers: { 'Accept-Encoding': 'gzip' },
    });
    ok('大响应启用 gzip', gzipRes.headers.get('content-encoding') === 'gzip', gzipRes.headers.get('content-encoding'));
    ok('安全响应头存在', gzipRes.headers.get('x-content-type-options') === 'nosniff', gzipRes.headers.get('x-content-type-options'));
  } finally {
    server.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 300));
    fs.rmSync(TMP, { recursive: true, force: true });
  }

  console.log(`\n结果：通过 ${passed} 项，失败 ${failures.length} 项`);
  if (failures.length > 0) {
    console.log('失败项：');
    for (const f of failures) console.log(`  - ${f}`);
    process.exitCode = 1;
  } else {
    console.log('全部通过 ✅');
  }
}

main().catch((err) => {
  console.error('冒烟测试异常：', err);
  process.exitCode = 1;
});
