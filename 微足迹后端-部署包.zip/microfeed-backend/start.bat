@echo off
rem 微足迹独立服务启动脚本（Windows）
rem 双击运行，或用 start-backend.bat 自动创建 .env / 检查 Node 版本
setlocal enabledelayedexpansion
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo 未找到 node。请安装 Node.js 24（官网 LTS 版）后重试。
  pause
  exit /b 1
)

for /f "delims=" %%v in ('node -v') do set NODE_VER=%%v
echo 当前 Node: %NODE_VER%

if not exist .env (
  copy /y .env.example .env >nul
  echo 已生成 .env，请用记事本填写 MF_SECRET_KEY ^(必须与主后端一致^)，然后重新运行。
  pause
  exit /b 1
)

if not exist data mkdir data
if not exist storage mkdir storage
if not exist logs mkdir logs

echo 启动微足迹服务，端口见 .env 中的 MF_PORT ^(默认 7080^)
node --no-warnings src/server.js
pause
