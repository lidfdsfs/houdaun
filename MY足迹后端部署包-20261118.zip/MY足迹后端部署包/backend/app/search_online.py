"""联网搜索（临时会话）。

链路：App 带 query + 强度 → 服务端检索（SearXNG 优先，未配置则 Bing HTML）→
并发抓取前 N 条网页 → 复用 `content.clean_html` 抽正文 → 生成结构化结果 →
写进 `search_sessions`（短期会话，默认 10 分钟）→ 返回。

**临时性**：搜索到的网页原文不落盘、不进 `content_items`；会话到期或被客户端
显式关闭时整行删除，并做一次 WAL checkpoint，避免已删除内容长期留在日志里。
进程内还有 janitor 线程每分钟清一次过期会话。

强度（strength）决定成本：
- fast      5 条结果，不抓正文（只用搜索引擎摘要），~1 秒
- balanced  8 条结果，抓前 4 篇正文摘要，~3-6 秒
- deep      10 条结果，抓前 8 篇正文摘要，~6-12 秒
"""
from __future__ import annotations

import hashlib
import html as html_lib
import logging
import re
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import httpx

from .config import settings
from .content import FetchError, clean_html, fetch_html, normalize_url
from .db import db, json_dump, json_load, tx

logger = logging.getLogger("myzuji.search_online")

STRENGTHS: dict[str, dict[str, int]] = {
    "fast": {"results": 5, "excerpts": 0, "attempts": 0},
    "balanced": {"results": 8, "excerpts": 4, "attempts": 8},
    "deep": {"results": 10, "excerpts": 8, "attempts": 10},
}

_BING_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)

_TIERS: list[tuple[int, tuple[str, ...]]] = [
    (1, ("gov.cn", "gov.hk", "gov.mo", "ncha.gov.cn", "mct.gov.cn", "stats.gov.cn",
         "cnki.net", "edu.cn", "cas.cn", "wikipedia.org")),
    (2, ("people.com.cn", "xinhuanet.com", "news.cn", "cctv.com", "china.com.cn",
         "thepaper.cn", "bjnews.com.cn", "sina.com.cn", "sina.cn", "163.com", "qq.com")),
    (3, ("mafengwo.cn", "ctrip.com", "qunar.com", "dianping.com", "douban.com",
         "zhihu.com", "xiaohongshu.com", "bilibili.com", "sohu.com", "toutiao.com")),
]


class SearchError(RuntimeError):
    pass


def _site_of(url: str) -> str:
    host = (url.split("//")[-1].split("/")[0] or "").lower()
    return host[4:] if host.startswith("www.") else host


def _tier_for(url: str) -> int:
    host = _site_of(url)
    for tier, domains in _TIERS:
        if any(host == d or host.endswith("." + d) for d in domains):
            return tier
    return 4


def _plain(text: str) -> str:
    text = re.sub(r"<[^>]+>", " ", text or "")
    text = html_lib.unescape(text)
    return re.sub(r"\s+", " ", text).strip()


# ---------- 搜索源 ----------

def _search_searxng(query: str, limit: int) -> list[dict[str, Any]]:
    if not settings.search_endpoint:
        raise SearchError("未配置 SEARCH_ENDPOINT")
    try:
        with httpx.Client(timeout=settings.search_timeout_seconds, follow_redirects=True) as client:
            resp = client.get(
                settings.search_endpoint,
                params={"q": query, "format": "json", "language": "zh-CN",
                        "categories": "general", "safesearch": "1"},
            )
            resp.raise_for_status()
            data = resp.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise SearchError(f"SearXNG 不可用：{type(exc).__name__}") from exc

    hits: list[dict[str, Any]] = []
    for rank, item in enumerate((data.get("results") or [])[:limit], start=1):
        url = str(item.get("url") or "").strip()
        title = _plain(str(item.get("title") or ""))
        if not url or not title:
            continue
        hits.append({
            "title": title[:200],
            "url": url[:600],
            "snippet": _plain(str(item.get("content") or ""))[:500],
            "site": _site_of(url),
            "rank": rank,
        })
    return hits


_BING_BLOCK_RE = re.compile(r'<li class="b_algo".*?</li>', re.I | re.S)
_BING_LINK_RE = re.compile(r'<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', re.I | re.S)
_BING_SNIPPET_RE = re.compile(r'<p[^>]*>(.*?)</p>', re.I | re.S)


def parse_bing_html(html: str, limit: int) -> list[dict[str, Any]]:
    """从 Bing 搜索结果页抽 title/url/snippet。抽不到就返回空，不猜。"""
    hits: list[dict[str, Any]] = []
    seen: set[str] = set()
    for block in _BING_BLOCK_RE.findall(html):
        link = _BING_LINK_RE.search(block)
        if not link:
            continue
        url = html_lib.unescape(link.group(1)).strip()
        title = _plain(link.group(2))
        if not url.startswith(("http://", "https://")) or not title:
            continue
        if "bing.com/ck" in url or "go.microsoft.com" in url:
            continue  # 跳转壳链接，清洗成本高且不稳定
        normalized = normalize_url(url)
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        snippet_match = _BING_SNIPPET_RE.search(block)
        snippet = _plain(snippet_match.group(1))[:500] if snippet_match else ""
        hits.append({
            "title": title[:200],
            "url": normalized[:600],
            "snippet": snippet,
            "site": _site_of(normalized),
            "rank": len(hits) + 1,
        })
        if len(hits) >= limit:
            break
    return hits


def _search_bing(query: str, limit: int) -> list[dict[str, Any]]:
    try:
        with httpx.Client(
            timeout=settings.search_timeout_seconds,
            headers={"User-Agent": _BING_UA, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6"},
            follow_redirects=True,
        ) as client:
            resp = client.get(
                "https://www.bing.com/search",
                params={"q": query, "setlang": "zh-CN", "count": "20"},
            )
            resp.raise_for_status()
    except httpx.HTTPError as exc:
        raise SearchError(f"Bing 不可用：{type(exc).__name__}") from exc
    hits = parse_bing_html(resp.text, limit)
    if not hits:
        raise SearchError("Bing 没有返回可解析的结果（可能触发了反爬）")
    return hits


def search_web(query: str, limit: int) -> tuple[str, list[dict[str, Any]]]:
    """按配置选择搜索源；auto = SearXNG 优先，其次 Bing。"""
    provider = (settings.search_provider or "auto").strip().lower()
    if provider == "searxng":
        return "searxng", _search_searxng(query, limit)
    if provider == "bing":
        return "bing", _search_bing(query, limit)
    if settings.search_endpoint:
        try:
            return "searxng", _search_searxng(query, limit)
        except SearchError as exc:
            logger.warning("SearXNG 失败，回退 Bing：%s", exc)
    return "bing", _search_bing(query, limit)


# ---------- 正文摘要 ----------

def fetch_excerpt(url: str, limit: int = 800) -> str:
    """抓一篇文章并抽正文摘要；正文抽不出来时退回 meta description。

    单篇失败返回空串，不影响其它结果。
    """
    try:
        final_url, html = fetch_html(url)
        cleaned = clean_html(html, final_url)
        text = (cleaned.get("body_text") or cleaned.get("summary") or "").strip()
        return text[:limit]
    except FetchError as exc:
        logger.info("摘要抓取跳过 %s：%s", url, exc)
        return ""
    except Exception:  # noqa: BLE001 - 单篇失败不能拖垮整次搜索
        logger.exception("摘要抓取异常 %s", url)
        return ""


def enrich_with_excerpts(results: list[dict[str, Any]], count: int, attempts: int | None = None) -> list[dict[str, Any]]:
    """并发清洗前 N 篇；部分站点反爬/robots 拒绝时，用后面的结果补位。

    `count` 是希望拿到的正文摘要条数，`attempts` 是最多尝试抓取的条数。
    """
    if count <= 0 or not results:
        return results
    limit = min(len(results), max(count, attempts or count))
    targets = results[:limit]
    excerpts: dict[int, str] = {}
    with ThreadPoolExecutor(max_workers=min(6, len(targets))) as pool:
        futures = {pool.submit(fetch_excerpt, item["url"], settings.search_excerpt_chars): idx
                   for idx, item in enumerate(targets)}
        for future in as_completed(futures):
            idx = futures[future]
            try:
                excerpts[idx] = future.result()
            except Exception:  # noqa: BLE001
                excerpts[idx] = ""
    filled = 0
    for idx, item in enumerate(targets):
        text = (excerpts.get(idx) or "").strip()
        if text and filled < count:
            item["excerpt"] = text
            item["fetched"] = True
            filled += 1
    logger.info("正文摘要完成 %s/%s（尝试 %s 篇）", filled, count, len(targets))
    return results


# ---------- 会话生命周期 ----------

def _session_view(row: Any) -> dict[str, Any]:
    return {
        "session_id": row["id"],
        "query": row["query"],
        "strength": row["strength"],
        "provider": row["provider"],
        "items": json_load(row["items"], []),
        "item_count": int(row["item_count"]),
        "created_at": int(row["created_at"]),
        "expires_at": int(row["expires_at"]),
        "ttl_seconds": max(0, int(row["expires_at"]) - int(time.time())),
    }


def run_search(user_id: int, query: str, strength: str) -> dict[str, Any]:
    spec = STRENGTHS.get(strength)
    if spec is None:
        raise SearchError("strength 只能是 fast / balanced / deep")

    provider, raw = search_web(query, spec["results"])
    results: list[dict[str, Any]] = []
    for rank, item in enumerate(raw[: spec["results"]], start=1):
        tier = _tier_for(item["url"])
        snippet = item.get("snippet") or ""
        results.append({
            "title": item["title"],
            "url": item["url"],
            "site": item["site"],
            "snippet": snippet[:500],
            "excerpt": "",
            "fetched": False,
            "tier": tier,
            "rank": rank,
            "score": round(max(0.05, 1.0 - (rank - 1) / max(1, spec["results"]) * 0.6
                               - (tier - 1) * 0.08), 3),
        })
    enrich_with_excerpts(results, spec["excerpts"], spec["attempts"])

    now = int(time.time())
    sid = uuid.uuid4().hex
    expires = now + settings.search_session_ttl_seconds
    with tx() as conn:
        conn.execute(
            """INSERT INTO search_sessions
               (id, user_id, query, strength, provider, items, item_count, created_at, expires_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (sid, user_id, query[:200], strength, provider,
             json_dump(results), len(results), now, expires),
        )
        row = conn.execute("SELECT * FROM search_sessions WHERE id = ?", (sid,)).fetchone()
    view = _session_view(row)
    view["result_count"] = len(results)
    return view


def get_session(user_id: int, session_id: str) -> dict[str, Any] | None:
    now = int(time.time())
    with db() as conn:
        row = conn.execute("SELECT * FROM search_sessions WHERE id = ?", (session_id,)).fetchone()
    if row is None or int(row["user_id"]) != user_id:
        return None
    if int(row["expires_at"]) <= now:
        close_session(user_id, session_id)
        return None
    return _session_view(row)


def close_session(user_id: int, session_id: str) -> bool:
    with tx() as conn:
        cur = conn.execute(
            "DELETE FROM search_sessions WHERE id = ? AND user_id = ?", (session_id, user_id)
        )
        return cur.rowcount > 0


def close_all(user_id: int) -> int:
    with tx() as conn:
        cur = conn.execute("DELETE FROM search_sessions WHERE user_id = ?", (user_id,))
        return int(cur.rowcount)


def list_sessions(user_id: int, limit: int = 20) -> list[dict[str, Any]]:
    now = int(time.time())
    with db() as conn:
        rows = conn.execute(
            """SELECT * FROM search_sessions WHERE user_id = ? AND expires_at > ?
               ORDER BY created_at DESC LIMIT ?""",
            (user_id, now, limit),
        ).fetchall()
    return [
        {
            "session_id": r["id"], "query": r["query"], "strength": r["strength"],
            "provider": r["provider"], "item_count": int(r["item_count"]),
            "created_at": int(r["created_at"]), "expires_at": int(r["expires_at"]),
            "ttl_seconds": max(0, int(r["expires_at"]) - now),
        }
        for r in rows
    ]


def purge_expired() -> int:
    """删除过期会话，并 checkpoint WAL 让已删内容尽快从日志里消失。"""
    now = int(time.time())
    with tx() as conn:
        cur = conn.execute("DELETE FROM search_sessions WHERE expires_at <= ?", (now,))
        deleted = int(cur.rowcount)
    if deleted:
        try:
            with db() as conn:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:  # noqa: BLE001 - checkpoint 失败不影响清理结果
            logger.warning("WAL checkpoint 失败，下次再试")
        logger.info("已清理过期搜索会话 %s 个", deleted)
    return deleted


def purge_all() -> int:
    with tx() as conn:
        cur = conn.execute("DELETE FROM search_sessions")
        deleted = int(cur.rowcount)
    try:
        with db() as conn:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except Exception:  # noqa: BLE001
        pass
    return deleted


def stats() -> dict[str, Any]:
    now = int(time.time())
    today = now - now % 86400
    with db() as conn:
        row = conn.execute(
            """SELECT COUNT(*) c,
                      COALESCE(SUM(CASE WHEN created_at >= ? THEN 1 ELSE 0 END), 0) today
               FROM search_sessions WHERE expires_at > ?""",
            (today, now),
        ).fetchone()
    return {"active_sessions": int(row["c"]), "created_today": int(row["today"]),
            "ttl_seconds": settings.search_session_ttl_seconds}


class SearchJanitor:
    """每分钟清一次过期搜索会话；随 FastAPI lifespan 启停。"""

    def __init__(self) -> None:
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if not settings.search_online_enabled:
            logger.info("联网搜索已关闭（SEARCH_ONLINE_ENABLED=false）")
            return
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, name="search-janitor", daemon=True)
        self._thread.start()
        logger.info("搜索会话清理线程已启动，每 %ss 一次", settings.search_cleanup_seconds)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                purge_expired()
            except Exception:  # noqa: BLE001
                logger.exception("搜索会话清理异常")
            self._stop.wait(settings.search_cleanup_seconds)


janitor = SearchJanitor()


def query_fingerprint(query: str) -> str:
    """只用于日志排查，不落库。"""
    return hashlib.sha256(query.encode("utf-8")).hexdigest()[:12]
