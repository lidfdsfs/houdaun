"""请求/响应参数校验。

原则：所有来自客户端的字段都在这里定长度上限，避免超大字符串进库；
extra="ignore" 让客户端多传字段不会 422（老版本 App 升级期间更稳）。
"""
from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

HEX64_RE = re.compile(r"^[a-f0-9]{64}$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_\u4e00-\u9fa5]{3,20}$")


def _clean_username(value: str) -> str:
    v = (value or "").strip()
    if not USERNAME_RE.match(v):
        raise ValueError("用户名需 3–20 位，只能包含字母、数字、下划线或中文")
    return v


def _clean_hash(value: str) -> str:
    v = (value or "").strip().lower()
    if not HEX64_RE.match(v):
        raise ValueError("密码格式错误：应提交客户端预哈希值")
    return v


class Base(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)


# ---------------- 认证 ----------------

class LoginRequest(Base):
    """登录只接受用户名；密码为客户端固定盐预哈希。"""
    username: str = Field(min_length=3, max_length=20)
    password_hash: str = Field(min_length=64, max_length=64)
    captcha_id: str | None = Field(default=None, max_length=64)
    captcha_text: str | None = Field(default=None, max_length=16)

    @field_validator("username")
    @classmethod
    def _v_username(cls, v: str) -> str:
        return _clean_username(v)

    @field_validator("password_hash")
    @classmethod
    def _v_hash(cls, v: str) -> str:
        return _clean_hash(v)


class RegisterRequest(Base):
    username: str = Field(min_length=3, max_length=20)
    password_hash: str = Field(min_length=64, max_length=64)
    nickname: str | None = Field(default=None, max_length=40)
    captcha_id: str = Field(min_length=1, max_length=64)
    captcha_text: str = Field(min_length=1, max_length=16)

    @field_validator("username")
    @classmethod
    def _v_username(cls, v: str) -> str:
        return _clean_username(v)

    @field_validator("password_hash")
    @classmethod
    def _v_hash(cls, v: str) -> str:
        return _clean_hash(v)

    @field_validator("nickname")
    @classmethod
    def _v_nick(cls, v: str | None) -> str | None:
        value = (v or "").strip()
        return value[:40] if value else None


class VerifyLinkRequest(Base):
    """申请注册验证地址：用户名 + 图形验证码，防止批量生成。"""

    username: str = Field(min_length=3, max_length=20)
    captcha_id: str = Field(min_length=1, max_length=64)
    captcha_text: str = Field(min_length=1, max_length=16)

    @field_validator("username")
    @classmethod
    def _v_username(cls, v: str) -> str:
        return _clean_username(v)


class DeleteAccountRequest(Base):
    """注销申请：提交当前密码（固定盐预哈希）。"""
    password_hash: str = Field(min_length=64, max_length=64)

    @field_validator("password_hash")
    @classmethod
    def _v_hash(cls, v: str) -> str:
        return _clean_hash(v)


# ---------------- 用户 ----------------

class UserUpdate(Base):
    nickname: str | None = Field(default=None, max_length=40)
    signature: str | None = Field(default=None, max_length=200)
    default_public: bool | None = None
    notif_enabled: bool | None = None
    share_enabled: bool | None = None


# ---------------- 攻略 ----------------

class CostItemIn(Base):
    label: str = Field(default="", max_length=40)
    amount: str = Field(default="", max_length=40)
    total: bool = False


class SpotIn(Base):
    name: str = Field(default="", max_length=80)
    note: str = Field(default="", max_length=800)
    cost: str = Field(default="", max_length=40)
    tips: str | None = Field(default=None, max_length=400)
    seed: int = 0


class DayPlanIn(Base):
    day: int = Field(default=1, ge=0, le=60)
    title: str = Field(default="", max_length=120)
    special: bool = False
    special_reason: str | None = Field(default=None, max_length=300)
    spots: list[SpotIn] = Field(default_factory=list, max_length=40)


class GuideCreate(Base):
    title: str = Field(min_length=1, max_length=120)
    intro: str = Field(default="", max_length=6000)
    city: str = Field(default="", max_length=60)
    days: int = Field(default=1, ge=1, le=60)
    cost: str = Field(default="", max_length=60)
    theme: str = Field(default="", max_length=40)
    region: str = Field(default="", max_length=20)
    cover_seed: int = 0
    cover_image: str | None = Field(default=None, max_length=400)
    banner_title: str = Field(default="", max_length=120)
    banner_subtitle: str = Field(default="", max_length=200)
    tags: list[str] = Field(default_factory=list, max_length=12)
    cost_breakdown: list[CostItemIn] = Field(default_factory=list, max_length=30)
    tips: list[str] = Field(default_factory=list, max_length=30)
    itinerary: list[DayPlanIn] = Field(default_factory=list, max_length=60)

    @field_validator("tags")
    @classmethod
    def _v_tags(cls, v: list[str]) -> list[str]:
        return [t[:24] for t in v if t and t.strip()][:12]

    @field_validator("tips")
    @classmethod
    def _v_tips(cls, v: list[str]) -> list[str]:
        return [t[:400] for t in v if t and t.strip()][:30]


# ---------------- 足迹 / 路线 ----------------

class RouteCreate(Base):
    title: str = Field(min_length=1, max_length=120)
    cities: list[str] = Field(default_factory=list, max_length=40)
    date: str = Field(default="", max_length=40)
    note: str = Field(default="", max_length=6000)
    cover_seed: int = 0
    year: int = Field(default=0, ge=0, le=3000)
    special: bool = False
    special_reason: str = Field(default="", max_length=300)
    tags: list[str] = Field(default_factory=list, max_length=12)
    spots: list[SpotIn] = Field(default_factory=list, max_length=200)
    photos: list[str] = Field(default_factory=list, max_length=200)


# ---------------- 评论 ----------------

class CommentCreate(Base):
    guide_id: int = Field(gt=0)
    content: str = Field(min_length=1, max_length=1200)
    parent_id: int | None = Field(default=None, gt=0)


# ---------------- 同步 ----------------

class SyncItem(Base):
    client_id: int
    updated_at: int = Field(ge=0)
    payload: dict[str, Any]


class SyncBatch(Base):
    items: list[SyncItem] = Field(default_factory=list, max_length=500)
    deleted_client_ids: list[int] = Field(default_factory=list, max_length=1000)


class SettingsSync(Base):
    payload: dict[str, Any]
    updated_at: int = Field(ge=0)


class CollectionItem(Base):
    """通用分区的单条数据：client_id 允许字符串（歌曲 id、隐私空间条目 uuid 都能用）。"""

    client_id: str = Field(min_length=1, max_length=128)
    updated_at: int = Field(ge=0)
    payload: dict[str, Any]


class CollectionBatch(Base):
    items: list[CollectionItem] = Field(default_factory=list, max_length=1000)
    deleted_client_ids: list[str] = Field(default_factory=list, max_length=1000)


class SnapshotIn(Base):
    footprints: list[SyncItem] = Field(default_factory=list, max_length=2000)
    routes: list[SyncItem] = Field(default_factory=list, max_length=1000)
    settings: dict[str, Any] | None = None
    settings_updated_at: int = 0
    replace_all: bool = False


# ---------------- 服务端检索 ----------------

class SearchRequest(Base):
    query: str = Field(min_length=1, max_length=200)
    limit: int = Field(default=8, ge=1, le=30)
    depth: str = Field(default="balanced", max_length=16)


class SearchOnlineRequest(Base):
    """联网搜索：强度决定结果数与抓正文篇数。"""

    query: str = Field(min_length=1, max_length=200)
    strength: str = Field(default="balanced", max_length=12)

    @field_validator("strength")
    @classmethod
    def _v_strength(cls, v: str) -> str:
        v = (v or "balanced").strip().lower()
        if v not in {"fast", "balanced", "deep"}:
            raise ValueError("strength 只能是 fast / balanced / deep")
        return v


# ---------------- AI 端点（云端保管，端上调用） ----------------

class AiEndpointIn(Base):
    """一条模型端点配置。字段上限在这里卡死，路由层再做协议/地址校验。"""

    client_id: str = Field(min_length=1, max_length=64)
    name: str = Field(default="自定义 API", max_length=60)
    format: str = Field(default="OPENAI", max_length=16)
    base_url: str = Field(min_length=8, max_length=500)
    api_key: str = Field(default="", max_length=4096)
    model: str = Field(default="", max_length=160)
    vision_model: str = Field(default="", max_length=160)
    image_model: str = Field(default="", max_length=160)
    video_model: str = Field(default="", max_length=160)
    capabilities: list[str] = Field(default_factory=list, max_length=8)
    context_tokens: int = Field(default=200_000, ge=1024, le=2_000_000)
    max_output_tokens: int = Field(default=4096, ge=1, le=262_144)
    vision_context_tokens: int = Field(default=8000, ge=1024, le=2_000_000)
    vision_max_output_tokens: int = Field(default=1024, ge=1, le=262_144)
    media_path: str = Field(default="", max_length=200)
    video_path: str = Field(default="", max_length=200)


class AiConfigIn(Base):
    endpoints: list[AiEndpointIn] = Field(default_factory=list, max_length=32)
    state: dict[str, Any] | None = None
    deleted_client_ids: list[str] = Field(default_factory=list, max_length=32)
    updated_at: int = Field(default=0, ge=0)


# ---------------- 后台 ----------------

class AdminLogin(Base):
    username: str = Field(default="", max_length=120)
    password: str = Field(min_length=1, max_length=200)


class AdminUserAction(Base):
    note: str | None = Field(default=None, max_length=200)
    new_password: str | None = Field(default=None, max_length=64)


class AdminUserCreate(Base):
    """后台直接创建 App 账号：管理员填用户名 + 明文初始密码。"""

    username: str = Field(min_length=3, max_length=20)
    password: str = Field(min_length=6, max_length=64)
    nickname: str = Field(default="旅行者", max_length=40)

    @field_validator("username")
    @classmethod
    def _v_username(cls, v: str) -> str:
        return _clean_username(v)

    @field_validator("nickname")
    @classmethod
    def _v_nick(cls, v: str) -> str:
        v = (v or "").strip() or "旅行者"
        return v[:40]


class AdminGuideAction(Base):
    featured: bool | None = None
    status: int | None = Field(default=None, ge=0, le=1)
    region: str | None = Field(default=None, max_length=20)
    title: str | None = Field(default=None, max_length=120)


# ---------------- 网页抓取 / 内容源 ----------------

class ContentSourceCreate(Base):
    name: str = Field(min_length=1, max_length=80)
    kind: str = Field(default="html", max_length=10)
    list_url: str = Field(min_length=3, max_length=600)
    host: str = Field(default="", max_length=200)
    url_prefix: str = Field(default="", max_length=400)
    default_category: str = Field(default="", max_length=40)
    enabled: bool = True
    interval_minutes: int = Field(default=60, ge=5, le=10080)
    max_items: int = Field(default=12, ge=1, le=50)

    @field_validator("kind")
    @classmethod
    def _v_kind(cls, v: str) -> str:
        v = (v or "html").strip().lower()
        if v not in {"html", "rss", "sitemap"}:
            raise ValueError("kind 只能是 html / rss / sitemap")
        return v

    @field_validator("list_url")
    @classmethod
    def _v_url(cls, v: str) -> str:
        v = (v or "").strip()
        if not v.startswith(("http://", "https://")):
            raise ValueError("list_url 必须是 http(s) 地址")
        return v


class ContentSourceUpdate(Base):
    name: str | None = Field(default=None, max_length=80)
    enabled: bool | None = None
    interval_minutes: int | None = Field(default=None, ge=5, le=10080)
    max_items: int | None = Field(default=None, ge=1, le=50)
    host: str | None = Field(default=None, max_length=200)
    url_prefix: str | None = Field(default=None, max_length=400)
    default_category: str | None = Field(default=None, max_length=40)


class ContentFetchUrl(Base):
    url: str = Field(min_length=3, max_length=600)
    category: str = Field(default="", max_length=40)

    @field_validator("url")
    @classmethod
    def _v_url(cls, v: str) -> str:
        v = (v or "").strip()
        if not v.startswith(("http://", "https://")):
            raise ValueError("url 必须是 http(s) 地址")
        return v


class ContentItemAction(Base):
    status: int | None = Field(default=None, ge=0, le=1)
    category: str | None = Field(default=None, max_length=40)


# ---------------- 站内私信 ----------------

class ConversationOpen(Base):
    peer_id: int = Field(gt=0)


class MessageSend(Base):
    client_msg_id: str = Field(default="", max_length=80)
    type: str = Field(default="text", max_length=10)
    body: str = Field(default="", max_length=4000)
    extra: dict[str, Any] | None = None

    @field_validator("type")
    @classmethod
    def _v_type(cls, v: str) -> str:
        v = (v or "text").strip().lower()
        if v not in {"text", "image", "video"}:
            raise ValueError("消息类型只支持 text / image / video")
        return v


class ReadMark(Base):
    seq: int = Field(default=0, ge=0)


class BlockAction(Base):
    blocked: bool = True
