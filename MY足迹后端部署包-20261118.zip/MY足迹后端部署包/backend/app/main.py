"""MY足迹 后端服务入口。

启动顺序：读配置 → 建目录 → 建表 → 落测试账号 → 挂路由。
安全相关的全局措施都在这里：请求体大小上限、安全响应头、统一异常兜底（不泄露堆栈）。
"""
from __future__ import annotations

import logging
import mimetypes
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from .config import settings
from .content import worker as content_worker
from .deps import require_user
from .db import init_db
from .routers import admin as admin_router
from .routers import account as account_router
from .routers import ai as ai_router
from .routers import auth as auth_router
from .routers import comments as comments_router
from .routers import content as content_router
from .routers import guides as guides_router
from .routers import messages as messages_router
from .routers import routes as routes_router
from .routers import search as search_router
from .routers import sync as sync_router
from .routers import users as users_router
from .search_online import janitor as search_janitor

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger("myzuji")

ADMIN_UI_DIR = Path(__file__).resolve().parent / "admin_ui"
MAX_BODY_BYTES = max(settings.max_video_bytes, settings.max_image_bytes) + 2 * 1024 * 1024


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    logger.info("数据库就绪：%s", settings.db_file)
    logger.info("存储目录：%s", settings.storage_path)
    if settings.is_prod:
        # 生产环境把关键配置是否就位打在日志里，便于部署后第一时间发现漏配
        if not settings.secret_key:
            logger.warning("SECRET_KEY 未显式配置，已使用 data/.secret_key 自动生成密钥")
        if settings.cors_origins.strip() == "*":
            logger.warning("CORS_ORIGINS=*：后台接口不建议对任意来源开放，建议改成自己的域名")
    logger.info(
        "%s v%s 启动完成 env=%s，测试账号=%s",
        settings.app_name,
        settings.app_version,
        settings.env,
        settings.test_account_username if settings.seed_test_account else "未启用",
    )
    content_worker.start()
    search_janitor.start()
    account_router.janitor.start()
    try:
        yield
    finally:
        content_worker.stop()
        search_janitor.stop()
        account_router.janitor.stop()
        logger.info("服务停止，抓取 worker、搜索清理线程与注销清理线程已收尾")


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "MY足迹 App 云端服务：用户名注册/登录、注册验证地址、攻略与评论、"
        "足迹行程、照片视频同步、网页抓取清洗与内容分发、站内私信（会话/seq/已读/撤回/拉黑/SSE）、"
        "管理员后台。密码链路为「客户端 SHA-256 预哈希 + 服务端 bcrypt」。"
    ),
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Accept"],
    max_age=86400,
)


# 公开的 App 内容接口：未登录也能读（发现页/详情），其余 /api/* 一律要求登录
PUBLIC_API_PREFIXES = ("/api/content/feed", "/api/content/items/")


@app.middleware("http")
async def require_login_for_api(request: Request, call_next):
    """后端侧登录门禁：除公开内容外，任何 /api/* 没有有效用户 token 直接 401。

    App 本身已改成「必须登录才能进入」，这里再做一层，防止有人绕过客户端直接调接口。
    """
    path = request.url.path
    if (
        request.method != "OPTIONS"
        and path.startswith("/api/")
        and not any(path.startswith(prefix) for prefix in PUBLIC_API_PREFIXES)
    ):
        authorization = request.headers.get("authorization")
        try:
            require_user(authorization)
        except HTTPException as exc:
            return JSONResponse(
                status_code=exc.status_code,
                content={"detail": exc.detail},
                headers=exc.headers or None,
            )
    return await call_next(request)


@app.middleware("http")
async def guard_and_headers(request: Request, call_next):
    # 1) 请求体大小硬上限：先看 Content-Length，避免超大上传把磁盘/内存打满
    if request.method in {"POST", "PUT", "PATCH"}:
        length = request.headers.get("content-length")
        if length and length.isdigit() and int(length) > MAX_BODY_BYTES:
            return JSONResponse(
                status_code=413,
                content={"detail": f"请求体过大，上限 {MAX_BODY_BYTES // (1024 * 1024)}MB"},
            )

    response = await call_next(request)

    # 2) 安全响应头
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
    response.headers.setdefault("Cross-Origin-Resource-Policy", "same-site")
    if request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https":
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")

    content_type = response.headers.get("content-type", "")
    if "text/html" in content_type:
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
            "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'",
        )
    return response


@app.exception_handler(Exception)
async def unhandled_error(request: Request, exc: Exception):  # pragma: no cover - 兜底
    logger.exception("未处理异常 %s %s", request.method, request.url.path)
    return JSONResponse(status_code=500, content={"detail": "服务器内部错误，请稍后再试"})


app.include_router(auth_router.router)
app.include_router(users_router.router)
app.include_router(guides_router.router)
app.include_router(comments_router.router)
app.include_router(routes_router.router)
app.include_router(sync_router.router)
app.include_router(ai_router.router)
app.include_router(account_router.router)
app.include_router(search_router.router)
app.include_router(search_router.admin_router)
app.include_router(content_router.router)
app.include_router(content_router.admin_router)
app.include_router(messages_router.router)
app.include_router(admin_router.router)


@app.get("/ping", summary="存活探测")
def ping():
    return {"ok": True, "service": settings.app_name, "version": settings.app_version}


@app.get("/healthz", summary="健康检查")
def healthz():
    ok = True
    try:
        from .db import db

        with db() as conn:
            conn.execute("SELECT 1").fetchone()
    except Exception:  # noqa: BLE001
        ok = False
    return JSONResponse(status_code=200 if ok else 503, content={"ok": ok, "db": ok})


@app.get("/uploads/{file_path:path}", include_in_schema=False)
def serve_upload(file_path: str):
    """公开读取上传文件（App 直接用 URL 加载图片，不带 token）。

    只允许 storage 目录内的路径，挡住 `../` 穿越；未知后缀一律按二进制流下发。
    """
    root = settings.storage_path
    target = (root / file_path).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        raise HTTPException(status_code=404, detail="文件不存在")
    if not target.is_file():
        raise HTTPException(status_code=404, detail="文件不存在")

    media_type, _ = mimetypes.guess_type(str(target))
    allowed = settings.image_mimes | settings.video_mimes
    media_type = media_type if media_type in allowed else "application/octet-stream"
    return FileResponse(
        target,
        media_type=media_type,
        headers={"Cache-Control": "public, max-age=31536000, immutable"},
    )


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse(url="/admin", status_code=302)


@app.get("/admin", include_in_schema=False)
def admin_page():
    index = ADMIN_UI_DIR / "index.html"
    if not index.is_file():
        raise HTTPException(status_code=404, detail="管理后台前端未安装")
    return HTMLResponse(index.read_text(encoding="utf-8"))


if ADMIN_UI_DIR.is_dir():
    app.mount("/admin/static", StaticFiles(directory=str(ADMIN_UI_DIR)), name="admin-static")
