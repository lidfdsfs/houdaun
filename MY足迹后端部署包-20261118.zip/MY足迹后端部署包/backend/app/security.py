"""密码、令牌、图形验证码、限流。

密码链路（与安卓端 BackendApi.hashPasswordV2 完全一致）：
    客户端先算 SHA256("myzuji_salt_v2:" + 明文密码)  → 64 位十六进制
    服务端再对这个值做 bcrypt(cost=12) 入库
明文密码永不出网、不进日志，数据库泄露也拿不到可登录的凭据。

JWT 里带 token_version：用户改密、被后台封禁时版本 +1，所有旧 token 立刻失效，
不需要维护一堆黑名单；主动登出则把 jti 写进 revoked_tokens。
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import io
import re
import secrets
import threading
import time
import uuid
from collections import defaultdict, deque
from typing import Any

import bcrypt
import jwt
from PIL import Image, ImageDraw, ImageFont

from .config import get_jwt_secret, settings

PREHASH_PREFIX = "myzuji_salt_v2"
PREHASH_RE = re.compile(r"^[a-f0-9]{64}$")

BCRYPT_ROUNDS = 12

CAPTCHA_ALPHABET = "2345678ACDEFGHJKLMNPQRTUVWXY"  # 去掉易混淆的 0/1/9/B/I/O/S/Z


class AuthError(Exception):
    """认证失败，带 HTTP 状态码与提示。"""

    def __init__(self, message: str, status_code: int = 401):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


# ---------------- 密码 ----------------

def password_prehash(password: str) -> str:
    """固定盐预哈希：不含账号标识，用户名改不改都不影响密码。"""
    raw = f"{PREHASH_PREFIX}:{password}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def is_prehashed(value: str) -> bool:
    return bool(PREHASH_RE.match((value or "").strip().lower()))


def bcrypt_hash_prehashed(prehashed: str) -> str:
    return bcrypt.hashpw(prehashed.encode("utf-8"), bcrypt.gensalt(rounds=BCRYPT_ROUNDS)).decode("utf-8")


def bcrypt_verify(prehashed: str, stored: str) -> bool:
    if not prehashed or not stored:
        return False
    try:
        return bcrypt.checkpw(prehashed.encode("utf-8"), stored.encode("utf-8"))
    except (ValueError, TypeError):
        return False


def constant_time_eq(a: str, b: str) -> bool:
    return hmac.compare_digest(a or "", b or "")


# ---------------- JWT ----------------

def create_token(subject: str, typ: str, ttl_seconds: int, version: int = 0) -> tuple[str, str, int]:
    now = int(time.time())
    exp = now + max(60, ttl_seconds)
    jti = uuid.uuid4().hex
    payload = {
        "sub": str(subject),
        "typ": typ,
        "ver": version,
        "iat": now,
        "exp": exp,
        "jti": jti,
        "iss": "myzuji-backend",
    }
    token = jwt.encode(payload, get_jwt_secret(), algorithm=settings.jwt_algorithm)
    return token, jti, exp


def decode_token(token: str, expected_typ: str) -> dict[str, Any]:
    try:
        payload = jwt.decode(
            token,
            get_jwt_secret(),
            algorithms=[settings.jwt_algorithm],
            options={"require": ["exp", "iat", "sub", "typ"]},
            issuer="myzuji-backend",
        )
    except jwt.ExpiredSignatureError:
        raise AuthError("登录已过期，请重新登录", 401)
    except jwt.InvalidTokenError:
        raise AuthError("登录凭证无效", 401)
    if payload.get("typ") != expected_typ:
        raise AuthError("登录凭证类型不匹配", 401)
    return payload


# ---------------- 图形验证码 ----------------

def _load_font(size: int) -> ImageFont.ImageFont:
    for path in (
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    ):
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def generate_captcha() -> tuple[str, str, str]:
    """生成图形验证码，返回 (captcha_id, base64 PNG, 明文答案)。"""
    length = max(3, min(6, settings.captcha_length))
    code = "".join(secrets.choice(CAPTCHA_ALPHABET) for _ in range(length))

    width, height = 48 + 26 * length, 64
    image = Image.new("RGB", (width, height), (247, 249, 252))
    draw = ImageDraw.Draw(image)

    # 背景噪点：不干扰人眼，但足以破坏简单 OCR
    for _ in range(260):
        x, y = secrets.randbelow(width), secrets.randbelow(height)
        shade = secrets.randbelow(120) + 120
        draw.point((x, y), fill=(shade, shade, shade))

    for _ in range(5):
        x1, y1 = secrets.randbelow(width), secrets.randbelow(height)
        x2, y2 = secrets.randbelow(width), secrets.randbelow(height)
        tone = secrets.randbelow(90) + 150
        draw.line((x1, y1, x2, y2), fill=(tone, tone, tone), width=1)

    font = _load_font(34)
    palette = [(24, 92, 138), (17, 122, 101), (146, 62, 42), (76, 63, 138), (28, 100, 72)]
    for index, ch in enumerate(code):
        color = palette[index % len(palette)]
        x = 20 + index * 26 + secrets.randbelow(4)
        y = 10 + secrets.randbelow(10)
        # PIL 无旋转字形，用轻微纵向偏移模拟手写感
        draw.text((x, y), ch, font=font, fill=color)
    draw.line((0, height - 3, width, height - 4), fill=(150, 150, 160), width=2)

    buf = io.BytesIO()
    image.save(buf, format="PNG", optimize=True)
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return uuid.uuid4().hex, b64, code


def normalize_captcha_answer(text: str) -> str:
    return (text or "").strip().upper().replace(" ", "")


# ---------------- 注册验证码 ----------------

def generate_verify_code() -> str:
    return f"{secrets.randbelow(1_000_000):06d}"


def hash_verify_code(username: str, purpose: str, code: str) -> str:
    raw = f"{PREHASH_PREFIX}|{username.strip().casefold()}|{purpose}|{code}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# ---------------- 限流 ----------------

class RateLimiter:
    """按 (bucket, key) 计滑动窗口。单进程内存态，重启即清，足够挡住暴力破解。

    多进程/多机部署时换成 Redis 即可，接口不变。
    """

    def __init__(self) -> None:
        self._hits: dict[tuple[str, str], deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, bucket: str, key: str, limit: int, window_seconds: int = 60) -> tuple[bool, int]:
        now = time.time()
        with self._lock:
            q = self._hits[(bucket, key)]
            while q and now - q[0] > window_seconds:
                q.popleft()
            if len(q) >= limit:
                retry_after = int(window_seconds - (now - q[0])) + 1
                return False, max(1, retry_after)
            q.append(now)
            # 顺手回收空桶，防止内存随 IP 无限增长
            if len(self._hits) > 5000:
                for k in [k for k, v in self._hits.items() if not v]:
                    self._hits.pop(k, None)
            return True, 0

    def reset(self, bucket: str, key: str) -> None:
        with self._lock:
            self._hits.pop((bucket, key), None)


limiter = RateLimiter()
