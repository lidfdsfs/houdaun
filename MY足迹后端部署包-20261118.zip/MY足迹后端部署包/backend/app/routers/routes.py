"""足迹 / 路线（结构化接口，App 的「我的足迹」页直接读这一组）。"""
from __future__ import annotations

import time

from fastapi import APIRouter, Depends, HTTPException, Query

from ..db import db, json_dump, json_load, tx
from ..deps import require_user
from ..schemas import RouteCreate

router = APIRouter(tags=["足迹"])


def route_obj(row) -> dict:
    return {
        "id": int(row["id"]),
        "title": row["title"],
        "year": int(row["year"]),
        "date": row["date"],
        "cities": json_load(row["cities"], []),
        "cover_seed": int(row["cover_seed"]),
        "special": bool(row["special"]),
        "special_reason": row["special_reason"],
        "note": row["note"],
        "tags": json_load(row["tags"], []),
        "spots": json_load(row["spots"], []),
        "photos": json_load(row["photos"], []),
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(int(row["created_at"]))),
    }


@router.get("/routes/me", summary="我的足迹列表")
def my_routes(
    year: int = Query(default=0, ge=0, le=3000),
    special_only: bool = False,
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=200, ge=1, le=500),
    user: dict = Depends(require_user),
):
    where = ["user_id = ?"]
    params: list[object] = [user["id"]]
    if year:
        where.append("year = ?")
        params.append(year)
    if special_only:
        where.append("special = 1")
    sql = f"SELECT * FROM routes WHERE {' AND '.join(where)} ORDER BY created_at DESC LIMIT ? OFFSET ?"
    params.extend([limit, skip])
    with db() as conn:
        rows = conn.execute(sql, tuple(params)).fetchall()
    return [route_obj(r) for r in rows]


@router.post("/routes", summary="新增足迹")
def create_route(payload: RouteCreate, user: dict = Depends(require_user)):
    now = int(time.time())
    with tx() as conn:
        cur = conn.execute(
            """INSERT INTO routes (user_id, title, cities, date, year, note, cover_seed, special,
                   special_reason, tags, spots, photos, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                user["id"], payload.title, json_dump(payload.cities), payload.date, payload.year,
                payload.note, payload.cover_seed, 1 if payload.special else 0, payload.special_reason,
                json_dump(payload.tags), json_dump([s.model_dump() for s in payload.spots]),
                json_dump(payload.photos), now, now,
            ),
        )
        rid = int(cur.lastrowid)
        _refresh_counters(conn, int(user["id"]))
    return {"id": rid}


@router.get("/routes/{route_id}", summary="足迹详情")
def get_route(route_id: int, user: dict = Depends(require_user)):
    with db() as conn:
        row = conn.execute("SELECT * FROM routes WHERE id = ?", (route_id,)).fetchone()
    if row is None or int(row["user_id"]) != int(user["id"]):
        raise HTTPException(status_code=404, detail="足迹不存在")
    return route_obj(row)


@router.delete("/routes/{route_id}", summary="删除足迹")
def delete_route(route_id: int, user: dict = Depends(require_user)):
    with tx() as conn:
        row = conn.execute("SELECT user_id FROM routes WHERE id = ?", (route_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="足迹不存在")
        if int(row["user_id"]) != int(user["id"]):
            raise HTTPException(status_code=403, detail="无权删除他人的足迹")
        conn.execute("DELETE FROM routes WHERE id = ?", (route_id,))
        _refresh_counters(conn, int(user["id"]))
    return {"ok": True}


def _refresh_counters(conn, user_id: int) -> None:
    """按同步数据与结构化足迹重算个人统计，供 /users/me 显示。"""
    cities: set[str] = set()
    days: set[str] = set()
    count = 0
    for row in conn.execute("SELECT payload FROM sync_footprints WHERE user_id = ?", (user_id,)).fetchall():
        payload = json_load(row["payload"], {}) or {}
        count += 1
        city = str(payload.get("city") or payload.get("name") or "").strip()
        if city:
            cities.add(city)
        date = str(payload.get("date") or "").strip()
        if date:
            days.add(date[:10])
    route_rows = conn.execute("SELECT cities FROM routes WHERE user_id = ?", (user_id,)).fetchall()
    for row in route_rows:
        for city in json_load(row["cities"], []) or []:
            if isinstance(city, str) and city.strip():
                cities.add(city.strip())
    conn.execute(
        "UPDATE users SET cities_count = ?, footprint_count = ?, days_count = ?, updated_at = ? WHERE id = ?",
        (len(cities), count, len(days), int(time.time()), user_id),
    )
