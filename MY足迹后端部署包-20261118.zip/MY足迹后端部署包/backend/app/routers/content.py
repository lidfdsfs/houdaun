"""内容抓取：App 侧增量拉取 + 后台内容源/任务管理。"""
from __future__ import annotations

import time
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query

from .. import content as content_service
from ..db import count_rows, db, json_load, tx
from ..deps import audit, client_ip, optional_user, require_admin
from ..schemas import ContentFetchUrl, ContentItemAction, ContentSourceCreate, ContentSourceUpdate

router = APIRouter(prefix="/api/content", tags=["内容"])


def _iso(ts: int) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(int(ts or 0))) if ts else ""


def _brief(row: Any) -> dict[str, Any]:
    return {
        "id": int(row["id"]),
        "source_id": int(row["source_id"]) if row["source_id"] else 0,
        "title": row["title"],
        "summary": row["summary"],
        "host": row["host"],
        "category": row["category"],
        "author": row["author"],
        "word_count": int(row["word_count"]),
        "images": json_load(row["images"], [])[:3],
        "url": row["url"],
        "published_at": _iso(row["published_at"]),
        "fetched_at": _iso(row["fetched_at"]),
        "status": int(row["status"]),
    }


def _full(row: Any) -> dict[str, Any]:
    data = _brief(row)
    data.update(
        {
            "body_text": row["body_text"],
            "blocks": json_load(row["blocks"], []),
            "images": json_load(row["images"], []),
            "content_hash": row["content_hash"],
            "lang": row["lang"],
            "canonical_url": row["canonical_url"],
        }
    )
    return data


# ---------------- App 侧 ----------------

@router.get("/feed", summary="增量拉取清洗后的内容")
def content_feed(
    since_id: int = Query(default=0, ge=0),
    limit: int = Query(default=20, ge=1, le=100),
    category: str = Query(default="", max_length=40),
    host: str = Query(default="", max_length=120),
    user: dict | None = Depends(optional_user),
):
    """按自增 id 增量拉：客户端记住 next_since，下次带 since_id 即可，不重复不丢。

    返回按 id 升序，客户端顺序追加；没有新内容时 items 为空、next_since 不变。
    """
    where = ["status = 1", "id > ?"]
    params: list[Any] = [since_id]
    if category:
        where.append("category = ?")
        params.append(category)
    if host:
        where.append("host = ?")
        params.append(host)
    with db() as conn:
        rows = conn.execute(
            f"""SELECT * FROM content_items WHERE {' AND '.join(where)}
                ORDER BY id ASC LIMIT ?""",
            (*params, limit),
        ).fetchall()
        total = count_rows(conn, "content_items", "WHERE status = 1")
    items = [_brief(r) for r in rows]
    next_since = items[-1]["id"] if items else since_id
    return {"data": {"items": items, "next_since": next_since, "total": total, "server_time": int(time.time())}}


@router.get("/items/{item_id}", summary="内容详情（正文+结构化段落）")
def content_detail(item_id: int, user: dict | None = Depends(optional_user)):
    with db() as conn:
        row = conn.execute("SELECT * FROM content_items WHERE id = ? AND status = 1", (item_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="内容不存在")
    return {"data": _full(row)}


# ---------------- 后台：总览 ----------------

admin_router = APIRouter(prefix="/admin/api/content", tags=["后台-内容"])


def _source(row: Any) -> dict[str, Any]:
    return {
        "id": int(row["id"]),
        "name": row["name"],
        "kind": row["kind"],
        "list_url": row["list_url"],
        "host": row["host"],
        "url_prefix": row["url_prefix"],
        "default_category": row["default_category"],
        "enabled": bool(row["enabled"]),
        "interval_minutes": int(row["interval_minutes"]),
        "max_items": int(row["max_items"]),
        "last_run_at": _iso(row["last_run_at"]),
        "last_status": row["last_status"],
        "created_at": _iso(row["created_at"]),
    }


@admin_router.get("/overview", summary="内容中心总览")
def content_overview(admin: dict = Depends(require_admin)):
    with db() as conn:
        sources = count_rows(conn, "content_sources")
        enabled = count_rows(conn, "content_sources", "WHERE enabled = 1")
        items = count_rows(conn, "content_items", "WHERE status = 1")
        queued = count_rows(conn, "content_jobs", "WHERE status = 'queued'")
        failed = count_rows(conn, "content_jobs", "WHERE status = 'failed'")
        today = int(time.time()) - 86400
        new_24h = count_rows(conn, "content_items", f"WHERE fetched_at >= {today} AND status = 1")
    return {"data": {"sources": sources, "enabled_sources": enabled, "items": items,
                     "queued_jobs": queued, "failed_jobs": failed, "new_24h": new_24h}}


@admin_router.get("/sources", summary="内容源列表")
def list_sources(admin: dict = Depends(require_admin)):
    with db() as conn:
        rows = conn.execute("SELECT * FROM content_sources ORDER BY enabled DESC, id DESC").fetchall()
    return {"data": [_source(r) for r in rows]}


@admin_router.post("/sources", summary="新建内容源")
def create_source(payload: ContentSourceCreate, admin: dict = Depends(require_admin),
                  ip: str = Depends(client_ip)):
    now = int(time.time())
    with tx() as conn:
        cur = conn.execute(
            """INSERT INTO content_sources
               (name, kind, list_url, host, url_prefix, default_category, enabled,
                interval_minutes, max_items, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                payload.name.strip(), payload.kind, content_service.normalize_url(payload.list_url),
                payload.host.strip(), payload.url_prefix.strip(), payload.default_category.strip(),
                1 if payload.enabled else 0, payload.interval_minutes, payload.max_items, now, now,
            ),
        )
        sid = int(cur.lastrowid)
    audit(admin["name"], "content.source.create", str(sid), payload.list_url, ip)
    with db() as conn:
        row = conn.execute("SELECT * FROM content_sources WHERE id = ?", (sid,)).fetchone()
    return {"data": _source(row)}


@admin_router.patch("/sources/{source_id}", summary="修改内容源")
def update_source(source_id: int, payload: ContentSourceUpdate, admin: dict = Depends(require_admin)):
    fields: list[str] = []
    values: list[Any] = []
    for name in ("name", "host", "url_prefix", "default_category"):
        value = getattr(payload, name)
        if value is not None:
            fields.append(f"{name} = ?")
            values.append(value.strip())
    if payload.enabled is not None:
        fields.append("enabled = ?")
        values.append(1 if payload.enabled else 0)
    if payload.interval_minutes is not None:
        fields.append("interval_minutes = ?")
        values.append(payload.interval_minutes)
    if payload.max_items is not None:
        fields.append("max_items = ?")
        values.append(payload.max_items)
    if not fields:
        raise HTTPException(status_code=400, detail="没有要修改的字段")
    fields.append("updated_at = ?")
    values.extend([int(time.time()), source_id])
    with tx() as conn:
        cur = conn.execute(f"UPDATE content_sources SET {', '.join(fields)} WHERE id = ?", tuple(values))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="内容源不存在")
        row = conn.execute("SELECT * FROM content_sources WHERE id = ?", (source_id,)).fetchone()
    return {"data": _source(row)}


@admin_router.delete("/sources/{source_id}", summary="删除内容源（保留已抓内容）")
def delete_source(source_id: int, admin: dict = Depends(require_admin), ip: str = Depends(client_ip)):
    with tx() as conn:
        cur = conn.execute("DELETE FROM content_sources WHERE id = ?", (source_id,))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="内容源不存在")
    audit(admin["name"], "content.source.delete", str(source_id), "", ip)
    return {"data": {"deleted": source_id}}


@admin_router.post("/sources/{source_id}/run", summary="立即跑一次内容源")
def run_source(source_id: int, admin: dict = Depends(require_admin), ip: str = Depends(client_ip)):
    with db() as conn:
        row = conn.execute("SELECT id FROM content_sources WHERE id = ?", (source_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="内容源不存在")
    job_id = content_service.enqueue_source(source_id)
    audit(admin["name"], "content.source.run", str(source_id), f"job={job_id}", ip)
    return {"data": {"job_id": job_id, "status": "queued"}}


@admin_router.post("/fetch-url", summary="抓取指定 URL（入队）")
def fetch_url(payload: ContentFetchUrl, admin: dict = Depends(require_admin), ip: str = Depends(client_ip)):
    ok, reason = content_service.url_is_allowed(payload.url)
    if not ok:
        raise HTTPException(status_code=400, detail=reason)
    job_id = content_service.enqueue_url(payload.url)
    audit(admin["name"], "content.fetch.url", payload.url[:120], f"job={job_id}", ip)
    return {"data": {"job_id": job_id, "status": "queued"}}


@admin_router.get("/jobs", summary="抓取任务列表")
def list_jobs(
    status: str = Query(default="", max_length=12),
    limit: int = Query(default=30, ge=1, le=200),
    admin: dict = Depends(require_admin),
):
    with db() as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM content_jobs WHERE status = ? ORDER BY id DESC LIMIT ?", (status, limit)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM content_jobs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    data = [
        {
            "id": int(r["id"]),
            "kind": r["kind"],
            "source_id": int(r["source_id"]) if r["source_id"] else 0,
            "url": r["url"],
            "status": r["status"],
            "attempts": int(r["attempts"]),
            "created_items": int(r["created_items"]),
            "error": r["error"],
            "created_at": _iso(r["created_at"]),
            "started_at": _iso(r["started_at"]),
            "finished_at": _iso(r["finished_at"]),
        }
        for r in rows
    ]
    return {"data": data}


@admin_router.post("/jobs/{job_id}/retry", summary="重试失败任务")
def retry_job(job_id: int, admin: dict = Depends(require_admin)):
    with tx() as conn:
        row = conn.execute("SELECT * FROM content_jobs WHERE id = ?", (job_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="任务不存在")
        conn.execute(
            "UPDATE content_jobs SET status = 'queued', attempts = 0, error = '', next_attempt_at = 0 WHERE id = ?",
            (job_id,),
        )
    return {"data": {"job_id": job_id, "status": "queued"}}


@admin_router.get("/items", summary="已入库内容列表")
def list_items(
    q: str = Query(default="", max_length=100),
    source_id: int = Query(default=0, ge=0),
    limit: int = Query(default=30, ge=1, le=200),
    admin: dict = Depends(require_admin),
):
    where: list[str] = []
    params: list[Any] = []
    if q:
        where.append("(title LIKE ? OR summary LIKE ?)")
        params.extend([f"%{q}%", f"%{q}%"])
    if source_id:
        where.append("source_id = ?")
        params.append(source_id)
    sql_where = f"WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        rows = conn.execute(
            f"SELECT * FROM content_items {sql_where} ORDER BY id DESC LIMIT ?", (*params, limit)
        ).fetchall()
    return {"data": [_brief(r) for r in rows]}


@admin_router.get("/items/{item_id}", summary="内容详情")
def admin_item_detail(item_id: int, admin: dict = Depends(require_admin)):
    with db() as conn:
        row = conn.execute("SELECT * FROM content_items WHERE id = ?", (item_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="内容不存在")
    return {"data": _full(row)}


@admin_router.patch("/items/{item_id}", summary="隐藏 / 恢复 / 改分类")
def update_item(item_id: int, payload: ContentItemAction, admin: dict = Depends(require_admin)):
    fields: list[str] = []
    values: list[Any] = []
    if payload.status is not None:
        fields.append("status = ?")
        values.append(payload.status)
    if payload.category is not None:
        fields.append("category = ?")
        values.append(payload.category.strip()[:40])
    if not fields:
        raise HTTPException(status_code=400, detail="没有要修改的字段")
    fields.append("updated_at = ?")
    values.extend([int(time.time()), item_id])
    with tx() as conn:
        cur = conn.execute(f"UPDATE content_items SET {', '.join(fields)} WHERE id = ?", tuple(values))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="内容不存在")
    return {"data": {"item_id": item_id}}


@admin_router.delete("/items/{item_id}", summary="删除内容")
def delete_item(item_id: int, admin: dict = Depends(require_admin), ip: str = Depends(client_ip)):
    with tx() as conn:
        cur = conn.execute("DELETE FROM content_items WHERE id = ?", (item_id,))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="内容不存在")
    audit(admin["name"], "content.item.delete", str(item_id), "", ip)
    return {"data": {"deleted": item_id}}
