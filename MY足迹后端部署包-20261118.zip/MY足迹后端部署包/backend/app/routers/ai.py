"""AI 端点配置接口：Key 云端保管，推理仍在手机上直连。

约定：
- 请求由 App 直接发往模型服务商，服务器不代理、不记录对话；
- 这里只提供配置的加密存取，登录本人才能拉回自己的 Key；
- 所有写操作进审计，但审计里只记条数，不记 Key / URL。
"""
from __future__ import annotations

import time

from fastapi import APIRouter, Depends, HTTPException, Request

from .. import ai_store
from ..deps import audit, client_ip, require_user
from ..schemas import AiConfigIn
from ..security import limiter

router = APIRouter(prefix="/api/ai", tags=["AI 配置"])


def _check_user_rate(user_id: int, bucket: str = "ai_config", limit: int = 30) -> None:
    allowed, retry_after = limiter.check(bucket, str(user_id), limit, 60)
    if not allowed:
        raise HTTPException(
            status_code=429,
            detail=f"操作太频繁，请 {retry_after} 秒后再试",
            headers={"Retry-After": str(retry_after)},
        )


@router.get("/config", summary="读取我的 AI 端点配置（含解密后的 Key，仅本人可见）")
def get_ai_config(request: Request, user: dict = Depends(require_user)):
    _check_user_rate(int(user["id"]))
    data = ai_store.config_for_user(int(user["id"]))
    return {
        "data": {
            "endpoints": data["endpoints"],
            "state": data["state"],
            "count": len(data["endpoints"]),
        }
    }


@router.put("/config", summary="保存 / 更新我的 AI 端点配置（URL 与 Key 加密落库）")
def put_ai_config(payload: AiConfigIn, request: Request, user: dict = Depends(require_user)):
    uid = int(user["id"])
    _check_user_rate(uid)
    items = [item.model_dump() for item in payload.endpoints]
    try:
        result = ai_store.save_config(
            uid,
            items,
            deleted_client_ids=payload.deleted_client_ids,
            state=payload.state,
            updated_at=payload.updated_at or int(time.time()),
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    audit(
        f"user:{uid}",
        "ai.config.save",
        target=f"endpoints={result['total']}",
        detail=f"created={result['created']} updated={result['updated']} deleted={result['deleted']}",
        ip=client_ip(request),
    )
    return {"data": result}


@router.delete("/config", summary="清空我的 AI 端点配置")
def delete_ai_config(request: Request, user: dict = Depends(require_user)):
    uid = int(user["id"])
    _check_user_rate(uid)
    deleted = ai_store.clear_config(uid)
    audit(f"user:{uid}", "ai.config.clear", target="all", detail=f"deleted={deleted}", ip=client_ip(request))
    return {"data": {"deleted": deleted}}
