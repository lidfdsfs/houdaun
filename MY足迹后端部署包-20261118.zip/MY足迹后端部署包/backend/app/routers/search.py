"""服务端检索。

- `POST /api/search`：老接口，走自建 SearXNG 的 JSON 索引；没配置就返回空，App 回退本地。
- `POST /api/search/online`：联网搜索（本轮新增）。按强度由服务器检索 + 抓正文清洗，
  结果只存在于短期会话里，TTL 到期或客户端关闭即删除（见 app/search_online.py）。
"""
from __future__ import annotations

import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException

from .. import search_online
from ..config import settings
from ..deps import audit, client_ip, rate_limit, require_admin, require_user
from ..schemas import SearchOnlineRequest, SearchRequest
from ..security import limiter

router = APIRouter(tags=["检索"])
admin_router = APIRouter(prefix="/admin/api/search", tags=["后台-搜索"])
logger = logging.getLogger("myzuji.search")

SEARCH_RATE = Depends(rate_limit("search", settings.rate_limit_per_minute))

# 来源分层：数字越小越可信（App 侧只用它做展示排序，不做事实判定）
_TIERS: list[tuple[int, tuple[str, ...]]] = [
    (1, ("gov.cn", "gov.hk", "gov.mo", "ncha.gov.cn", "mct.gov.cn", "stats.gov.cn", "cnki.net", "edu.cn", "cas.cn")),
    (2, ("people.com.cn", "xinhuanet.com", "news.cn", "cctv.com", "china.com.cn", "thepaper.cn", "bjnews.com.cn")),
    (3, ("mafengwo.cn", "ctrip.com", "qunar.com", "dianping.com", "douban.com", "zhihu.com", "xiaohongshu.com")),
]


def _tier_for(url: str) -> int:
    host = url.split("//")[-1].split("/")[0].lower()
    for tier, domains in _TIERS:
        if any(host == d or host.endswith("." + d) for d in domains):
            return tier
    return 4


def _site_of(url: str) -> str:
    host = url.split("//")[-1].split("/")[0].lower()
    return host[4:] if host.startswith("www.") else host


@router.post("/api/search", summary="服务端网页索引")
def search(payload: SearchRequest, _: None = SEARCH_RATE):
    if not settings.search_endpoint:
        return {"hits": [], "provider": "none", "detail": "服务端未配置 SEARCH_ENDPOINT，App 将回退本机检索"}

    params = {
        "q": payload.query,
        "format": "json",
        "language": "zh-CN",
        "categories": "general",
        "safesearch": "1",
    }
    try:
        with httpx.Client(timeout=settings.search_timeout_seconds, follow_redirects=True) as client:
            resp = client.get(settings.search_endpoint, params=params)
            resp.raise_for_status()
            data = resp.json()
    except (httpx.HTTPError, ValueError) as exc:
        logger.warning("服务端检索失败: %s", exc)
        return {"hits": [], "provider": "searxng", "detail": "检索后端不可用"}

    raw = data.get("results") or []
    hits = []
    for rank, item in enumerate(raw[: payload.limit], start=1):
        url = str(item.get("url") or "").strip()
        title = str(item.get("title") or "").strip()
        if not url or not title:
            continue
        tier = _tier_for(url)
        hits.append(
            {
                "title": title[:200],
                "snippet": str(item.get("content") or "")[:600],
                "url": url[:500],
                "site": _site_of(url),
                "tier": tier,
                "score": round(max(0.05, 1.0 - (rank - 1) / max(1, payload.limit) * 0.6 - (tier - 1) * 0.08), 3),
                "rank": rank,
                "publishedAt": str(item.get("publishedDate") or "")[:40],
            }
        )
    return {"hits": hits, "provider": "searxng"}


# ---------------- 联网搜索（临时会话） ----------------

def _check_online_rate(user_id: int) -> None:
    allowed, retry_after = limiter.check(
        "search_online", str(user_id), settings.search_rate_per_minute, 60
    )
    if not allowed:
        raise HTTPException(
            status_code=429,
            detail=f"搜索太频繁，请 {retry_after} 秒后再试",
            headers={"Retry-After": str(retry_after)},
        )


@router.post("/api/search/online", summary="联网搜索（服务器检索+清洗，临时保存）")
def search_online_api(payload: SearchOnlineRequest, user: dict = Depends(require_user)):
    if not settings.search_online_enabled:
        raise HTTPException(status_code=503, detail="联网搜索未开启")
    _check_online_rate(int(user["id"]))
    try:
        result = search_online.run_search(int(user["id"]), payload.query.strip(), payload.strength)
    except search_online.SearchError as exc:
        logger.warning("联网搜索失败 user=%s q=%s: %s",
                       user["id"], search_online.query_fingerprint(payload.query), exc)
        raise HTTPException(status_code=502, detail=f"联网搜索暂不可用：{exc}") from exc
    logger.info("联网搜索 user=%s q=%s strength=%s provider=%s results=%s",
                user["id"], search_online.query_fingerprint(payload.query),
                result["strength"], result["provider"], result["result_count"])
    return {
        "data": result,
        "note": f"结果仅在服务器短期保留 {settings.search_session_ttl_seconds} 秒，关闭会话或到期后自动删除",
    }


@router.get("/api/search/sessions", summary="我的临时搜索会话")
def list_search_sessions(user: dict = Depends(require_user)):
    return {"data": search_online.list_sessions(int(user["id"]))}


@router.get("/api/search/sessions/{session_id}", summary="读取临时搜索结果")
def get_search_session(session_id: str, user: dict = Depends(require_user)):
    session = search_online.get_session(int(user["id"]), session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="搜索会话不存在或已清除")
    return {"data": session}


@router.post("/api/search/sessions/{session_id}/close", summary="结束搜索并立即清除结果")
def close_search_session(session_id: str, user: dict = Depends(require_user)):
    cleared = search_online.close_session(int(user["id"]), session_id)
    if not cleared:
        raise HTTPException(status_code=404, detail="搜索会话不存在或已清除")
    return {"data": {"session_id": session_id, "cleared": True}}


@router.delete("/api/search/sessions", summary="清除我的全部搜索结果")
def clear_search_sessions(user: dict = Depends(require_user)):
    deleted = search_online.close_all(int(user["id"]))
    return {"data": {"deleted": deleted}}


@admin_router.get("/overview", summary="搜索会话概况（不含任何内容）")
def search_overview(admin: dict = Depends(require_admin)):
    return {"data": search_online.stats()}


@admin_router.post("/purge", summary="立即清除所有搜索会话")
def search_purge(admin: dict = Depends(require_admin), ip: str = Depends(client_ip)):
    deleted = search_online.purge_all()
    audit(admin["name"], "search.purge_all", detail=f"deleted={deleted}", ip=ip)
    return {"data": {"deleted": deleted}}
