"""管理员后台 API（/admin/api/*）。

与 App 用户体系完全隔离：管理员不建用户记录，只靠 ADMIN_USERNAME / ADMIN_PASSWORD
换取一个 typ=admin 的短效 JWT。所有写操作都会落审计日志。
"""
from __future__ import annotations

import re
import shutil
import tempfile
import time
from pathlib import Path

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse

from ..config import settings
from ..db import db, json_load, tx
from ..deps import audit, client_ip, rate_limit, require_admin
from ..schemas import AdminGuideAction, AdminLogin, AdminUserAction, AdminUserCreate
from ..security import (
    AuthError,
    bcrypt_hash_prehashed,
    constant_time_eq,
    create_token,
    decode_token,
    password_prehash,
)
from ..storage import (
    delete_media_file,
    list_user_files,
    read_user_json,
    user_folder_summary,
    user_root,
)

router = APIRouter(prefix="/admin/api", tags=["管理后台"])

_ADMIN_RATE = Depends(rate_limit("admin_login", 10))


def _admin_token(name: str) -> dict:
    token, jti, exp = create_token(name, "admin", settings.admin_token_ttl_hours * 3600)
    return {"access_token": token, "token_type": "bearer", "expires_in": exp - int(time.time()), "admin": {"name": name}}


@router.post("/login", summary="后台登录")
def admin_login(payload: AdminLogin, request: Request, _: None = _ADMIN_RATE):
    expected_user = settings.admin_username
    expected_pwd = settings.require_admin_password()
    ip = client_ip(request)
    if not (constant_time_eq(payload.username.strip(), expected_user) and constant_time_eq(payload.password, expected_pwd)):
        audit("admin", "login_failed", target=payload.username[:60], ip=ip)
        return JSONResponse(status_code=401, content={"detail": "账号或密码错误"})
    audit(expected_user, "login", detail="后台登录成功", ip=ip)
    return _admin_token(settings.admin_name or expected_user)


@router.post("/logout", summary="后台登出")
def admin_logout(request: Request, authorization: str | None = Header(default=None)):
    try:
        token = (authorization or "")[7:].strip()
        payload = decode_token(token, "admin")
    except (AuthError, IndexError):
        return {"ok": True}
    with tx() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO revoked_tokens (jti, expires_at) VALUES (?,?)",
            (payload.get("jti", ""), int(payload.get("exp", time.time() + 3600))),
        )
    audit(settings.admin_username, "logout", ip=client_ip(request))
    return {"ok": True}


@router.get("/session", summary="校验后台会话")
def admin_session(admin: dict = Depends(require_admin)):
    return {"admin": admin, "now": int(time.time())}


# ---------------- 概览 ----------------

@router.get("/overview", summary="数据概览")
def overview(admin: dict = Depends(require_admin)):
    now = int(time.time())
    with db() as conn:
        users_total = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
        users_active = conn.execute("SELECT COUNT(*) c FROM users WHERE status = 1").fetchone()["c"]
        users_new = conn.execute("SELECT COUNT(*) c FROM users WHERE created_at >= ?", (now - 7 * 86400,)).fetchone()["c"]
        guides_total = conn.execute("SELECT COUNT(*) c FROM guides").fetchone()["c"]
        guides_hidden = conn.execute("SELECT COUNT(*) c FROM guides WHERE status = 0").fetchone()["c"]
        guides_featured = conn.execute("SELECT COUNT(*) c FROM guides WHERE featured = 1").fetchone()["c"]
        comments_total = conn.execute("SELECT COUNT(*) c FROM comments").fetchone()["c"]
        fp_total = conn.execute("SELECT COUNT(*) c FROM sync_footprints").fetchone()["c"]
        rt_total = conn.execute("SELECT COUNT(*) c FROM sync_routes").fetchone()["c"]
        media = conn.execute("SELECT COUNT(*) c, COALESCE(SUM(bytes),0) s FROM media").fetchone()
        settings_users = conn.execute("SELECT COUNT(*) c FROM sync_settings").fetchone()["c"]
        series = conn.execute(
            """SELECT date(created_at, 'unixepoch', '+8 hours') AS d, COUNT(*) c
               FROM users WHERE created_at >= ? GROUP BY d ORDER BY d""",
            (now - 7 * 86400,),
        ).fetchall()
        recent = conn.execute(
            "SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 8"
        ).fetchall()

    db_size = settings.db_file.stat().st_size if settings.db_file.exists() else 0
    return {
        "users": {"total": int(users_total), "active": int(users_active), "new_7d": int(users_new),
                  "banned": int(users_total) - int(users_active)},
        "guides": {"total": int(guides_total), "hidden": int(guides_hidden), "featured": int(guides_featured)},
        "comments": {"total": int(comments_total)},
        "sync": {
            "footprints": int(fp_total),
            "routes": int(rt_total),
            "media_count": int(media["c"]),
            "media_bytes": int(media["s"]),
            "settings_users": int(settings_users),
        },
        "storage": {"db_bytes": db_size, "media_bytes": int(media["s"])},
        "signup_series": [{"date": r["d"], "count": int(r["c"])} for r in series],
        "recent_audit": [dict(r) for r in recent],
    }


# ---------------- 用户 ----------------

@router.get("/users", summary="用户列表")
def list_users(
    q: str = Query(default="", max_length=80),
    status: int | None = Query(default=None, ge=0, le=1),
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=30, ge=1, le=100),
    admin: dict = Depends(require_admin),
):
    where, params = [], []
    if q:
        where.append("(username LIKE ? OR nickname LIKE ?)")
        params.extend([f"%{q}%", f"%{q}%"])
    if status is not None:
        where.append("status = ?")
        params.append(status)
    clause = f"WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        total = conn.execute(f"SELECT COUNT(*) c FROM users {clause}", tuple(params)).fetchone()["c"]
        rows = conn.execute(
            f"""SELECT id, username, nickname, signature, avatar, status, default_public, token_version,
                       followers_count, following_count, likes_received, footprint_count, cities_count,
                       days_count, login_fail_count, locked_until, note, last_login_at, created_at
                FROM users {clause} ORDER BY id DESC LIMIT ? OFFSET ?""",
            (*params, limit, skip),
        ).fetchall()
        guide_counts = {
            int(r["author_id"]): int(r["c"])
            for r in conn.execute("SELECT author_id, COUNT(*) c FROM guides GROUP BY author_id").fetchall()
        }
    items = []
    for r in rows:
        d = dict(r)
        d["guides"] = guide_counts.get(int(r["id"]), 0)
        d["created_at"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(int(r["created_at"])))
        d["last_login_at"] = (
            time.strftime("%Y-%m-%d %H:%M", time.localtime(int(r["last_login_at"]))) if r["last_login_at"] else None
        )
        d["locked_until"] = int(r["locked_until"] or 0)
        items.append(d)
    return {"total": int(total), "items": items}


@router.post("/users", summary="后台创建 App 账号（用户名 + 初始密码）")
def create_user(payload: AdminUserCreate, request: Request, admin: dict = Depends(require_admin)):
    """管理员直接建号，跳过注册验证地址；建完 App 就能用用户名 + 密码登录。"""
    now = int(time.time())
    username = payload.username
    with tx() as conn:
        if conn.execute("SELECT 1 FROM users WHERE username = ? COLLATE NOCASE", (username,)).fetchone():
            raise HTTPException(status_code=409, detail="该用户名已存在")
        stored = bcrypt_hash_prehashed(password_prehash(payload.password.strip()))
        cur = conn.execute(
            """INSERT INTO users (username, nickname, signature, password_hash, pwd_scheme, status,
                   default_public, notif_enabled, share_enabled, token_version,
                   created_at, updated_at)
               VALUES (?,?,?,?,2,1,1,1,1,1,?,?)""",
            (username, payload.nickname, "新加入的旅行者", stored, now, now),
        )
        user_id = int(cur.lastrowid)
    audit(admin["name"], "user_create", target=username, detail=f"user_id={user_id}", ip=client_ip(request))
    return {"ok": True, "data": {"id": user_id, "username": username, "nickname": payload.nickname}}


@router.post("/users/{user_id}/status", summary="封禁 / 解封用户")
def set_user_status(user_id: int, request: Request, status: int = Query(ge=0, le=1),
                    admin: dict = Depends(require_admin)):
    with tx() as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="用户不存在")
        conn.execute(
            "UPDATE users SET status = ?, token_version = token_version + 1, login_fail_count = 0, locked_until = 0 WHERE id = ?",
            (status, user_id),
        )
    audit(admin["name"], "user_status", target=f"user_id={user_id}", detail="解封" if status else "封禁",
          ip=client_ip(request))
    return {"ok": True, "status": status}


@router.post("/users/{user_id}/reset_password", summary="后台重置用户密码")
def admin_reset_password(user_id: int, payload: AdminUserAction, request: Request,
                         admin: dict = Depends(require_admin)):
    new_pwd = (payload.new_password or "").strip()
    if len(new_pwd) < 6:
        raise HTTPException(status_code=400, detail="新密码至少 6 位")
    with tx() as conn:
        row = conn.execute("SELECT username FROM users WHERE id = ?", (user_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="用户不存在")
        stored = bcrypt_hash_prehashed(password_prehash(new_pwd))
        conn.execute(
            """UPDATE users SET password_hash = ?, pwd_scheme = 2, token_version = token_version + 1,
                   login_fail_count = 0, locked_until = 0, updated_at = ? WHERE id = ?""",
            (stored, int(time.time()), user_id),
        )
    audit(admin["name"], "reset_password", target=f"user_id={user_id}", ip=client_ip(request))
    return {"ok": True}


@router.post("/users/{user_id}/note", summary="给用户写备注")
def set_user_note(user_id: int, payload: AdminUserAction, admin: dict = Depends(require_admin)):
    with tx() as conn:
        row = conn.execute("SELECT id FROM users WHERE id = ?", (user_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="用户不存在")
        conn.execute("UPDATE users SET note = ? WHERE id = ?", ((payload.note or "")[:200], user_id))
    return {"ok": True}


@router.delete("/users/{user_id}", summary="删除用户及其数据（含整个用户文件夹）")
def delete_user(user_id: int, request: Request, admin: dict = Depends(require_admin)):
    with db() as conn:
        row = conn.execute("SELECT username FROM users WHERE id = ?", (user_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="用户不存在")
        media_rows = conn.execute("SELECT rel_path FROM media WHERE user_id = ?", (user_id,)).fetchall()
    for m in media_rows:
        delete_media_file(m["rel_path"])
    with tx() as conn:
        conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    # 整个用户文件夹一起删掉（media/vault/data/avatar/cover）
    shutil.rmtree(user_root(user_id), ignore_errors=True)
    audit(admin["name"], "user_delete", target=row["username"], detail=f"user_id={user_id}", ip=client_ip(request))
    return {"ok": True}


# ---------------- 攻略 ----------------

@router.get("/guides", summary="攻略列表")
def list_guides(
    q: str = Query(default="", max_length=80),
    status: int | None = Query(default=None, ge=0, le=1),
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=30, ge=1, le=100),
    admin: dict = Depends(require_admin),
):
    where, params = [], []
    if q:
        where.append("(g.title LIKE ? OR g.city LIKE ? OR u.nickname LIKE ?)")
        params.extend([f"%{q}%"] * 3)
    if status is not None:
        where.append("g.status = ?")
        params.append(status)
    clause = f"WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        total = conn.execute(
            f"SELECT COUNT(*) c FROM guides g JOIN users u ON u.id = g.author_id {clause}", tuple(params)
        ).fetchone()["c"]
        rows = conn.execute(
            f"""SELECT g.id, g.title, g.city, g.days, g.likes, g.favs, g.viewed_count, g.featured,
                       g.status, g.region, g.created_at, u.nickname AS author_name, g.author_id
                FROM guides g JOIN users u ON u.id = g.author_id
                {clause} ORDER BY g.created_at DESC LIMIT ? OFFSET ?""",
            (*params, limit, skip),
        ).fetchall()
    items = []
    for r in rows:
        d = dict(r)
        d["created_at"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(int(r["created_at"])))
        items.append(d)
    return {"total": int(total), "items": items}


@router.patch("/guides/{guide_id}", summary="编辑攻略（推荐/下线/改地区）")
def patch_guide(guide_id: int, payload: AdminGuideAction, request: Request,
                admin: dict = Depends(require_admin)):
    sets, params = [], []
    if payload.featured is not None:
        sets.append("featured = ?")
        params.append(1 if payload.featured else 0)
    if payload.status is not None:
        sets.append("status = ?")
        params.append(payload.status)
    if payload.region is not None:
        sets.append("region = ?")
        params.append(payload.region)
    if payload.title is not None:
        sets.append("title = ?")
        params.append(payload.title)
    if not sets:
        raise HTTPException(status_code=400, detail="没有要修改的字段")
    sets.append("updated_at = ?")
    params.append(int(time.time()))
    with tx() as conn:
        row = conn.execute("SELECT id FROM guides WHERE id = ?", (guide_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="攻略不存在")
        conn.execute(f"UPDATE guides SET {', '.join(sets)} WHERE id = ?", (*params, guide_id))
    audit(admin["name"], "guide_patch", target=f"guide_id={guide_id}", detail=str(payload.model_dump(exclude_none=True)),
          ip=client_ip(request))
    return {"ok": True}


@router.delete("/guides/{guide_id}", summary="删除攻略")
def delete_guide(guide_id: int, request: Request, admin: dict = Depends(require_admin)):
    with tx() as conn:
        row = conn.execute("SELECT title FROM guides WHERE id = ?", (guide_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="攻略不存在")
        conn.execute("DELETE FROM guides WHERE id = ?", (guide_id,))
    audit(admin["name"], "guide_delete", target=f"guide_id={guide_id}", detail=row["title"], ip=client_ip(request))
    return {"ok": True}


# ---------------- 评论 ----------------

@router.get("/comments", summary="评论列表")
def list_comments(
    q: str = Query(default="", max_length=80),
    guide_id: int | None = None,
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=30, ge=1, le=100),
    admin: dict = Depends(require_admin),
):
    where, params = [], []
    if q:
        where.append("(c.content LIKE ? OR u.nickname LIKE ?)")
        params.extend([f"%{q}%"] * 2)
    if guide_id:
        where.append("c.guide_id = ?")
        params.append(guide_id)
    clause = f"WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        total = conn.execute(
            f"SELECT COUNT(*) c FROM comments c JOIN users u ON u.id = c.user_id {clause}", tuple(params)
        ).fetchone()["c"]
        rows = conn.execute(
            f"""SELECT c.id, c.guide_id, c.content, c.likes, c.status, c.parent_id, c.created_at,
                       u.nickname AS user_name, u.username AS user_account, g.title AS guide_title
                FROM comments c JOIN users u ON u.id = c.user_id LEFT JOIN guides g ON g.id = c.guide_id
                {clause} ORDER BY c.created_at DESC LIMIT ? OFFSET ?""",
            (*params, limit, skip),
        ).fetchall()
    items = []
    for r in rows:
        d = dict(r)
        d["created_at"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(int(r["created_at"])))
        items.append(d)
    return {"total": int(total), "items": items}


@router.delete("/comments/{comment_id}", summary="删除评论")
def delete_comment(comment_id: int, request: Request, admin: dict = Depends(require_admin)):
    with tx() as conn:
        row = conn.execute("SELECT content FROM comments WHERE id = ?", (comment_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="评论不存在")
        conn.execute("DELETE FROM comments WHERE id = ?", (comment_id,))
    audit(admin["name"], "comment_delete", target=f"comment_id={comment_id}", detail=row["content"][:80],
          ip=client_ip(request))
    return {"ok": True}


# ---------------- 同步数据 ----------------

@router.get("/footprints", summary="云端足迹（同步数据）")
def list_sync_footprints(
    user_id: int | None = None,
    q: str = Query(default="", max_length=80),
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=30, ge=1, le=100),
    admin: dict = Depends(require_admin),
):
    where, params = [], []
    if user_id:
        where.append("f.user_id = ?")
        params.append(user_id)
    if q:
        where.append("f.payload LIKE ?")
        params.append(f"%{q}%")
    clause = f"WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        total = conn.execute(f"SELECT COUNT(*) c FROM sync_footprints f {clause}", tuple(params)).fetchone()["c"]
        rows = conn.execute(
            f"""SELECT f.id, f.user_id, f.client_id, f.updated_at, f.payload, f.created_at,
                       u.nickname, u.username
                FROM sync_footprints f JOIN users u ON u.id = f.user_id
                {clause} ORDER BY f.updated_at DESC LIMIT ? OFFSET ?""",
            (*params, limit, skip),
        ).fetchall()
    items = []
    for r in rows:
        payload = json_load(r["payload"], {}) or {}
        items.append({
            "id": int(r["id"]),
            "user_id": int(r["user_id"]),
            "nickname": r["nickname"],
            "username": r["username"],
            "client_id": int(r["client_id"]),
            "updated_at": time.strftime("%Y-%m-%d %H:%M", time.localtime(int(r["updated_at"]) / 1000))
            if int(r["updated_at"]) > 10**11 else time.strftime("%Y-%m-%d %H:%M", time.localtime(int(r["updated_at"]))),
            "city": str(payload.get("city") or ""),
            "name": str(payload.get("name") or ""),
            "date": str(payload.get("date") or ""),
            "note": str(payload.get("note") or "")[:120],
            "photos": len(payload.get("photos") or []),
            "has_video": bool(payload.get("videoPath") or payload.get("video_path")),
        })
    return {"total": int(total), "items": items}


@router.delete("/footprints/{user_id}/{client_id}", summary="删除云端足迹")
def delete_sync_footprint(user_id: int, client_id: int, request: Request, admin: dict = Depends(require_admin)):
    with tx() as conn:
        cur = conn.execute("DELETE FROM sync_footprints WHERE user_id = ? AND client_id = ?", (user_id, client_id))
        if (cur.rowcount or 0) == 0:
            raise HTTPException(status_code=404, detail="记录不存在")
    audit(admin["name"], "footprint_delete", target=f"user {user_id} / client {client_id}", ip=client_ip(request))
    return {"ok": True}


@router.get("/routes", summary="云端行程（同步数据）")
def list_sync_routes(
    user_id: int | None = None,
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=30, ge=1, le=100),
    admin: dict = Depends(require_admin),
):
    where, params = [], []
    if user_id:
        where.append("r.user_id = ?")
        params.append(user_id)
    clause = f"WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        total = conn.execute(f"SELECT COUNT(*) c FROM sync_routes r {clause}", tuple(params)).fetchone()["c"]
        rows = conn.execute(
            f"""SELECT r.id, r.user_id, r.client_id, r.updated_at, r.payload, u.nickname
                FROM sync_routes r JOIN users u ON u.id = r.user_id
                {clause} ORDER BY r.updated_at DESC LIMIT ? OFFSET ?""",
            (*params, limit, skip),
        ).fetchall()
    items = []
    for r in rows:
        payload = json_load(r["payload"], {}) or {}
        items.append({
            "id": int(r["id"]),
            "user_id": int(r["user_id"]),
            "nickname": r["nickname"],
            "client_id": int(r["client_id"]),
            "title": str(payload.get("title") or ""),
            "cities": payload.get("cities") or [],
            "date": str(payload.get("date") or ""),
        })
    return {"total": int(total), "items": items}


# ---------------- 媒体 ----------------

@router.get("/media", summary="媒体文件列表")
def list_media(
    user_id: int | None = None,
    kind: str | None = Query(default=None, pattern="^(image|video)$"),
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=30, ge=1, le=100),
    admin: dict = Depends(require_admin),
):
    where, params = [], []
    if user_id:
        where.append("m.user_id = ?")
        params.append(user_id)
    if kind:
        where.append("m.kind = ?")
        params.append(kind)
    clause = f"WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        total = conn.execute(f"SELECT COUNT(*) c FROM media m {clause}", tuple(params)).fetchone()["c"]
        rows = conn.execute(
            f"""SELECT m.id, m.user_id, m.url, m.bytes, m.mime, m.kind, m.created_at, u.nickname
                FROM media m JOIN users u ON u.id = m.user_id
                {clause} ORDER BY m.created_at DESC LIMIT ? OFFSET ?""",
            (*params, limit, skip),
        ).fetchall()
    items = []
    for r in rows:
        d = dict(r)
        d["created_at"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(int(r["created_at"])))
        items.append(d)
    return {"total": int(total), "items": items}


@router.delete("/media/{media_id}", summary="删除媒体文件")
def delete_media(media_id: int, request: Request, admin: dict = Depends(require_admin)):
    with db() as conn:
        row = conn.execute("SELECT rel_path, url FROM media WHERE id = ?", (media_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="文件不存在")
    delete_media_file(row["rel_path"])
    with tx() as conn:
        conn.execute("DELETE FROM media WHERE id = ?", (media_id,))
    audit(admin["name"], "media_delete", target=row["url"], ip=client_ip(request))
    return {"ok": True}


# ---------------- 审计 / 系统 ----------------

@router.get("/audit", summary="审计日志")
def list_audit(
    q: str = Query(default="", max_length=80),
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=50, ge=1, le=200),
    admin: dict = Depends(require_admin),
):
    where, params = [], []
    if q:
        where.append("(actor LIKE ? OR action LIKE ? OR target LIKE ?)")
        params.extend([f"%{q}%"] * 3)
    clause = f"WHERE {' AND '.join(where)}" if where else ""
    with db() as conn:
        total = conn.execute(f"SELECT COUNT(*) c FROM audit_logs {clause}", tuple(params)).fetchone()["c"]
        rows = conn.execute(
            f"SELECT * FROM audit_logs {clause} ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (*params, limit, skip),
        ).fetchall()
    items = []
    for r in rows:
        d = dict(r)
        d["created_at"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(r["created_at"])))
        items.append(d)
    return {"total": int(total), "items": items}


@router.get("/system", summary="系统配置概览（不含密钥）")
def system_info(admin: dict = Depends(require_admin)):
    db_size = settings.db_file.stat().st_size if settings.db_file.exists() else 0
    media_bytes = 0
    with db() as conn:
        media_bytes = int(conn.execute("SELECT COALESCE(SUM(bytes),0) s FROM media").fetchone()["s"])
    storage_bytes = sum(
        f.stat().st_size for f in settings.storage_path.rglob("*") if f.is_file()
    ) if settings.storage_path.exists() else 0
    return {
        "app_name": settings.app_name,
        "version": settings.app_version,
        "env": settings.env,
        "token_ttl_days": settings.token_ttl_days,
        "admin_token_ttl_hours": settings.admin_token_ttl_hours,
        "quota_bytes": settings.user_quota_bytes,
        "max_image_bytes": settings.max_image_bytes,
        "max_video_bytes": settings.max_video_bytes,
        "database_path": str(settings.db_file),
        "db_bytes": db_size,
        "storage_path": str(settings.storage_path),
        "storage_bytes": storage_bytes,
        "media_bytes": media_bytes,
        "search_configured": bool(settings.search_endpoint),
        "test_account": settings.test_account_username if settings.seed_test_account else None,
        "secret_key_source": "env" if settings.secret_key else "data/.secret_key",
    }


# ==================== 用户数据中心 ====================
# 每个用户在磁盘上有一个独立文件夹：storage/users/{id}/
#   media/    足迹照片与视频
#   vault/    隐私空间密文块（端侧加密，后台只能看条目与大小）
#   data/     各分区 JSON 镜像（footprints / routes / plans / music / comments / vault / settings / archive）
#   avatar/ cover/


@router.get("/users/{user_id}/data", summary="用户数据中心（文件夹 + 各分区统计）")
def admin_user_data(user_id: int, admin: dict = Depends(require_admin)):
    with db() as conn:
        u = conn.execute(
            "SELECT id, username, nickname, status, created_at, last_login_at FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if u is None:
            raise HTTPException(status_code=404, detail="用户不存在")
        fps = conn.execute("SELECT COUNT(*) c FROM sync_footprints WHERE user_id = ?", (user_id,)).fetchone()["c"]
        rts = conn.execute("SELECT COUNT(*) c FROM sync_routes WHERE user_id = ?", (user_id,)).fetchone()["c"]
        media = conn.execute(
            "SELECT COUNT(*) c, COALESCE(SUM(bytes),0) s FROM media WHERE user_id = ?", (user_id,)
        ).fetchone()
        vault = conn.execute(
            "SELECT COUNT(*) c, COALESCE(SUM(bytes),0) s FROM vault_files WHERE user_id = ?", (user_id,)
        ).fetchone()
        kinds = conn.execute(
            "SELECT kind, COUNT(*) c, COALESCE(MAX(updated_at),0) m FROM sync_collections WHERE user_id = ? GROUP BY kind",
            (user_id,),
        ).fetchall()
        arch = conn.execute(
            "SELECT sections, bytes, created_at FROM user_archives WHERE user_id = ? ORDER BY created_at DESC LIMIT 1",
            (user_id,),
        ).fetchone()
        st = conn.execute("SELECT updated_at FROM sync_settings WHERE user_id = ?", (user_id,)).fetchone()

    folder = user_folder_summary(user_id)
    collections = [
        {"kind": r["kind"], "count": int(r["c"]), "updated_at": int(r["m"])} for r in kinds
    ]
    return {
        "user": {
            "id": int(u["id"]),
            "username": u["username"],
            "nickname": u["nickname"],
            "status": int(u["status"]),
            "created_at": int(u["created_at"]),
            "last_login_at": int(u["last_login_at"] or 0),
        },
        "folder": folder,
        "counts": {
            "footprints": int(fps),
            "routes": int(rts),
            "media": int(media["c"]),
            "media_bytes": int(media["s"]),
            "vault_files": int(vault["c"]),
            "vault_bytes": int(vault["s"]),
            "settings_updated_at": int(st["updated_at"]) if st else 0,
        },
        "collections": collections,
        "archive": {
            "available": arch is not None,
            "bytes": int(arch["bytes"]) if arch else 0,
            "created_at": int(arch["created_at"]) if arch else 0,
            "sections": json_load(arch["sections"], {}) if arch else {},
        },
    }


@router.get("/users/{user_id}/collections/{kind}", summary="查看某个用户的某个数据分区")
def admin_user_collection(
    user_id: int,
    kind: str,
    limit: int = Query(default=200, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
    admin: dict = Depends(require_admin),
):
    with db() as conn:
        total = int(
            conn.execute(
                "SELECT COUNT(*) c FROM sync_collections WHERE user_id = ? AND kind = ?", (user_id, kind)
            ).fetchone()["c"]
        )
        rows = conn.execute(
            """SELECT client_id, updated_at, payload FROM sync_collections
               WHERE user_id = ? AND kind = ? ORDER BY updated_at DESC LIMIT ? OFFSET ?""",
            (user_id, kind, limit, offset),
        ).fetchall()
    return {
        "kind": kind,
        "total": total,
        "items": [
            {"client_id": r["client_id"], "updated_at": int(r["updated_at"]), "payload": json_load(r["payload"], {})}
            for r in rows
        ],
    }


@router.get("/users/{user_id}/vault", summary="隐私空间条目（密文，不解密）")
def admin_user_vault(user_id: int, admin: dict = Depends(require_admin)):
    with db() as conn:
        rows = conn.execute(
            """SELECT item_id, name, kind, sha256, bytes, rel_path, created_at
               FROM vault_files WHERE user_id = ? ORDER BY created_at DESC""",
            (user_id,),
        ).fetchall()
    return {
        "encrypted": True,
        "note": "端侧 AES-GCM 加密，服务端与后台都不持有密钥，只能看到条目与密文大小",
        "total": len(rows),
        "items": [
            {
                "item_id": r["item_id"],
                "name": r["name"],
                "kind": r["kind"],
                "sha256": r["sha256"],
                "bytes": int(r["bytes"]),
                "url": f"/uploads/{r['rel_path']}",
                "created_at": int(r["created_at"]),
            }
            for r in rows
        ],
    }


@router.get("/users/{user_id}/files", summary="用户文件夹里的文件清单")
def admin_user_files(
    user_id: int,
    limit: int = Query(default=500, ge=1, le=2000),
    admin: dict = Depends(require_admin),
):
    return {"folder": f"users/{user_id}", "files": list_user_files(user_id, limit=limit)}


@router.get("/users/{user_id}/section/{name}", summary="读取用户某个分区的镜像数据（footprints / music / comments / plans / vault / settings / archive）")
def admin_user_section(user_id: int, name: str, admin: dict = Depends(require_admin)):
    if not re.match(r"^[a-z][a-z0-9_]{0,31}$", name or ""):
        raise HTTPException(status_code=400, detail="非法的分区名")
    doc = read_user_json(user_id, name)
    return {"name": name, "available": doc is not None, "data": doc}


@router.get("/users/{user_id}/archive", summary="下载该用户最近一次全量档案 JSON")
def admin_user_archive(user_id: int, admin: dict = Depends(require_admin)):
    doc = read_user_json(user_id, "archive")
    if doc is None:
        raise HTTPException(status_code=404, detail="该用户还没有上传全量档案")
    return JSONResponse(content=doc)


@router.get("/users/{user_id}/export", summary="把用户文件夹打包成 zip 下载")
def admin_user_export(user_id: int, admin: dict = Depends(require_admin)):
    root = user_root(user_id)
    if not any(root.iterdir()):
        raise HTTPException(status_code=404, detail="该用户还没有任何数据")
    tmp_dir = Path(tempfile.mkdtemp(prefix="user-export-"))
    base = tmp_dir / f"user-{user_id}"
    shutil.make_archive(str(base), "zip", root_dir=str(root))
    audit(admin["name"], "export_user_data", target=f"user_id={user_id}", detail=f"导出 users/{user_id} 文件夹")
    return FileResponse(
        str(base) + ".zip",
        media_type="application/zip",
        filename=f"user-{user_id}-data.zip",
    )
