"""攻略评论与楼中楼回复。"""
from __future__ import annotations

import time

from fastapi import APIRouter, Depends, HTTPException, Query

from ..db import db, tx
from ..deps import require_user
from ..schemas import CommentCreate

router = APIRouter(tags=["评论"])


def _comment_obj(row, replies: list[dict] | None = None) -> dict:
    return {
        "id": int(row["id"]),
        "guide_id": int(row["guide_id"]),
        "user_id": int(row["user_id"]),
        "user_name": row["user_name"] if "user_name" in row.keys() else "旅行者",
        "avatar": row["avatar"] if "avatar" in row.keys() else None,
        "content": row["content"],
        "likes": int(row["likes"]),
        "dislikes": int(row["dislikes"]),
        "parent_id": row["parent_id"],
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(int(row["created_at"]))),
        "replies": replies or [],
    }


@router.get("/guides/{guide_id}/comments", summary="攻略评论列表")
def list_comments(guide_id: int, limit: int = Query(default=100, ge=1, le=300)):
    with db() as conn:
        rows = conn.execute(
            """SELECT c.*, u.nickname AS user_name, u.avatar AS avatar
               FROM comments c JOIN users u ON u.id = c.user_id
               WHERE c.guide_id = ? AND c.status = 1
               ORDER BY c.created_at DESC LIMIT ?""",
            (guide_id, limit),
        ).fetchall()
    if not rows:
        return []

    roots: list[dict] = []
    children: dict[int, list[dict]] = {}
    objs: dict[int, dict] = {}
    for row in rows:
        obj = _comment_obj(row)
        objs[int(row["id"])] = obj
        parent = row["parent_id"]
        if parent is None:
            roots.append(obj)
        else:
            children.setdefault(int(parent), []).append(obj)

    def attach(node: dict) -> None:
        kids = children.get(node["id"], [])
        kids.sort(key=lambda x: x["created_at"])
        node["replies"] = kids
        for kid in kids:
            kid["user_name"] = kid["user_name"]
            attach(kid)

    for root in roots:
        attach(root)
    # 顶层按时间倒序（最新在前），回复内部按时间正序
    return roots


@router.post("/comments", summary="发表评论 / 回复")
def create_comment(payload: CommentCreate, user: dict = Depends(require_user)):
    content = payload.content.strip()
    if not content:
        raise HTTPException(status_code=400, detail="评论内容不能为空")

    with tx() as conn:
        guide = conn.execute("SELECT id FROM guides WHERE id = ? AND status = 1", (payload.guide_id,)).fetchone()
        if guide is None:
            raise HTTPException(status_code=404, detail="攻略不存在或已下线")
        if payload.parent_id is not None:
            parent = conn.execute(
                "SELECT id FROM comments WHERE id = ? AND guide_id = ?", (payload.parent_id, payload.guide_id)
            ).fetchone()
            if parent is None:
                raise HTTPException(status_code=400, detail="被回复的评论不存在")
        cur = conn.execute(
            """INSERT INTO comments (guide_id, user_id, parent_id, content, likes, dislikes, status, created_at)
               VALUES (?,?,?,?,0,0,1,?)""",
            (payload.guide_id, user["id"], payload.parent_id, content, int(time.time())),
        )
        cid = int(cur.lastrowid)
    return {"id": cid}


@router.post("/comments/{comment_id}/like", summary="评论点赞 / 取消")
def like_comment(comment_id: int, user: dict = Depends(require_user)):
    with tx() as conn:
        row = conn.execute("SELECT likes FROM comments WHERE id = ? AND status = 1", (comment_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="评论不存在")
        conn.execute("UPDATE comments SET likes = likes + 1 WHERE id = ?", (comment_id,))
        likes = int(conn.execute("SELECT likes FROM comments WHERE id = ?", (comment_id,)).fetchone()["likes"])
    return {"data": {"likes": likes, "liked": True}}
