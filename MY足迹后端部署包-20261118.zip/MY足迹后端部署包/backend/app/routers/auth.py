"""认证：图形验证码、用户名登录、注册验证地址、注销、登出、令牌刷新。

本轮账号体系约定：
- 注册只要「用户名 + 图形验证码 + 密码」；
- 注册前先申请一个**验证地址**，地址里带一次性验证码；用户打开即视为验证通过，
  注册成功后该地址与验证码整条删除，再打开返回 404；
- 登录只认用户名；密码统一为固定盐预哈希；
- 旧版带盐账号无法再校验密码，标记 pwd_scheme=3，由管理员后台重置后登录；
- 同一 IP 最多注册 5 个账号（按注册时记录的 IP 统计）。

与安卓端约定：
- 请求体里的密码是客户端预哈希值（64 位十六进制），服务端再 bcrypt 入库；
- 登录成功返回 {"access_token", "token_type", "expires_in", "user": {...}}。
"""
from __future__ import annotations

import logging
import re
import secrets
import time
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, Request
from fastapi.responses import HTMLResponse, JSONResponse

from ..config import settings
from ..db import db, tx
from ..deps import audit, client_ip, rate_limit, require_user
from ..schemas import LoginRequest, RegisterRequest, VerifyLinkRequest
from ..security import (
    AuthError,
    bcrypt_hash_prehashed,
    bcrypt_verify,
    constant_time_eq,
    create_token,
    decode_token,
    generate_captcha,
    generate_verify_code,
    hash_verify_code,
    limiter,
    normalize_captcha_answer,
)
from ..storage import user_root
import shutil

router = APIRouter(prefix="/auth", tags=["认证"])
logger = logging.getLogger("myzuji.auth")

AUTH_RATE = Depends(rate_limit("auth", settings.auth_rate_limit_per_minute))
MAX_ACCOUNTS_PER_IP = 5
VERIFY_LINK_TTL_SECONDS = 15 * 60


# ---------------- 工具 ----------------

def iso_utc(ts: int | None) -> str | None:
    if not ts:
        return None
    return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def serialize_user(row) -> dict:
    return {
        "id": int(row["id"]),
        "username": row["username"],
        "nickname": row["nickname"],
        "signature": row["signature"],
        "avatar": row["avatar"],
        "cities_count": int(row["cities_count"]),
        "footprint_count": int(row["footprint_count"]),
        "days_count": int(row["days_count"]),
        "followers": int(row["followers_count"]),
        "following": int(row["following_count"]),
        "likes_received": int(row["likes_received"]),
        "default_public": bool(row["default_public"]),
        "notif_enabled": bool(row["notif_enabled"]),
        "share_enabled": bool(row["share_enabled"]),
        "created_at": iso_utc(row["created_at"]),
    }


def auth_error(status: int, message: str, need_captcha: bool = False, **extra) -> JSONResponse:
    body = {"detail": message, "need_captcha": need_captcha}
    body.update(extra)
    return JSONResponse(status_code=status, content=body)


def _new_captcha() -> tuple[str, str, str]:
    with tx() as conn:
        conn.execute("DELETE FROM captchas WHERE expires_at < ?", (int(time.time()) - 600,))
        cid, image, code = generate_captcha()
        now = int(time.time())
        conn.execute(
            "INSERT INTO captchas (id, code, expires_at, used, created_at) VALUES (?,?,?,0,?)",
            (cid, normalize_captcha_answer(code), now + settings.captcha_ttl_seconds, now),
        )
    return cid, image, code


def _consume_captcha(captcha_id: str | None, captcha_text: str | None) -> bool:
    if not captcha_id or not captcha_text:
        return False
    answer = normalize_captcha_answer(captcha_text)
    with tx() as conn:
        row = conn.execute("SELECT * FROM captchas WHERE id = ?", (captcha_id,)).fetchone()
        if row is None or int(row["used"]) != 0:
            return False
        if int(row["expires_at"]) < int(time.time()):
            conn.execute("UPDATE captchas SET used = 1 WHERE id = ?", (captcha_id,))
            return False
        conn.execute("UPDATE captchas SET used = 1 WHERE id = ?", (captcha_id,))
        return constant_time_eq(row["code"], answer)


def _find_user(conn, username: str):
    return conn.execute(
        "SELECT * FROM users WHERE username = ? COLLATE NOCASE", (username,)
    ).fetchone()


def _username_exists(conn, username: str) -> bool:
    return conn.execute(
        "SELECT 1 FROM users WHERE username = ? COLLATE NOCASE", (username,)
    ).fetchone() is not None


def _verify_password(row, payload: LoginRequest) -> bool:
    scheme = int(row["pwd_scheme"] or 2)
    if scheme != 2:
        return False
    return bcrypt_verify(payload.password_hash, row["password_hash"])


def _registration_ip_count(conn, ip: str) -> int:
    return int(
        conn.execute("SELECT COUNT(*) AS c FROM users WHERE reg_ip = ?", (ip,)).fetchone()["c"]
    )


def _public_base(request: Request) -> str:
    base = str(request.base_url).rstrip("/")
    # 反代常用 X-Forwarded-Proto；uvicorn 已按 TRUST_PROXY_HEADERS 处理，这里兜底 http
    return base


# ---------------- 接口 ----------------

@router.get("/captcha", summary="获取图形验证码")
def get_captcha(request: Request, _: None = AUTH_RATE):
    cid, image, _code = _new_captcha()
    return {"captcha_id": cid, "image": image}


@router.post("/login", summary="用户名 + 密码登录")
def login(payload: LoginRequest, request: Request, _: None = AUTH_RATE):
    login_id = payload.username.strip()
    ip = client_ip(request)
    now = int(time.time())

    with db() as conn:
        row = _find_user(conn, login_id)

    if row is None:
        limiter.check("login_fail_ip", ip, settings.login_lock_after * 3, 600)
        return auth_error(401, "用户名或密码错误")

    locked_until = int(row["locked_until"] or 0)
    if locked_until > now:
        return auth_error(429, f"登录失败次数过多，请 {max(1, (locked_until - now) // 60)} 分钟后再试")

    fail_count = int(row["login_fail_count"] or 0)
    if fail_count >= settings.login_captcha_after:
        if not _consume_captcha(payload.captcha_id, payload.captcha_text):
            return auth_error(401, "需要图形验证码", need_captcha=True)

    if int(row["status"]) != 1:
        return auth_error(403, "账号已被停用，请联系管理员")

    if int(row["pwd_scheme"] or 2) != 2:
        return auth_error(403, "该账号的旧密码已停用，请联系管理员重置密码后再登录")

    if not _verify_password(row, payload):
        fail_count += 1
        lock_until = now + settings.login_lock_minutes * 60 if fail_count >= settings.login_lock_after else 0
        with tx() as conn:
            conn.execute(
                "UPDATE users SET login_fail_count = ?, locked_until = ? WHERE id = ?",
                (fail_count, lock_until, row["id"]),
            )
        if lock_until:
            audit("system", "login_locked", target=login_id, detail=f"连续失败 {fail_count} 次", ip=ip)
            return auth_error(429, f"登录失败次数过多，请 {settings.login_lock_minutes} 分钟后再试")
        return auth_error(
            401,
            "用户名或密码错误",
            need_captcha=fail_count >= settings.login_captcha_after,
        )

    token, _jti, exp = create_token(str(row["id"]), "user", settings.token_ttl_days * 86400, int(row["token_version"]))
    with tx() as conn:
        conn.execute(
            "UPDATE users SET login_fail_count = 0, locked_until = 0, last_login_at = ? WHERE id = ?",
            (now, row["id"]),
        )
        fresh = conn.execute("SELECT * FROM users WHERE id = ?", (row["id"],)).fetchone()
    limiter.reset("login_fail_ip", ip)

    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": exp - now,
        "user": serialize_user(fresh),
    }


@router.post("/register_link", summary="生成注册验证地址（地址内含一次性验证码）")
def register_link(payload: VerifyLinkRequest, request: Request, _: None = AUTH_RATE):
    ip = client_ip(request)
    if not _consume_captcha(payload.captcha_id, payload.captcha_text):
        return auth_error(400, "图形验证码错误或已过期")

    with db() as conn:
        if _username_exists(conn, payload.username):
            return auth_error(409, "该用户名已被注册")

    allowed, retry_after = limiter.check("register_link_ip", ip, 10, 3600)
    if not allowed:
        return auth_error(429, f"生成太频繁，请 {retry_after} 秒后再试")

    now = int(time.time())
    link_id = secrets.token_urlsafe(18)
    code = generate_verify_code()
    url = f"{_public_base(request)}/auth/verify/{link_id}?code={code}"

    with tx() as conn:
        # 同名只保留最新一条，旧地址立即失效
        conn.execute("DELETE FROM verify_links WHERE username = ? COLLATE NOCASE", (payload.username,))
        conn.execute(
            """INSERT INTO verify_links (id, username, code_hash, verified_at, used, ip, expires_at, created_at)
               VALUES (?,?,?,0,0,?,?,?)""",
            (
                link_id,
                payload.username,
                hash_verify_code(payload.username.casefold(), "verify", code),
                ip,
                now + VERIFY_LINK_TTL_SECONDS,
                now,
            ),
        )
    audit("system", "register_link_create", target=payload.username, ip=ip)
    return {
        "verify_url": url,
        "expires_in": VERIFY_LINK_TTL_SECONDS,
        "detail": "请在浏览器打开该地址完成验证，验证后回 App 注册；注册成功地址立即作废",
    }


@router.get("/verify/{link_id}", summary="打开注册验证地址（成功后该地址立即失效）")
def verify_link(request: Request, link_id: str, code: str = ""):
    ip = client_ip(request) if request is not None else ""
    now = int(time.time())

    def page(title: str, message: str, ok: bool) -> HTMLResponse:
        color = "#0f766e" if ok else "#b91c1c"
        return HTMLResponse(
            f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title>{title}</title></head>
            <body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
                         font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f6f6f4">
              <div style="max-width:420px;padding:36px 30px;background:#fff;border-radius:18px;
                          box-shadow:0 12px 40px rgba(0,0,0,.08);text-align:center">
                <div style="font-size:40px;margin-bottom:12px">{'✅' if ok else '⚠️'}</div>
                <h2 style="margin:0 0 10px;color:{color};font-size:20px">{title}</h2>
                <p style="margin:0;color:#555;font-size:14px;line-height:1.7">{message}</p>
              </div>
            </body></html>""",
            status_code=200 if ok else 400,
        )

    with tx() as conn:
        row = conn.execute("SELECT * FROM verify_links WHERE id = ?", (link_id,)).fetchone()
        if row is None:
            return page("地址已失效", "该验证地址已被使用或已删除，请回 App 重新获取。", False)
        if int(row["used"]) != 0 or int(row["verified_at"]) != 0:
            return page("已验证", "该地址已经完成验证，请回 App 直接注册。", True)
        if int(row["expires_at"]) < now:
            return page("地址已过期", "验证地址超过 15 分钟，请回 App 重新获取。", False)
        expected = row["code_hash"]
        actual = hash_verify_code(str(row["username"]).casefold(), "verify", (code or "").strip())
        if not constant_time_eq(expected, actual):
            return page("验证码不正确", "请使用 App 展示的完整地址打开，不要改动链接参数。", False)
        conn.execute("UPDATE verify_links SET verified_at = ? WHERE id = ?", (now, link_id))

    audit("system", "register_link_verified", target=row["username"], ip=ip)
    return page("验证成功", "请回到 MY足迹 完成注册；注册完成后本地址会自动清除。", True)


@router.post("/register", summary="注册（用户名 + 图形验证码 + 已验证的地址）")
def register(payload: RegisterRequest, request: Request, _: None = AUTH_RATE):
    ip = client_ip(request)
    if not _consume_captcha(payload.captcha_id, payload.captcha_text):
        return auth_error(400, "图形验证码错误或已过期")

    now = int(time.time())
    with tx() as conn:
        if _username_exists(conn, payload.username):
            return auth_error(409, "该用户名已被注册，请直接登录")
        if _registration_ip_count(conn, ip) >= MAX_ACCOUNTS_PER_IP:
            logger.warning("注册 IP 达上限 username=%s ip=%s", payload.username, ip)
            return auth_error(403, f"当前网络最多注册 {MAX_ACCOUNTS_PER_IP} 个账号")

        link = conn.execute(
            """SELECT id FROM verify_links
               WHERE username = ? COLLATE NOCASE AND used = 0 AND verified_at > 0 AND expires_at > ?
               ORDER BY created_at DESC LIMIT 1""",
            (payload.username, now),
        ).fetchone()
        if link is None:
            return auth_error(400, "请先打开注册验证地址完成验证")

        nickname = payload.nickname or payload.username
        stored = bcrypt_hash_prehashed(payload.password_hash)
        cur = conn.execute(
            """INSERT INTO users (username, reg_ip, nickname, signature, password_hash, pwd_scheme,
                   status, default_public, notif_enabled, share_enabled, token_version, created_at, updated_at)
               VALUES (?,?,?,?,?,2,1,1,1,1,1,?,?)""",
            (payload.username, ip, nickname, "", stored, now, now),
        )
        uid = int(cur.lastrowid)
        # 注册完成：这个用户名下的所有验证地址与验证码彻底清除
        conn.execute("DELETE FROM verify_links WHERE username = ? COLLATE NOCASE", (payload.username,))
        row = conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()

    token, _jti, exp = create_token(str(uid), "user", settings.token_ttl_days * 86400, int(row["token_version"]))
    audit("system", "register", target=payload.username, detail=f"user_id={uid}", ip=ip)
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": exp - now,
        "user": serialize_user(row),
    }


@router.post("/logout", summary="登出（当前 token 立即失效）")
def logout(request: Request, authorization: str | None = Header(default=None)):
    try:
        token = (authorization or "")[7:].strip()
        payload = decode_token(token, "user")
    except (AuthError, IndexError):
        return {"ok": True}
    with tx() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO revoked_tokens (jti, expires_at) VALUES (?,?)",
            (payload.get("jti", ""), int(payload.get("exp", time.time() + 3600))),
        )
    return {"ok": True}


@router.post("/refresh", summary="刷新登录令牌")
def refresh(user: dict = Depends(require_user)):
    token, _jti, exp = create_token(
        str(user["id"]), "user", settings.token_ttl_days * 86400, int(user["token_version"])
    )
    return {"access_token": token, "token_type": "bearer", "expires_in": exp - int(time.time())}
