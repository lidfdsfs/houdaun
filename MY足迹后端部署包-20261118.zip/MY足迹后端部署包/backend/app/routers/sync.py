"""App 云端同步：足迹、行程、设置、媒体、全量档案。

语义（与 App 的 CloudSync 一致）：
- 本机是权威：批量 upsert，按 (user_id, client_id) 幂等，updated_at 小者不覆盖；
- 删除用 deleted_client_ids 一次性告知，服务端删掉后返回 deleted 条数；
- 媒体按 sha256 去重，每人 2GB 配额，超过返回 413；
- 单条 payload 上限 1MB，整批 8MB，设置快照 256KB；
- 全量档案（足迹/行程/计划/音乐收藏/评论/隐私空间索引/设置）一次上传，
  服务端存到 users/{id}/data/ 下并镜像成独立 JSON，后台可直接浏览。
"""
from __future__ import annotations

import json
import os
import re
import time
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile

from ..config import settings
from ..db import db, json_dump, json_load, tx
from ..deps import require_user
from ..schemas import CollectionBatch, SettingsSync, SnapshotIn, SyncBatch
from .. import ai_store
from ..storage import (
    read_user_json,
    save_encrypted_blob,
    save_upload,
    user_data_dir,
    user_root,
    write_user_json,
)
from .routes import _refresh_counters
from .guides import _SELECT as GUIDE_SELECT, guide_obj

router = APIRouter(prefix="/api/sync", tags=["同步"])

ITEM_LIMIT = 1024 * 1024          # 单条 1MB
BATCH_LIMIT = 8 * 1024 * 1024     # 整批 8MB
SETTINGS_LIMIT = 256 * 1024       # 设置快照 256KB
ARCHIVE_LIMIT = 16 * 1024 * 1024  # 全量档案 16MB
COLLECTION_KINDS = {"music", "comments", "plans", "vault", "notes", "watch", "custom"}
_KIND_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")

_TABLES = {
    "footprints": ("sync_footprints", "footprints"),
    "routes": ("sync_routes", "routes"),
}


def _table(kind: str) -> str:
    if kind not in _TABLES:
        raise HTTPException(status_code=404, detail="未知的同步类型")
    return _TABLES[kind][0]


def _used_bytes(conn, user_id: int) -> int:
    row = conn.execute(
        """SELECT (SELECT COALESCE(SUM(bytes), 0) FROM media WHERE user_id = ?)
                + (SELECT COALESCE(SUM(bytes), 0) FROM vault_files WHERE user_id = ?) AS s""",
        (user_id, user_id),
    ).fetchone()
    return int(row["s"])


def _upsert_batch(user_id: int, kind: str, payload: SyncBatch) -> dict[str, int]:
    table = _table(kind)
    now = int(time.time())
    created = updated = unchanged = deleted = 0

    # 先做尺寸校验，避免大事务里半途失败
    encoded: list[tuple[int, int, str]] = []
    total = 0
    for item in payload.items:
        raw = json.dumps(item.payload, ensure_ascii=False, separators=(",", ":"))
        if len(raw.encode("utf-8")) > ITEM_LIMIT:
            raise HTTPException(
                status_code=413,
                detail=f"单条数据超过 {ITEM_LIMIT // 1024}KB，请减少照片后重试（client_id={item.client_id}）",
            )
        total += len(raw)
        if total > BATCH_LIMIT:
            raise HTTPException(status_code=413, detail="本批数据过大，请分批上传")
        encoded.append((int(item.client_id), int(item.updated_at), raw))

    with tx() as conn:
        for client_id, updated_at, raw in encoded:
            existing = conn.execute(
                f"SELECT id, updated_at FROM {table} WHERE user_id = ? AND client_id = ?",
                (user_id, client_id),
            ).fetchone()
            if existing is None:
                conn.execute(
                    f"INSERT INTO {table} (user_id, client_id, updated_at, payload, created_at) VALUES (?,?,?,?,?)",
                    (user_id, client_id, updated_at, raw, now),
                )
                created += 1
            elif int(existing["updated_at"]) < updated_at:
                conn.execute(
                    f"UPDATE {table} SET updated_at = ?, payload = ? WHERE id = ?",
                    (updated_at, raw, existing["id"]),
                )
                updated += 1
            else:
                unchanged += 1

        for client_id in payload.deleted_client_ids:
            cur = conn.execute(
                f"DELETE FROM {table} WHERE user_id = ? AND client_id = ?", (user_id, int(client_id))
            )
            deleted += cur.rowcount or 0

        if kind == "footprints":
            _refresh_counters(conn, user_id)

    return {"created": created, "updated": updated, "unchanged": unchanged, "deleted": deleted}


@router.get("/status", summary="同步水位与配额")
def sync_status(user: dict = Depends(require_user)):
    with db() as conn:
        fp = conn.execute(
            "SELECT COUNT(*) AS c, COALESCE(MAX(updated_at),0) AS m FROM sync_footprints WHERE user_id = ?",
            (user["id"],),
        ).fetchone()
        rt = conn.execute(
            "SELECT COUNT(*) AS c, COALESCE(MAX(updated_at),0) AS m FROM sync_routes WHERE user_id = ?",
            (user["id"],),
        ).fetchone()
        st = conn.execute("SELECT updated_at FROM sync_settings WHERE user_id = ?", (user["id"],)).fetchone()
        media = conn.execute(
            "SELECT COUNT(*) AS c, COALESCE(SUM(bytes),0) AS s FROM media WHERE user_id = ?", (user["id"],)
        ).fetchone()
        used = int(media["s"])
    return {
        "user_id": int(user["id"]),
        "quota_bytes": settings.user_quota_bytes,
        "used_bytes": used,
        "remaining_bytes": max(0, settings.user_quota_bytes - used),
        "footprints": int(fp["c"]),
        "footprints_updated_at": int(fp["m"]),
        "routes": int(rt["c"]),
        "routes_updated_at": int(rt["m"]),
        "media_count": int(media["c"]),
        "settings_updated_at": int(st["updated_at"]) if st else 0,
        "limits": {"item_bytes": ITEM_LIMIT, "batch_bytes": BATCH_LIMIT, "settings_bytes": SETTINGS_LIMIT},
    }


@router.get("/footprints", summary="拉取服务端足迹")
def list_footprints(
    since: int = Query(default=0, ge=0),
    limit: int = Query(default=500, ge=1, le=2000),
    user: dict = Depends(require_user),
):
    with db() as conn:
        rows = conn.execute(
            """SELECT client_id, updated_at, payload FROM sync_footprints
               WHERE user_id = ? AND updated_at > ? ORDER BY updated_at ASC LIMIT ?""",
            (user["id"], since, limit),
        ).fetchall()
    return [
        {"client_id": int(r["client_id"]), "updated_at": int(r["updated_at"]), "payload": json_load(r["payload"], {})}
        for r in rows
    ]


@router.put("/footprints", summary="批量上传足迹（幂等）")
def put_footprints(payload: SyncBatch, user: dict = Depends(require_user)):
    return _upsert_batch(int(user["id"]), "footprints", payload)


@router.delete("/footprints/{client_id}", summary="删除一条服务端足迹")
def delete_footprint(client_id: int, user: dict = Depends(require_user)):
    with tx() as conn:
        cur = conn.execute(
            "DELETE FROM sync_footprints WHERE user_id = ? AND client_id = ?", (user["id"], client_id)
        )
        if (cur.rowcount or 0) == 0:
            raise HTTPException(status_code=404, detail="足迹不存在")
        _refresh_counters(conn, int(user["id"]))
    return {"ok": True}


@router.get("/routes", summary="拉取服务端行程")
def list_routes(
    since: int = Query(default=0, ge=0),
    limit: int = Query(default=500, ge=1, le=2000),
    user: dict = Depends(require_user),
):
    with db() as conn:
        rows = conn.execute(
            """SELECT client_id, updated_at, payload FROM sync_routes
               WHERE user_id = ? AND updated_at > ? ORDER BY updated_at ASC LIMIT ?""",
            (user["id"], since, limit),
        ).fetchall()
    return [
        {"client_id": int(r["client_id"]), "updated_at": int(r["updated_at"]), "payload": json_load(r["payload"], {})}
        for r in rows
    ]


@router.put("/routes", summary="批量上传行程（幂等）")
def put_routes(payload: SyncBatch, user: dict = Depends(require_user)):
    return _upsert_batch(int(user["id"]), "routes", payload)


@router.delete("/routes/{client_id}", summary="删除一条服务端行程")
def delete_synced_route(client_id: int, user: dict = Depends(require_user)):
    with tx() as conn:
        cur = conn.execute("DELETE FROM sync_routes WHERE user_id = ? AND client_id = ?", (user["id"], client_id))
        if (cur.rowcount or 0) == 0:
            raise HTTPException(status_code=404, detail="行程不存在")
    return {"ok": True}


@router.get("/settings", summary="读取设置快照")
def get_settings_snapshot(user: dict = Depends(require_user)):
    with db() as conn:
        row = conn.execute("SELECT payload, updated_at FROM sync_settings WHERE user_id = ?", (user["id"],)).fetchone()
    if row is None:
        return {"payload": {}, "updated_at": 0}
    return {"payload": json_load(row["payload"], {}), "updated_at": int(row["updated_at"])}


@router.put("/settings", summary="上传设置快照")
def put_settings_snapshot(payload: SettingsSync, user: dict = Depends(require_user)):
    raw = json_dump(payload.payload)
    if len(raw.encode("utf-8")) > SETTINGS_LIMIT:
        raise HTTPException(status_code=413, detail=f"设置快照超过 {SETTINGS_LIMIT // 1024}KB")

    blocked = ("token", "password", "secret", "api_key")
    clean = {k: v for k, v in payload.payload.items() if not any(word in k.lower() for word in blocked)}
    raw = json_dump(clean)
    if len(raw.encode("utf-8")) > SETTINGS_LIMIT:
        raise HTTPException(status_code=413, detail=f"设置快照超过 {SETTINGS_LIMIT // 1024}KB")

    with tx() as conn:
        conn.execute(
            """INSERT INTO sync_settings (user_id, payload, updated_at) VALUES (?,?,?)
               ON CONFLICT(user_id) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at""",
            (user["id"], raw, int(payload.updated_at)),
        )
    return {"ok": True, "updated_at": int(payload.updated_at)}


@router.post("/media", summary="上传照片 / 视频（sha256 去重）")
def upload_media(file: UploadFile = File(...), user: dict = Depends(require_user)):
    with db() as conn:
        used = _used_bytes(conn, int(user["id"]))
    if used >= settings.user_quota_bytes:
        raise HTTPException(status_code=413, detail="云空间已满（2GB），请清理后再上传")

    saved = save_upload(file, int(user["id"]), category="media")

    with tx() as conn:
        existing = conn.execute(
            "SELECT url, bytes, mime FROM media WHERE user_id = ? AND sha256 = ?",
            (user["id"], saved["sha256"]),
        ).fetchone()
        if existing:
            return {
                "url": existing["url"],
                "sha256": saved["sha256"],
                "bytes": int(existing["bytes"]),
                "mime": existing["mime"],
                "dedup": True,
            }
        if used + int(saved["bytes"]) > settings.user_quota_bytes:
            raise HTTPException(status_code=413, detail="云空间不足（每人 2GB）")
        conn.execute(
            """INSERT INTO media (user_id, sha256, url, rel_path, bytes, mime, kind, created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (
                user["id"], saved["sha256"], saved["url"], saved["rel_path"], saved["bytes"],
                saved["mime"], saved["kind"], int(time.time()),
            ),
        )
    return {
        "url": saved["url"],
        "sha256": saved["sha256"],
        "bytes": saved["bytes"],
        "mime": saved["mime"],
        "dedup": saved["dedup"],
    }


@router.get("/snapshot", summary="整库快照（换机恢复用）")
def get_snapshot(user: dict = Depends(require_user)):
    with db() as conn:
        fps = conn.execute(
            "SELECT client_id, updated_at, payload FROM sync_footprints WHERE user_id = ? ORDER BY updated_at",
            (user["id"],),
        ).fetchall()
        rts = conn.execute(
            "SELECT client_id, updated_at, payload FROM sync_routes WHERE user_id = ? ORDER BY updated_at",
            (user["id"],),
        ).fetchall()
        st = conn.execute("SELECT payload, updated_at FROM sync_settings WHERE user_id = ?", (user["id"],)).fetchone()
    return {
        "footprints": [
            {"client_id": int(r["client_id"]), "updated_at": int(r["updated_at"]), "payload": json_load(r["payload"], {})}
            for r in fps
        ],
        "routes": [
            {"client_id": int(r["client_id"]), "updated_at": int(r["updated_at"]), "payload": json_load(r["payload"], {})}
            for r in rts
        ],
        "settings": json_load(st["payload"], {}) if st else {},
        "settings_updated_at": int(st["updated_at"]) if st else 0,
    }


@router.post("/snapshot", summary="用快照覆盖服务端（replace_all 时先清空）")
def post_snapshot(payload: SnapshotIn, user: dict = Depends(require_user)):
    fps = SyncBatch(items=payload.footprints, deleted_client_ids=[])
    rts = SyncBatch(items=payload.routes, deleted_client_ids=[])
    if payload.replace_all:
        with tx() as conn:
            conn.execute("DELETE FROM sync_footprints WHERE user_id = ?", (user["id"],))
            conn.execute("DELETE FROM sync_routes WHERE user_id = ?", (user["id"],))
    fp_res = _upsert_batch(int(user["id"]), "footprints", fps)
    rt_res = _upsert_batch(int(user["id"]), "routes", rts)
    if payload.settings is not None:
        raw = json_dump(payload.settings)
        if len(raw.encode("utf-8")) > SETTINGS_LIMIT:
            raise HTTPException(status_code=413, detail="设置快照过大")
        with tx() as conn:
            conn.execute(
                """INSERT INTO sync_settings (user_id, payload, updated_at) VALUES (?,?,?)
                   ON CONFLICT(user_id) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at""",
                (user["id"], raw, int(payload.settings_updated_at or time.time() * 1000)),
            )
    return {"footprints": fp_res, "routes": rt_res, "replace_all": bool(payload.replace_all)}


# ============================ 通用分区 ============================
# 音乐收藏、评论、计划、隐私空间索引……客户端想传什么就传什么，
# 服务端不预设字段：按 (user, kind, client_id) 幂等存，并镜像成 users/{id}/data/{kind}.json。


def _check_kind(kind: str) -> str:
    if not _KIND_RE.match(kind or ""):
        raise HTTPException(status_code=400, detail="分区名只能用小写字母、数字、下划线，最长 32 位")
    return kind


def _mirror_collection(user_id: int, kind: str) -> int:
    with db() as conn:
        rows = conn.execute(
            "SELECT client_id, updated_at, payload FROM sync_collections WHERE user_id = ? AND kind = ? ORDER BY updated_at",
            (user_id, kind),
        ).fetchall()
    items = [
        {"client_id": r["client_id"], "updated_at": int(r["updated_at"]), "payload": json_load(r["payload"], {})}
        for r in rows
    ]
    write_user_json(user_id, kind, items)
    return len(items)


@router.put("/collections/{kind}", summary="批量上传自定义分区（音乐收藏 / 评论 / 计划 / 隐私空间索引…）")
def put_collection(kind: str, payload: CollectionBatch, user: dict = Depends(require_user)):
    kind = _check_kind(kind)
    uid = int(user["id"])
    encoded: list[tuple[str, int, str]] = []
    total = 0
    for item in payload.items:
        raw = json_dump(item.payload)
        size = len(raw.encode("utf-8"))
        if size > ITEM_LIMIT:
            raise HTTPException(status_code=413, detail=f"单条数据超过 {ITEM_LIMIT // 1024}KB（client_id={item.client_id}）")
        total += size
        if total > BATCH_LIMIT:
            raise HTTPException(status_code=413, detail="本批数据过大，请分批上传")
        encoded.append((str(item.client_id), int(item.updated_at), raw))

    created = updated = unchanged = deleted = 0
    with tx() as conn:
        for client_id, updated_at, raw in encoded:
            existing = conn.execute(
                "SELECT id, updated_at FROM sync_collections WHERE user_id = ? AND kind = ? AND client_id = ?",
                (uid, kind, client_id),
            ).fetchone()
            if existing is None:
                conn.execute(
                    """INSERT INTO sync_collections (user_id, kind, client_id, updated_at, payload, created_at)
                       VALUES (?,?,?,?,?,?)""",
                    (uid, kind, client_id, updated_at, raw, int(time.time())),
                )
                created += 1
            elif int(existing["updated_at"]) < updated_at:
                conn.execute(
                    "UPDATE sync_collections SET updated_at = ?, payload = ? WHERE id = ?",
                    (updated_at, raw, existing["id"]),
                )
                updated += 1
            else:
                unchanged += 1
        for client_id in payload.deleted_client_ids:
            cur = conn.execute(
                "DELETE FROM sync_collections WHERE user_id = ? AND kind = ? AND client_id = ?",
                (uid, kind, str(client_id)),
            )
            deleted += cur.rowcount or 0

    total_now = _mirror_collection(uid, kind)
    return {
        "kind": kind,
        "created": created,
        "updated": updated,
        "unchanged": unchanged,
        "deleted": deleted,
        "total": total_now,
    }


@router.get("/collections/{kind}", summary="读取自定义分区")
def get_collection(kind: str, limit: int = Query(default=2000, ge=1, le=5000), user: dict = Depends(require_user)):
    kind = _check_kind(kind)
    with db() as conn:
        rows = conn.execute(
            """SELECT client_id, updated_at, payload FROM sync_collections
               WHERE user_id = ? AND kind = ? ORDER BY updated_at DESC LIMIT ?""",
            (int(user["id"]), kind, limit),
        ).fetchall()
    return {
        "kind": kind,
        "items": [
            {"client_id": r["client_id"], "updated_at": int(r["updated_at"]), "payload": json_load(r["payload"], {})}
            for r in rows
        ],
    }


# ============================ 隐私空间 ============================


def _mirror_vault(user_id: int) -> int:
    with db() as conn:
        rows = conn.execute(
            """SELECT item_id, name, kind, sha256, bytes, rel_path, created_at
               FROM vault_files WHERE user_id = ? ORDER BY created_at DESC""",
            (user_id,),
        ).fetchall()
    items = [
        {
            "item_id": r["item_id"],
            "name": r["name"],
            "kind": r["kind"],
            "sha256": r["sha256"],
            "bytes": int(r["bytes"]),
            "url": f"/uploads/{r['rel_path']}",
            "created_at": int(r["created_at"]),
        }
        for r in rows
    ]
    write_user_json(user_id, "vault", {"encrypted": True, "items": items})
    return len(items)


@router.post("/vault", summary="上传隐私空间密文块（端侧 AES-GCM，服务端不解密）")
def upload_vault_file(
    file: UploadFile = File(...),
    item_id: str = Form(default=""),
    name: str = Form(default=""),
    kind: str = Form(default="image"),
    user: dict = Depends(require_user),
):
    uid = int(user["id"])
    if len(name) > 200:
        name = name[:200]
    if kind not in ("image", "video"):
        kind = "image"
    with db() as conn:
        used = _used_bytes(conn, uid)
    if used >= settings.user_quota_bytes:
        raise HTTPException(status_code=413, detail="云空间已满，请清理后再上传")

    saved = save_encrypted_blob(file, uid)
    with tx() as conn:
        existing = conn.execute(
            "SELECT item_id FROM vault_files WHERE user_id = ? AND sha256 = ?", (uid, saved["sha256"])
        ).fetchone()
        rel = saved["rel_path"]
        if existing is None:
            conn.execute(
                """INSERT INTO vault_files (user_id, sha256, item_id, name, kind, bytes, rel_path, created_at)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (uid, saved["sha256"], item_id[:64], name, kind, saved["bytes"], rel, int(time.time())),
            )
    total = _mirror_vault(uid)
    return {
        "url": saved["url"],
        "sha256": saved["sha256"],
        "bytes": saved["bytes"],
        "dedup": saved["dedup"],
        "item_id": item_id,
        "name": name,
        "total": total,
    }


@router.get("/vault", summary="隐私空间密文块清单（不含明文）")
def list_vault_files(user: dict = Depends(require_user)):
    uid = int(user["id"])
    with db() as conn:
        rows = conn.execute(
            "SELECT item_id, name, kind, sha256, bytes, rel_path, created_at FROM vault_files WHERE user_id = ? ORDER BY created_at DESC",
            (uid,),
        ).fetchall()
    return {
        "encrypted": True,
        "items": [
            {
                "item_id": r["item_id"],
                "name": r["name"],
                "kind": r["kind"],
                "sha256": r["sha256"],
                "bytes": int(r["bytes"]),
                "url": f"/uploads/{r['rel_path']}",
                "created_at": int(r["created_at"]),
            }
            for r in rows
        ],
    }


# ============================ 全量档案 ============================

_TABLE_FOR_SECTION = {"footprints": "sync_footprints", "routes": "sync_routes"}


def _store_flat_items(uid: int, section: str, items: list) -> int:
    table = _TABLE_FOR_SECTION[section]
    now = int(time.time())
    rows: list[tuple[int, int, str]] = []
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        cid = item.get("id", item.get("client_id", idx))
        try:
            cid = int(cid)
        except (TypeError, ValueError):
            cid = int(idx)
        upd = item.get("updated_at") or item.get("updatedAt") or now
        try:
            upd = int(upd)
        except (TypeError, ValueError):
            upd = now
        rows.append((cid, upd, json_dump(item)))

    with tx() as conn:
        for cid, upd, raw in rows:
            existing = conn.execute(
                f"SELECT id FROM {table} WHERE user_id = ? AND client_id = ?", (uid, cid)
            ).fetchone()
            if existing is None:
                conn.execute(
                    f"INSERT INTO {table} (user_id, client_id, updated_at, payload, created_at) VALUES (?,?,?,?,?)",
                    (uid, cid, upd, raw, now),
                )
            else:
                conn.execute(
                    f"UPDATE {table} SET updated_at = ?, payload = ? WHERE id = ?",
                    (upd, raw, existing["id"]),
                )
        if section == "footprints":
            _refresh_counters(conn, uid)
    return len(rows)


def _store_generic(uid: int, kind: str, items: list) -> int:
    now = int(time.time())
    normalized: list[tuple[str, int, str]] = []
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        cid = str(item.get("id", item.get("client_id", idx)))
        upd = item.get("updated_at") or item.get("updatedAt") or now
        try:
            upd = int(upd)
        except (TypeError, ValueError):
            upd = now
        normalized.append((cid[:128], upd, json_dump(item)))
    with tx() as conn:
        for cid, upd, raw in normalized:
            conn.execute(
                """INSERT INTO sync_collections (user_id, kind, client_id, updated_at, payload, created_at)
                   VALUES (?,?,?,?,?,?)
                   ON CONFLICT(user_id, kind, client_id)
                   DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at""",
                (uid, kind, cid, upd, raw, now),
            )
    return len(normalized)


def _import_sections(uid: int, sections: dict[str, Any]) -> dict[str, int]:
    """把档案里的每个分区镜像进用户文件夹，并把结构化数据落到库里。"""
    imported: dict[str, int] = {}
    for name, value in sections.items():
        if not _KIND_RE.match(name or ""):
            continue
        try:
            write_user_json(uid, name, value)
        except OSError:
            pass

        if name in _TABLE_FOR_SECTION and isinstance(value, list):
            imported[name] = _store_flat_items(uid, name, value)
        elif name == "settings" and isinstance(value, dict):
            clean = {
                k: v
                for k, v in value.items()
                if not any(w in k.lower() for w in ("token", "password", "secret", "api_key"))
            }
            with tx() as conn:
                conn.execute(
                    """INSERT INTO sync_settings (user_id, payload, updated_at) VALUES (?,?,?)
                       ON CONFLICT(user_id) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at""",
                    (uid, json_dump(clean), int(time.time())),
                )
            imported[name] = len(clean)
        elif isinstance(value, list):
            imported[name] = _store_generic(uid, name, value)
        elif isinstance(value, dict):
            imported[name] = _store_generic(uid, name, [{"id": "snapshot", "payload": value}])
    return imported


@router.post("/archive", summary="上传全量档案（足迹 / 行程 / 计划 / 音乐收藏 / 评论 / 隐私空间索引 / 设置）")
async def put_archive(request: Request, user: dict = Depends(require_user)):
    raw = await request.body()
    if not raw:
        raise HTTPException(status_code=400, detail="档案为空")
    if len(raw) > ARCHIVE_LIMIT:
        raise HTTPException(status_code=413, detail=f"档案超过 {ARCHIVE_LIMIT // (1024 * 1024)}MB，请把照片视频走 /api/sync/media")

    try:
        doc = json.loads(raw)
    except ValueError:
        raise HTTPException(status_code=400, detail="档案不是合法 JSON")
    if not isinstance(doc, dict):
        raise HTTPException(status_code=400, detail="档案必须是 JSON 对象")

    sections = doc.get("sections")
    if sections is None:
        sections = {k: v for k, v in doc.items() if k not in ("schema_version", "exported_at", "app")}
    if not isinstance(sections, dict):
        raise HTTPException(status_code=400, detail="sections 必须是对象")

    uid = int(user["id"])
    now = int(time.time())
    data_dir = user_data_dir(uid)
    latest = data_dir / "archive.json"
    tmp = latest.with_name("archive.json.part")
    tmp.write_bytes(raw)
    os.replace(tmp, latest)
    (data_dir / f"archive-{now}.json").write_bytes(raw)
    # 只保留最近 5 份历史档案，避免磁盘被刷爆
    history = sorted(data_dir.glob("archive-*.json"))
    for old in history[:-5]:
        try:
            old.unlink()
        except OSError:
            pass

    counts = {
        k: (len(v) if isinstance(v, list) else 1) for k, v in sections.items() if _KIND_RE.match(k or "")
    }
    with tx() as conn:
        conn.execute(
            "INSERT INTO user_archives (user_id, sections, bytes, rel_path, created_at) VALUES (?,?,?,?,?)",
            (uid, json_dump(counts), len(raw), f"users/{uid}/data/archive.json", now),
        )
        conn.execute(
            "DELETE FROM user_archives WHERE user_id = ? AND id NOT IN (SELECT id FROM user_archives WHERE user_id = ? ORDER BY created_at DESC LIMIT 20)",
            (uid, uid),
        )

    imported = _import_sections(uid, sections)
    return {
        "ok": True,
        "bytes": len(raw),
        "sections": counts,
        "imported": imported,
        "folder": f"users/{uid}/data/archive.json",
    }


@router.get("/archive", summary="查看最近一次全量档案的元信息")
def get_archive_meta(user: dict = Depends(require_user)):
    uid = int(user["id"])
    with db() as conn:
        row = conn.execute(
            "SELECT sections, bytes, created_at FROM user_archives WHERE user_id = ? ORDER BY created_at DESC LIMIT 1",
            (uid,),
        ).fetchone()
    if row is None:
        return {"available": False, "sections": {}, "bytes": 0, "created_at": 0}
    return {
        "available": True,
        "sections": json_load(row["sections"], {}),
        "bytes": int(row["bytes"]),
        "created_at": int(row["created_at"]),
    }


@router.get("/archive/content", summary="下载最近一次全量档案（换机恢复用）")
def get_archive_content(user: dict = Depends(require_user)):
    uid = int(user["id"])
    doc = read_user_json(uid, "archive")
    if doc is None:
        raise HTTPException(status_code=404, detail="还没有上传过全量档案")
    return doc


# ============================ 登录后全量恢复 ============================


def _profile(conn, uid: int) -> dict[str, Any]:
    row = conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="账号不存在")
    return {
        "id": int(row["id"]),
        "username": row["username"],
        "nickname": row["nickname"],
        "signature": row["signature"],
        "avatar": row["avatar"],
        "default_public": int(row["default_public"]),
        "notif_enabled": int(row["notif_enabled"]),
        "share_enabled": int(row["share_enabled"]),
        "followers": int(row["followers_count"]),
        "following": int(row["following_count"]),
        "likes_received": int(row["likes_received"]),
        "cities_count": int(row["cities_count"]),
        "footprint_count": int(row["footprint_count"]),
        "days_count": int(row["days_count"]),
        "created_at": int(row["created_at"]),
    }


def _flat_rows(rows) -> list[dict[str, Any]]:
    return [
        {
            "client_id": int(r["client_id"]),
            "updated_at": int(r["updated_at"]),
            "payload": json_load(r["payload"], {}),
        }
        for r in rows
    ]


@router.get("/bootstrap", summary="登录后全量恢复：一次取回云端所有个人数据")
def bootstrap(
    limit: int = Query(default=5000, ge=1, le=20000),
    include_media: bool = Query(default=True),
    user: dict = Depends(require_user),
):
    """App 登录成功后调用一次，把云端数据整体回灌到本机。

    返回的是「个人数据全集」：资料、设置、足迹、行程、所有通用分区、
    媒体清单、隐私空间密文清单、AI 端点配置、本人发布的攻略与评论、点赞/收藏。
    路径与单项接口保持一致，避免出现两套字段。
    """
    uid = int(user["id"])
    with db() as conn:
        profile = _profile(conn, uid)
        fp_rows = conn.execute(
            "SELECT client_id, updated_at, payload FROM sync_footprints WHERE user_id = ? ORDER BY updated_at ASC LIMIT ?",
            (uid, limit),
        ).fetchall()
        rt_rows = conn.execute(
            "SELECT client_id, updated_at, payload FROM sync_routes WHERE user_id = ? ORDER BY updated_at ASC LIMIT ?",
            (uid, limit),
        ).fetchall()
        st = conn.execute("SELECT payload, updated_at FROM sync_settings WHERE user_id = ?", (uid,)).fetchone()
        kinds = [
            r["kind"]
            for r in conn.execute(
                "SELECT DISTINCT kind FROM sync_collections WHERE user_id = ? ORDER BY kind", (uid,)
            ).fetchall()
        ]
        collections: dict[str, list] = {}
        for kind in kinds:
            rows = conn.execute(
                """SELECT client_id, updated_at, payload FROM sync_collections
                   WHERE user_id = ? AND kind = ? ORDER BY updated_at ASC LIMIT ?""",
                (uid, kind, limit),
            ).fetchall()
            collections[kind] = [
                {"client_id": r["client_id"], "updated_at": int(r["updated_at"]), "payload": json_load(r["payload"], {})}
                for r in rows
            ]
        media = conn.execute(
            """SELECT sha256, url, bytes, mime, kind, created_at FROM media
               WHERE user_id = ? ORDER BY created_at ASC LIMIT ?""",
            (uid, limit),
        ).fetchall()
        vault = conn.execute(
            """SELECT item_id, name, kind, sha256, bytes, rel_path, created_at FROM vault_files
               WHERE user_id = ? ORDER BY created_at ASC LIMIT ?""",
            (uid, limit),
        ).fetchall()
        guide_rows = conn.execute(
            GUIDE_SELECT + " WHERE g.author_id = ? AND g.status = 1 ORDER BY g.created_at DESC LIMIT ?",
            (uid, limit),
        ).fetchall()
        comment_rows = conn.execute(
            """SELECT id, guide_id, parent_id, content, likes, created_at FROM comments
               WHERE user_id = ? AND status = 1 ORDER BY created_at ASC LIMIT ?""",
            (uid, limit),
        ).fetchall()
        like_ids = [
            int(r["guide_id"])
            for r in conn.execute(
                "SELECT guide_id FROM guide_likes WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
                (uid, limit),
            ).fetchall()
        ]
        fav_ids = [
            int(r["guide_id"])
            for r in conn.execute(
                "SELECT guide_id FROM guide_favs WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
                (uid, limit),
            ).fetchall()
        ]
        fp_total = conn.execute("SELECT COUNT(*) AS c FROM sync_footprints WHERE user_id = ?", (uid,)).fetchone()["c"]
        rt_total = conn.execute("SELECT COUNT(*) AS c FROM sync_routes WHERE user_id = ?", (uid,)).fetchone()["c"]

    ai = ai_store.config_for_user(uid)
    complete = int(fp_total) <= len(fp_rows) and int(rt_total) <= len(rt_rows)
    return {
        "schema_version": 3,
        "server_time": int(time.time()),
        "complete": complete,
        "limit": limit,
        "profile": profile,
        "settings": json_load(st["payload"], {}) if st else {},
        "settings_updated_at": int(st["updated_at"]) if st else 0,
        "footprints": _flat_rows(fp_rows),
        "routes": _flat_rows(rt_rows),
        "collections": collections,
        "media": [
            {
                "sha256": r["sha256"],
                "url": r["url"],
                "bytes": int(r["bytes"]),
                "mime": r["mime"],
                "kind": r["kind"],
                "created_at": int(r["created_at"]),
            }
            for r in media
        ] if include_media else [],
        "vault": {
            "encrypted": True,
            "items": [
                {
                    "item_id": r["item_id"],
                    "name": r["name"],
                    "kind": r["kind"],
                    "sha256": r["sha256"],
                    "bytes": int(r["bytes"]),
                    "url": f"/uploads/{r['rel_path']}",
                    "created_at": int(r["created_at"]),
                }
                for r in vault
            ],
        },
        "ai": ai,
        "guides": [
            guide_obj(
                r,
                liked=int(r["id"]) in like_ids,
                is_favored=int(r["id"]) in fav_ids,
            )
            for r in guide_rows
        ],
        "comments": [
            {
                "id": int(r["id"]),
                "guide_id": int(r["guide_id"]),
                "parent_id": int(r["parent_id"]) if r["parent_id"] is not None else None,
                "content": r["content"],
                "likes": int(r["likes"]),
                "created_at": int(r["created_at"]),
            }
            for r in comment_rows
        ],
        "liked_guide_ids": like_ids,
        "favored_guide_ids": fav_ids,
        "counts": {
            "footprints": int(fp_total),
            "routes": int(rt_total),
            "collections": sum(len(v) for v in collections.values()),
            "media": len(media),
            "vault": len(vault),
            "guides": len(guide_rows),
            "comments": len(comment_rows),
            "ai_endpoints": len(ai["endpoints"]),
        },
    }
