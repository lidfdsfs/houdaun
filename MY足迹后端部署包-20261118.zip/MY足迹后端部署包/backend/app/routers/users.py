"""用户资料、头像、关注关系。"""
from __future__ import annotations

import time

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile

from ..db import db, tx
from ..deps import client_ip, optional_user, require_user
from ..schemas import UserUpdate
from ..storage import save_upload
from .auth import serialize_user

router = APIRouter(tags=["用户"])


@router.get("/users/me", summary="我的资料")
def get_me(user: dict = Depends(require_user)):
    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user["id"],)).fetchone()
    return serialize_user(row)


@router.put("/users/me", summary="更新我的资料")
def update_me(payload: UserUpdate, user: dict = Depends(require_user)):
    changes: list[str] = []
    values: list[object] = []
    if payload.nickname is not None:
        nick = payload.nickname.strip()
        if not nick:
            raise HTTPException(status_code=400, detail="昵称不能为空")
        changes.append("nickname = ?")
        values.append(nick[:40])
    if payload.signature is not None:
        changes.append("signature = ?")
        values.append(payload.signature[:200])
    if payload.default_public is not None:
        changes.append("default_public = ?")
        values.append(1 if payload.default_public else 0)
    if payload.notif_enabled is not None:
        changes.append("notif_enabled = ?")
        values.append(1 if payload.notif_enabled else 0)
    if payload.share_enabled is not None:
        changes.append("share_enabled = ?")
        values.append(1 if payload.share_enabled else 0)

    if changes:
        changes.append("updated_at = ?")
        values.append(int(time.time()))
        values.append(user["id"])
        with tx() as conn:
            conn.execute(f"UPDATE users SET {', '.join(changes)} WHERE id = ?", tuple(values))

    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user["id"],)).fetchone()
    return serialize_user(row)


@router.post("/users/me/avatar", summary="上传头像")
def upload_avatar(file: UploadFile = File(...), user: dict = Depends(require_user)):
    saved = save_upload(file, int(user["id"]), category="avatar")
    with tx() as conn:
        conn.execute(
            "UPDATE users SET avatar = ?, updated_at = ? WHERE id = ?",
            (saved["url"], int(time.time()), user["id"]),
        )
    return {"url": saved["url"], "sha256": saved["sha256"], "bytes": saved["bytes"], "mime": saved["mime"]}


@router.get("/users/search", summary="按账号（用户名）精确查找用户")
def search_user(username: str = "", user: dict = Depends(require_user)):
    name = (username or "").strip()
    if len(name) < 3:
        raise HTTPException(status_code=400, detail="账号至少 3 位")
    me = int(user["id"])
    with db() as conn:
        row = conn.execute(
            """SELECT id, username, nickname, avatar, signature
               FROM users WHERE username = ? COLLATE NOCASE AND status = 1""",
            (name,),
        ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="没找到该账号")
        target = int(row["id"])
        if target == me:
            raise HTTPException(status_code=400, detail="这是你自己的账号")
        i_follow = conn.execute(
            "SELECT 1 FROM user_follows WHERE follower_id = ? AND target_id = ?", (me, target)
        ).fetchone() is not None
        follows_me = conn.execute(
            "SELECT 1 FROM user_follows WHERE follower_id = ? AND target_id = ?", (target, me)
        ).fetchone() is not None
    return {
        "data": {
            "user": {
                "id": target,
                "username": row["username"],
                "nickname": row["nickname"],
                "avatar": row["avatar"],
                "signature": row["signature"],
            },
            "following": bool(i_follow),
            "follows_me": bool(follows_me),
            "mutual": bool(i_follow and follows_me),
        }
    }


@router.get("/users/followers", summary="我的粉丝列表")
def list_followers(user: dict = Depends(require_user)):
    me = int(user["id"])
    with db() as conn:
        rows = conn.execute(
            """SELECT u.id, u.username, u.nickname, u.avatar, u.signature
               FROM user_follows f JOIN users u ON u.id = f.follower_id
               WHERE f.target_id = ? AND u.status = 1
               ORDER BY f.created_at DESC, u.id DESC""",
            (me,),
        ).fetchall()
        items = [_follow_view(conn, me, row) for row in rows]
    return {"data": {"items": items, "total": len(items)}}


@router.get("/users/following", summary="我关注的人")
def list_following(user: dict = Depends(require_user)):
    me = int(user["id"])
    with db() as conn:
        rows = conn.execute(
            """SELECT u.id, u.username, u.nickname, u.avatar, u.signature
               FROM user_follows f JOIN users u ON u.id = f.target_id
               WHERE f.follower_id = ? AND u.status = 1
               ORDER BY f.created_at DESC, u.id DESC""",
            (me,),
        ).fetchall()
        items = [_follow_view(conn, me, row) for row in rows]
    return {"data": {"items": items, "total": len(items)}}


@router.get("/users/notifications", summary="关注我的通知")
def list_follow_notifications(user: dict = Depends(require_user)):
    me = int(user["id"])
    with tx() as conn:
        rows = conn.execute(
            """SELECT n.id, n.created_at, n.read, u.id AS actor_id, u.username,
                      u.nickname, u.avatar, u.signature
               FROM follow_notifications n JOIN users u ON u.id = n.actor_id
               WHERE n.user_id = ? AND u.status = 1
               ORDER BY n.created_at DESC, n.id DESC LIMIT 100""",
            (me,),
        ).fetchall()
        i_follow = {
            int(r["actor_id"]) for r in conn.execute(
                "SELECT target_id AS actor_id FROM user_follows WHERE follower_id = ?", (me,)
            ).fetchall()
        }
        items = [{
            "id": int(r["id"]),
            "actor": {
                "id": int(r["actor_id"]), "username": r["username"],
                "nickname": r["nickname"], "avatar": r["avatar"], "signature": r["signature"],
            },
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(int(r["created_at"]))),
            "read": bool(r["read"]),
            "i_follow_actor": int(r["actor_id"]) in i_follow,
        } for r in rows]
    return {"data": {"items": items, "unread": sum(1 for i in items if not i["read"])}}


@router.post("/users/notifications/read", summary="关注通知标记已读")
def read_follow_notifications(user: dict = Depends(require_user)):
    me = int(user["id"])
    with tx() as conn:
        conn.execute(
            "UPDATE follow_notifications SET read = 1 WHERE user_id = ? AND read = 0", (me,)
        )
    return {"data": {"ok": True}}


@router.get("/users/{user_id}", summary="查看他人主页")
def get_user(user_id: int, viewer: dict | None = Depends(optional_user)):
    with db() as conn:
        row = conn.execute(
            """SELECT id, username, nickname, signature, avatar, cities_count, footprint_count, days_count,
                      followers_count, following_count, likes_received, created_at
               FROM users WHERE id = ? AND status = 1""",
            (user_id,),
        ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="用户不存在")
        guides = conn.execute(
            "SELECT COUNT(*) AS c FROM guides WHERE author_id = ? AND status = 1", (user_id,)
        ).fetchone()["c"]
        relation = _relation(conn, int(viewer["id"]), user_id) if viewer else {
            "following": False, "follows_me": False, "mutual": False
        }
    data = dict(row)
    data["followers"] = data.pop("followers_count")
    data["following"] = data.pop("following_count")
    data["guides"] = int(guides)
    data["created_at"] = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(int(data["created_at"])))
    data.update(relation)
    return data


def _relation(conn, me: int, target: int) -> dict[str, bool]:
    i_follow = conn.execute(
        "SELECT 1 FROM user_follows WHERE follower_id = ? AND target_id = ?", (me, target)
    ).fetchone() is not None
    follows_me = conn.execute(
        "SELECT 1 FROM user_follows WHERE follower_id = ? AND target_id = ?", (target, me)
    ).fetchone() is not None
    return {"following": bool(i_follow), "follows_me": bool(follows_me),
            "mutual": bool(i_follow and follows_me)}


def _follow_view(conn, me: int, row) -> dict:
    target = int(row["id"])
    rel = _relation(conn, me, target)
    return {
        "id": target,
        "username": row["username"],
        "nickname": row["nickname"],
        "avatar": row["avatar"],
        "signature": row["signature"],
        **rel,
    }


@router.post("/users/{user_id}/follow", summary="关注 / 取消关注")
def toggle_follow(user_id: int, user: dict = Depends(require_user), ip: str = Depends(client_ip)):
    if user_id == int(user["id"]):
        raise HTTPException(status_code=400, detail="不能关注自己")
    with tx() as conn:
        target = conn.execute("SELECT id FROM users WHERE id = ? AND status = 1", (user_id,)).fetchone()
        if target is None:
            raise HTTPException(status_code=404, detail="用户不存在")
        existing = conn.execute(
            "SELECT 1 FROM user_follows WHERE follower_id = ? AND target_id = ?", (user["id"], user_id)
        ).fetchone()
        now = int(time.time())
        if existing:
            conn.execute("DELETE FROM user_follows WHERE follower_id = ? AND target_id = ?", (user["id"], user_id))
            conn.execute("UPDATE users SET following_count = MAX(0, following_count - 1) WHERE id = ?", (user["id"],))
            conn.execute("UPDATE users SET followers_count = MAX(0, followers_count - 1) WHERE id = ?", (user_id,))
            # 取消关注后，对方那条“新粉丝”通知也一起撤掉，避免点进去关系对不上
            conn.execute(
                "DELETE FROM follow_notifications WHERE user_id = ? AND actor_id = ?",
                (user_id, user["id"]),
            )
            following = False
        else:
            conn.execute(
                "INSERT OR IGNORE INTO user_follows (follower_id, target_id, created_at) VALUES (?,?,?)",
                (user["id"], user_id, now),
            )
            conn.execute("UPDATE users SET following_count = following_count + 1 WHERE id = ?", (user["id"],))
            conn.execute("UPDATE users SET followers_count = followers_count + 1 WHERE id = ?", (user_id,))
            conn.execute(
                """INSERT INTO follow_notifications (user_id, actor_id, created_at, read)
                   VALUES (?,?,?,0)""",
                (user_id, user["id"], now),
            )
            following = True
        me = conn.execute("SELECT following_count FROM users WHERE id = ?", (user["id"],)).fetchone()
        other = conn.execute("SELECT followers_count FROM users WHERE id = ?", (user_id,)).fetchone()
        rel = _relation(conn, int(user["id"]), user_id)
    return {"data": {
        "following": following,
        "follows_me": rel["follows_me"],
        "mutual": rel["mutual"],
        "following_count": int(me["following_count"]),
        "followers_count": int(other["followers_count"]),
    }}
