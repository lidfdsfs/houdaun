"""站内私信（单聊）。

对齐主流 IM 的几条硬规矩：
1. **会话唯一**：一对用户只有一条会话（user_a < user_b），双方 id 排序后做唯一键，
   天然避免「A 建的会话」和「B 建的会话」重复。
2. **seq 单调**：每条消息在会话内拿到 `seq = max(seq)+1`，客户端按 seq 增量同步，
   断线重连不会重复也不会漏；seq 也是已读水位。
3. **幂等**：客户端带 `client_msg_id`（离线队列重发/弱网重试都用同一个），
   服务端靠唯一索引把它折叠成一条，重复提交直接返回原消息。
4. **未读计数 + 已读回执**：会话冗余 a_unread/b_unread，拉取会话列表 O(1)；
   已读水位 a_last_read_seq/b_last_read_seq 让发送方能显示「已读」。
5. **撤回**：仅发送者、仅在 MESSAGE_RECALL_SECONDS 内可撤回，撤回后 status=0，
   对方未读计数回退，历史里留一条「已撤回」占位。
6. **拉黑**：任一方拉黑，双方都不能再发（历史仍可读），错误信息不区分是谁拉黑了谁。
7. **实时推送**：SSE 长连接 + 游标，收到断线后用 `after_seq` 补齐，推送只做「尽快知道」，
   数据仍以拉取为准。
"""
from __future__ import annotations

import asyncio
import time
from typing import Any, AsyncIterator

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from starlette.concurrency import run_in_threadpool

from ..config import settings
from ..db import db, json_dump, json_load, tx
from ..deps import client_ip, rate_limit, require_user
from ..schemas import BlockAction, ConversationOpen, MessageSend, ReadMark
from ..security import limiter

router = APIRouter(prefix="/api/messages", tags=["私信"])

_READ_LIMIT = rate_limit("messages_read", 240)


def _iso(ts: int) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(int(ts or 0))) if ts else ""


def _pair(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a < b else (b, a)


def _side(me_id: int, a: int) -> str:
    return "a" if me_id == a else "b"


def _blocked(conn: Any, me: int, peer: int) -> tuple[bool, bool]:
    row_i = conn.execute(
        "SELECT 1 FROM user_blocks WHERE owner_id = ? AND blocked_id = ?", (me, peer)
    ).fetchone()
    row_p = conn.execute(
        "SELECT 1 FROM user_blocks WHERE owner_id = ? AND blocked_id = ?", (peer, me)
    ).fetchone()
    return row_i is not None, row_p is not None


def _relation(conn: Any, me: int, peer: int) -> tuple[bool, bool, bool]:
    """(我关注对方, 对方关注我, 互关)。互关是私信的唯一准入条件。"""
    i_follow = conn.execute(
        "SELECT 1 FROM user_follows WHERE follower_id = ? AND target_id = ?", (me, peer)
    ).fetchone() is not None
    follows_me = conn.execute(
        "SELECT 1 FROM user_follows WHERE follower_id = ? AND target_id = ?", (peer, me)
    ).fetchone() is not None
    return bool(i_follow), bool(follows_me), bool(i_follow and follows_me)


# 图片/视频消息 extra 允许保留的媒体字段；其余任意 JSON 一律丢弃
_MEDIA_EXTRA_KEYS = {"url", "thumb", "width", "height", "duration", "bytes", "mime", "name"}


def _clean_message_extra(msg_type: str, extra: dict | None) -> dict:
    """文本消息原样保留 extra（回复引用等）；图片/视频只保留白名单媒体字段，
    并校验媒体地址必须是本站 /uploads/ 相对路径，避免外链注入。"""
    if not extra:
        return {}
    if msg_type == "text":
        return dict(extra)
    out: dict[str, Any] = {}
    for key in _MEDIA_EXTRA_KEYS:
        if key in extra:
            out[key] = extra[key]
    url = out.get("url")
    if not isinstance(url, str) or not url.startswith("/uploads/"):
        raise HTTPException(status_code=400, detail="媒体地址非法")
    thumb = out.get("thumb")
    if isinstance(thumb, str) and thumb and not thumb.startswith("/uploads/"):
        out.pop("thumb")
    return out


def _peer_profile(conn: Any, peer_id: int) -> dict[str, Any]:
    row = conn.execute(
        "SELECT id, username, nickname, avatar, signature FROM users WHERE id = ?", (peer_id,)
    ).fetchone()
    if row is None:
        return {"id": peer_id, "username": "", "nickname": "已注销用户", "avatar": None, "signature": ""}
    return {"id": int(row["id"]), "username": row["username"], "nickname": row["nickname"],
            "avatar": row["avatar"], "signature": row["signature"]}


def _conv_view(conn: Any, row: Any, me_id: int) -> dict[str, Any]:
    a, b = int(row["user_a"]), int(row["user_b"])
    peer = b if me_id == a else a
    side = _side(me_id, a)
    other = "b" if side == "a" else "a"
    i_blocked, peer_blocked = _blocked(conn, me_id, peer)
    i_follow, follows_me, mutual = _relation(conn, me_id, peer)
    return {
        "id": int(row["id"]),
        "peer": _peer_profile(conn, peer),
        "unread": int(row[f"{side}_unread"]),
        "my_last_read_seq": int(row[f"{side}_last_read_seq"]),
        "peer_last_read_seq": int(row[f"{other}_last_read_seq"]),
        "muted": bool(row[f"{side}_muted"]),
        "last_preview": row["last_preview"],
        "last_message_id": int(row["last_message_id"]),
        "last_message_at": _iso(row["last_message_at"]),
        "updated_at": _iso(row["updated_at"]),
        "i_blocked_peer": i_blocked,
        "peer_blocked_me": peer_blocked,
        # 互关限聊：前端只做展示，真正拦截在发送接口
        "i_follow_peer": i_follow,
        "peer_follows_me": follows_me,
        "mutual": mutual,
        "can_send": mutual and not (i_blocked or peer_blocked),
    }


def _msg_view(row: Any, me_id: int) -> dict[str, Any]:
    recalled = int(row["status"]) == 0
    return {
        "id": int(row["id"]),
        "conversation_id": int(row["conversation_id"]),
        "sender_id": int(row["sender_id"]),
        "seq": int(row["seq"]),
        "client_msg_id": row["client_msg_id"],
        "type": row["type"],
        "body": "" if recalled else row["body"],
        "extra": json_load(row["extra"], {}),
        "status": int(row["status"]),
        "recalled": recalled,
        "mine": int(row["sender_id"]) == me_id,
        "created_at": _iso(row["created_at"]),
        "created_ts": int(row["created_at"]),
    }


def _get_conv(conn: Any, conv_id: int, me_id: int) -> Any:
    row = conn.execute("SELECT * FROM conversations WHERE id = ?", (conv_id,)).fetchone()
    if row is None or me_id not in (int(row["user_a"]), int(row["user_b"])):
        raise HTTPException(status_code=404, detail="会话不存在")
    return row


# ---------------- 会话 ----------------

@router.get("/conversations", summary="会话列表（含未读数）")
def list_conversations(
    limit: int = Query(default=50, ge=1, le=200),
    user: dict = Depends(require_user),
):
    me = int(user["id"])
    with db() as conn:
        rows = conn.execute(
            """SELECT * FROM conversations
               WHERE user_a = ? OR user_b = ?
               ORDER BY last_message_at DESC, id DESC LIMIT ?""",
            (me, me, limit),
        ).fetchall()
        data = [_conv_view(conn, r, me) for r in rows]
        total_unread = sum(item["unread"] for item in data)
    return {"data": {"items": data, "total_unread": total_unread}}


@router.post("/conversations", summary="打开（或创建）与某人的会话")
def open_conversation(payload: ConversationOpen, user: dict = Depends(require_user)):
    me = int(user["id"])
    peer = int(payload.peer_id)
    if peer == me:
        raise HTTPException(status_code=400, detail="不能和自己聊天")
    now = int(time.time())
    a, b = _pair(me, peer)
    with tx() as conn:
        target = conn.execute("SELECT id, status FROM users WHERE id = ?", (peer,)).fetchone()
        if target is None:
            raise HTTPException(status_code=404, detail="对方账号不存在")
        if int(target["status"]) != 1:
            raise HTTPException(status_code=403, detail="对方账号已被停用")
        row = conn.execute(
            "SELECT * FROM conversations WHERE user_a = ? AND user_b = ?", (a, b)
        ).fetchone()
        if row is None:
            cur = conn.execute(
                """INSERT INTO conversations (user_a, user_b, created_at, updated_at)
                   VALUES (?,?,?,?)""",
                (a, b, now, now),
            )
            row = conn.execute(
                "SELECT * FROM conversations WHERE id = ?", (cur.lastrowid,)
            ).fetchone()
        view = _conv_view(conn, row, me)
    return {"data": view}


@router.get("/conversations/{conv_id}", summary="会话详情")
def conversation_detail(conv_id: int, user: dict = Depends(require_user)):
    me = int(user["id"])
    with db() as conn:
        row = _get_conv(conn, conv_id, me)
        view = _conv_view(conn, row, me)
    return {"data": view}


@router.post("/conversations/{conv_id}/mute", summary="免打扰开关")
def mute_conversation(conv_id: int, user: dict = Depends(require_user)):
    me = int(user["id"])
    with tx() as conn:
        row = _get_conv(conn, conv_id, me)
        side = _side(me, int(row["user_a"]))
        new_value = 0 if int(row[f"{side}_muted"]) else 1
        conn.execute(
            f"UPDATE conversations SET {side}_muted = ?, updated_at = ? WHERE id = ?",
            (new_value, int(time.time()), conv_id),
        )
    return {"data": {"conversation_id": conv_id, "muted": bool(new_value)}}


# ---------------- 消息 ----------------

def _check_send_rate(me: int, ip: str) -> None:
    allowed, retry_after = limiter.check(
        "msg_send", f"{me}:{ip}", settings.message_rate_per_minute, 60
    )
    if not allowed:
        raise HTTPException(
            status_code=429,
            detail=f"发消息太频繁，请 {retry_after} 秒后再试",
            headers={"Retry-After": str(retry_after)},
        )


@router.get("/conversations/{conv_id}/messages", summary="拉取消息（按 seq 双向分页）")
def list_messages(
    conv_id: int,
    limit: int = Query(default=settings.message_page_size, ge=1, le=100),
    before_seq: int = Query(default=0, ge=0),
    after_seq: int = Query(default=0, ge=0),
    user: dict = Depends(require_user),
    _rl: None = Depends(_READ_LIMIT),
):
    """三种用法：
    - 首屏：只传 limit，返回最近 N 条（升序）；
    - 翻历史：带 before_seq=当前最早一条的 seq，往前取；
    - 增量补齐：带 after_seq=本地最大 seq，只取更新的。
    """
    me = int(user["id"])
    with db() as conn:
        conv = _get_conv(conn, conv_id, me)
        max_row = conn.execute(
            "SELECT MAX(seq) AS m FROM messages WHERE conversation_id = ?", (conv_id,)
        ).fetchone()
        max_seq = int(max_row["m"] or 0)
        if after_seq > 0:
            rows = conn.execute(
                """SELECT * FROM messages WHERE conversation_id = ? AND seq > ?
                   ORDER BY seq ASC LIMIT ?""",
                (conv_id, after_seq, limit),
            ).fetchall()
            items = [_msg_view(r, me) for r in rows]
            has_more = len(items) == limit
        else:
            upper = before_seq if before_seq > 0 else max_seq + 1
            rows = conn.execute(
                """SELECT * FROM messages WHERE conversation_id = ? AND seq < ?
                   ORDER BY seq DESC LIMIT ?""",
                (conv_id, upper, limit),
            ).fetchall()
            items = [_msg_view(r, me) for r in reversed(rows)]
            has_more = len(items) == limit
        view = _conv_view(conn, conv, me)
    return {
        "data": {
            "conversation": view,
            "items": items,
            "max_seq": max_seq,
            "has_more": has_more,
            "server_time": int(time.time()),
        }
    }


@router.post("/conversations/{conv_id}/messages", summary="发消息（client_msg_id 幂等）")
def send_message(
    conv_id: int,
    payload: MessageSend,
    user: dict = Depends(require_user),
    ip: str = Depends(client_ip),
):
    me = int(user["id"])
    _check_send_rate(me, ip)

    body = (payload.body or "").strip()
    if payload.type == "text" and not body:
        raise HTTPException(status_code=400, detail="消息内容不能为空")
    body = body[: settings.message_max_length]
    clean_extra = _clean_message_extra(payload.type, payload.extra)
    client_msg_id = (payload.client_msg_id or "").strip()[:80]

    now = int(time.time())
    with tx() as conn:
        conv = _get_conv(conn, conv_id, me)
        peer = int(conv["user_b"]) if me == int(conv["user_a"]) else int(conv["user_a"])
        i_blocked, peer_blocked = _blocked(conn, me, peer)
        if i_blocked or peer_blocked:
            raise HTTPException(status_code=403, detail="消息发送失败：对方已拒收或你已拉黑对方")
        _, _, mutual = _relation(conn, me, peer)
        if not mutual:
            raise HTTPException(status_code=403, detail="仅互相关注后可聊天，请先在对方主页关注并等待回关")

        if client_msg_id:
            dup = conn.execute(
                "SELECT * FROM messages WHERE conversation_id = ? AND client_msg_id = ?",
                (conv_id, client_msg_id),
            ).fetchone()
            if dup is not None:
                return {"data": {"message": _msg_view(dup, me), "duplicate": True,
                                 "conversation": _conv_view(conn, conv, me)}}

        last_seq = int(
            conn.execute(
                "SELECT MAX(seq) AS m FROM messages WHERE conversation_id = ?", (conv_id,)
            ).fetchone()["m"] or 0
        )
        seq = last_seq + 1
        cur = conn.execute(
            """INSERT INTO messages
               (conversation_id, sender_id, seq, client_msg_id, type, body, extra, status, created_at)
               VALUES (?,?,?,?,?,?,?,1,?)""",
            (
                conv_id, me, seq, client_msg_id, payload.type, body,
                json_dump(clean_extra), now,
            ),
        )
        msg_id = int(cur.lastrowid)
        side = _side(me, int(conv["user_a"]))
        other = "b" if side == "a" else "a"
        preview = (
            "[图片]" if payload.type == "image"
            else "[视频]" if payload.type == "video"
            else body[:80]
        )
        conn.execute(
            f"""UPDATE conversations SET last_message_id = ?, last_message_at = ?,
                   last_preview = ?, {other}_unread = {other}_unread + 1, updated_at = ?
               WHERE id = ?""",
            (msg_id, now, preview, now, conv_id),
        )
        msg = conn.execute("SELECT * FROM messages WHERE id = ?", (msg_id,)).fetchone()
        conv = conn.execute("SELECT * FROM conversations WHERE id = ?", (conv_id,)).fetchone()
        result = {"message": _msg_view(msg, me), "duplicate": False,
                  "conversation": _conv_view(conn, conv, me)}
    return {"data": result}


@router.post("/conversations/{conv_id}/read", summary="标记已读（上报已读水位 seq）")
def mark_read(
    conv_id: int,
    payload: ReadMark,
    user: dict = Depends(require_user),
    _rl: None = Depends(_READ_LIMIT),
):
    me = int(user["id"])
    now = int(time.time())
    with tx() as conn:
        conv = _get_conv(conn, conv_id, me)
        max_seq = int(
            conn.execute(
                "SELECT MAX(seq) AS m FROM messages WHERE conversation_id = ?", (conv_id,)
            ).fetchone()["m"] or 0
        )
        seq = min(payload.seq, max_seq) if payload.seq else max_seq
        side = _side(me, int(conv["user_a"]))
        if seq > int(conv[f"{side}_last_read_seq"]):
            unread = int(
                conn.execute(
                    """SELECT COUNT(*) AS c FROM messages
                       WHERE conversation_id = ? AND seq > ? AND sender_id != ? AND status = 1""",
                    (conv_id, seq, me),
                ).fetchone()["c"]
            )
            conn.execute(
                f"""UPDATE conversations SET {side}_unread = ?, {side}_last_read_seq = ?,
                       updated_at = ? WHERE id = ?""",
                (unread, seq, now, conv_id),
            )
            conv = conn.execute("SELECT * FROM conversations WHERE id = ?", (conv_id,)).fetchone()
        view = _conv_view(conn, conv, me)
    return {"data": view}


@router.post("/recall/{message_id}", summary="撤回消息（仅发送者、限时）")
def recall_message(message_id: int, user: dict = Depends(require_user)):
    me = int(user["id"])
    now = int(time.time())
    with tx() as conn:
        msg = conn.execute("SELECT * FROM messages WHERE id = ?", (message_id,)).fetchone()
        if msg is None:
            raise HTTPException(status_code=404, detail="消息不存在")
        if int(msg["sender_id"]) != me:
            raise HTTPException(status_code=403, detail="只能撤回自己发的消息")
        if int(msg["status"]) == 0:
            raise HTTPException(status_code=400, detail="消息已撤回")
        if now - int(msg["created_at"]) > settings.message_recall_seconds:
            raise HTTPException(
                status_code=400,
                detail=f"超过 {settings.message_recall_seconds} 秒，无法撤回",
            )
        conv_id = int(msg["conversation_id"])
        conv = _get_conv(conn, conv_id, me)
        conn.execute("UPDATE messages SET status = 0 WHERE id = ?", (message_id,))
        peer = int(conv["user_b"]) if me == int(conv["user_a"]) else int(conv["user_a"])
        peer_side = _side(peer, int(conv["user_a"]))
        # 对方还没读，就把未读数退回去
        if int(msg["seq"]) > int(conv[f"{peer_side}_last_read_seq"]):
            conn.execute(
                f"UPDATE conversations SET {peer_side}_unread = MAX(0, {peer_side}_unread - 1) WHERE id = ?",
                (conv_id,),
            )
        conn.execute(
            "UPDATE conversations SET last_preview = '[消息已撤回]', updated_at = ? WHERE id = ?",
            (now, conv_id),
        )
        conv = conn.execute("SELECT * FROM conversations WHERE id = ?", (conv_id,)).fetchone()
        view = _conv_view(conn, conv, me)
    return {"data": {"message_id": message_id, "status": 0, "conversation": view}}


@router.get("/unread", summary="总未读数")
def unread_total(user: dict = Depends(require_user)):
    me = int(user["id"])
    with db() as conn:
        row = conn.execute(
            """SELECT COALESCE(SUM(CASE WHEN user_a = ? THEN a_unread ELSE b_unread END), 0) AS total
               FROM conversations WHERE user_a = ? OR user_b = ?""",
            (me, me, me),
        ).fetchone()
    return {"data": {"total": int(row["total"] or 0)}}


# ---------------- 拉黑 ----------------

@router.post("/users/{peer_id}/block", summary="拉黑 / 取消拉黑")
def toggle_block(peer_id: int, payload: BlockAction, user: dict = Depends(require_user)):
    me = int(user["id"])
    if peer_id == me:
        raise HTTPException(status_code=400, detail="不能拉黑自己")
    now = int(time.time())
    with tx() as conn:
        target = conn.execute("SELECT id FROM users WHERE id = ?", (peer_id,)).fetchone()
        if target is None:
            raise HTTPException(status_code=404, detail="用户不存在")
        existing = conn.execute(
            "SELECT 1 FROM user_blocks WHERE owner_id = ? AND blocked_id = ?", (me, peer_id)
        ).fetchone()
        if payload.blocked and existing is None:
            conn.execute(
                "INSERT INTO user_blocks (owner_id, blocked_id, created_at) VALUES (?,?,?)",
                (me, peer_id, now),
            )
        elif not payload.blocked and existing is not None:
            conn.execute(
                "DELETE FROM user_blocks WHERE owner_id = ? AND blocked_id = ?", (me, peer_id)
            )
    return {"data": {"peer_id": peer_id, "blocked": bool(payload.blocked)}}


@router.get("/blocks", summary="我的黑名单")
def list_blocks(user: dict = Depends(require_user)):
    me = int(user["id"])
    with db() as conn:
        rows = conn.execute(
            "SELECT blocked_id, created_at FROM user_blocks WHERE owner_id = ? ORDER BY created_at DESC",
            (me,),
        ).fetchall()
        items = [
            {"peer_id": int(r["blocked_id"]), "created_at": _iso(r["created_at"]),
             "peer": _peer_profile(conn, int(r["blocked_id"]))}
            for r in rows
        ]
    return {"data": items}


# ---------------- 实时推送（SSE） ----------------

def _fetch_new_for_user(me: int, after_id: int, limit: int = 50) -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute(
            """SELECT m.* FROM messages m
               JOIN conversations c ON c.id = m.conversation_id
               WHERE (c.user_a = ? OR c.user_b = ?) AND m.id > ?
               ORDER BY m.id ASC LIMIT ?""",
            (me, me, after_id, limit),
        ).fetchall()
        return [_msg_view(r, me) for r in rows]


@router.get("/stream", summary="实时消息流（SSE，断线用 after_seq 补齐）")
async def message_stream(
    request: Request,
    since_id: int = Query(default=0, ge=0),
    user: dict = Depends(require_user),
):
    """SSE：有新消息就推 `event: message`，没有就每 2 秒发心跳。

    移动端建议：前台用 SSE，退到后台就断开；回到前台先 `GET messages?after_seq=` 补齐，再重连。
    """
    me = int(user["id"])

    async def event_gen() -> AsyncIterator[str]:
        last = since_id
        started = time.time()
        yield "retry: 3000\n\n"
        while time.time() - started < 300:
            if await request.is_disconnected():
                break
            rows = await run_in_threadpool(_fetch_new_for_user, me, last)
            for msg in rows:
                last = max(last, int(msg["id"]))
                yield f"event: message\ndata: {json_dump(msg)}\n\n"
            yield f": ping {int(time.time())}\n\n"
            await asyncio.sleep(2)
        yield "event: bye\ndata: {}\n\n"

    return StreamingResponse(
        event_gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-store",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Nginx 下关缓冲，否则 SSE 会被攒住
        },
    )
