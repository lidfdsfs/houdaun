"""攻略：列表、详情、发布、点赞、收藏、封面上传。

返回字段严格对齐安卓端 BackendApi.parseGuide：
  id / title / city / days / cost / theme / cover_seed / intro / tags / tips /
  itinerary / cost_breakdown / author_name / author_id / likes / favored / featured /
  viewed_count
注意 favored 在列表接口里是「收藏数」（App 用 optInt 读），此外另给 favs 与 is_favored。
"""
from __future__ import annotations

import time

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import JSONResponse

from ..db import db, json_dump, json_load, tx
from ..deps import optional_user, require_user
from ..schemas import GuideCreate
from ..storage import save_upload

router = APIRouter(tags=["攻略"])


def guide_obj(row, liked: bool = False, is_favored: bool = False) -> dict:
    favs = int(row["favs"])
    return {
        "id": int(row["id"]),
        "title": row["title"],
        "intro": row["intro"],
        "city": row["city"],
        "days": int(row["days"]),
        "cost": row["cost"],
        "theme": row["theme"],
        "region": row["region"],
        "cover_seed": int(row["cover_seed"]),
        "cover_image": row["cover_image"],
        "banner_title": row["banner_title"],
        "banner_subtitle": row["banner_subtitle"],
        "tags": json_load(row["tags"], []),
        "cost_breakdown": json_load(row["cost_breakdown"], []),
        "tips": json_load(row["tips"], []),
        "itinerary": json_load(row["itinerary"], []),
        "author_id": int(row["author_id"]),
        "author_name": row["author_name"] if "author_name" in row.keys() else "",
        "author_avatar": row["author_avatar"] if "author_avatar" in row.keys() else None,
        "likes": int(row["likes"]),
        "favs": favs,
        "favored": favs,          # App 列表用 optInt("favored") 读收藏数
        "is_favored": is_favored,
        "liked": liked,
        "featured": bool(row["featured"]),
        "viewed_count": int(row["viewed_count"]),
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(int(row["created_at"]))),
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(int(row["updated_at"]))),
    }


_SELECT = """SELECT g.*, u.nickname AS author_name, u.avatar AS author_avatar
             FROM guides g JOIN users u ON u.id = g.author_id"""


@router.get("/guides", summary="攻略列表（公开）")
def list_guides(
    skip: int = Query(default=0, ge=0, le=100000),
    limit: int = Query(default=50, ge=1, le=100),
    city: str | None = Query(default=None, max_length=60),
    region: str | None = Query(default=None, max_length=20),
    tag: str | None = Query(default=None, max_length=24),
    q: str | None = Query(default=None, max_length=60),
    featured: bool | None = None,
    sort: str = Query(default="latest", pattern="^(latest|hot)$"),
    user: dict | None = Depends(optional_user),
):
    where = ["g.status = 1"]
    params: list[object] = []
    if city:
        where.append("g.city = ?")
        params.append(city)
    if region:
        where.append("g.region = ?")
        params.append(region)
    if tag:
        where.append("g.tags LIKE ?")
        params.append(f'%"{tag}"%')
    if q:
        where.append("(g.title LIKE ? OR g.intro LIKE ? OR g.city LIKE ?)")
        params.extend([f"%{q}%"] * 3)
    if featured is not None:
        where.append("g.featured = ?")
        params.append(1 if featured else 0)

    order = "g.featured DESC, g.likes DESC, g.created_at DESC" if sort == "hot" else "g.featured DESC, g.created_at DESC"
    sql = f"{_SELECT} WHERE {' AND '.join(where)} ORDER BY {order} LIMIT ? OFFSET ?"
    params.extend([limit, skip])

    with db() as conn:
        rows = conn.execute(sql, tuple(params)).fetchall()
        if not rows:
            return []
        liked_ids: set[int] = set()
        fav_ids: set[int] = set()
        if user:
            ids = [int(r["id"]) for r in rows]
            ph = ",".join("?" * len(ids))
            liked_ids = {int(r["guide_id"]) for r in conn.execute(
                f"SELECT guide_id FROM guide_likes WHERE user_id = ? AND guide_id IN ({ph})",
                (user["id"], *ids),
            ).fetchall()}
            fav_ids = {int(r["guide_id"]) for r in conn.execute(
                f"SELECT guide_id FROM guide_favs WHERE user_id = ? AND guide_id IN ({ph})",
                (user["id"], *ids),
            ).fetchall()}
    return [guide_obj(r, liked=int(r["id"]) in liked_ids, is_favored=int(r["id"]) in fav_ids) for r in rows]


@router.get("/guides/{guide_id}", summary="攻略详情")
def get_guide(guide_id: int, user: dict | None = Depends(optional_user)):
    with db() as conn:
        row = conn.execute(f"{_SELECT} WHERE g.id = ? AND g.status = 1", (guide_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="攻略不存在或已下线")
        conn.execute("UPDATE guides SET viewed_count = viewed_count + 1 WHERE id = ?", (guide_id,))
        row = conn.execute(f"{_SELECT} WHERE g.id = ?", (guide_id,)).fetchone()
        liked = faved = False
        if user:
            liked = conn.execute(
                "SELECT 1 FROM guide_likes WHERE guide_id = ? AND user_id = ?", (guide_id, user["id"])
            ).fetchone() is not None
            faved = conn.execute(
                "SELECT 1 FROM guide_favs WHERE guide_id = ? AND user_id = ?", (guide_id, user["id"])
            ).fetchone() is not None
    return guide_obj(row, liked=liked, is_favored=faved)


@router.post("/guides", summary="发布攻略")
def create_guide(payload: GuideCreate, user: dict = Depends(require_user)):
    now = int(time.time())
    with tx() as conn:
        cur = conn.execute(
            """INSERT INTO guides (author_id, title, intro, city, days, cost, theme, region,
                   cover_seed, cover_image, banner_title, banner_subtitle, tags, cost_breakdown,
                   tips, itinerary, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                int(user["id"]),
                payload.title,
                payload.intro,
                payload.city,
                payload.days,
                payload.cost,
                payload.theme,
                payload.region,
                payload.cover_seed,
                payload.cover_image,
                payload.banner_title,
                payload.banner_subtitle,
                json_dump(payload.tags),
                json_dump([c.model_dump() for c in payload.cost_breakdown]),
                json_dump(payload.tips),
                json_dump([d.model_dump() for d in payload.itinerary]),
                now,
                now,
            ),
        )
        gid = int(cur.lastrowid)
        conn.execute(
            "UPDATE users SET likes_received = likes_received WHERE id = ?", (user["id"],)
        )
    return {"id": gid}


@router.delete("/guides/{guide_id}", summary="删除自己的攻略")
def delete_guide(guide_id: int, user: dict = Depends(require_user)):
    with tx() as conn:
        row = conn.execute("SELECT author_id FROM guides WHERE id = ?", (guide_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="攻略不存在")
        if int(row["author_id"]) != int(user["id"]):
            raise HTTPException(status_code=403, detail="无权删除他人的攻略")
        conn.execute("DELETE FROM guides WHERE id = ?", (guide_id,))
    return {"ok": True}


def _toggle(guide_id: int, user_id: int, table: str) -> tuple[int, bool]:
    now = int(time.time())
    with tx() as conn:
        guide = conn.execute("SELECT id FROM guides WHERE id = ? AND status = 1", (guide_id,)).fetchone()
        if guide is None:
            raise HTTPException(status_code=404, detail="攻略不存在或已下线")
        existing = conn.execute(
            f"SELECT 1 FROM {table} WHERE guide_id = ? AND user_id = ?", (guide_id, user_id)
        ).fetchone()
        if existing:
            conn.execute(f"DELETE FROM {table} WHERE guide_id = ? AND user_id = ?", (guide_id, user_id))
            active = False
        else:
            conn.execute(
                f"INSERT OR IGNORE INTO {table} (guide_id, user_id, created_at) VALUES (?,?,?)",
                (guide_id, user_id, now),
            )
            active = True
        count = int(conn.execute(
            f"SELECT COUNT(*) AS c FROM {table} WHERE guide_id = ?", (guide_id,)
        ).fetchone()["c"])
        column = "likes" if table == "guide_likes" else "favs"
        conn.execute(f"UPDATE guides SET {column} = ? WHERE id = ?", (count, guide_id))
    return count, active


@router.post("/guides/{guide_id}/like", summary="点赞 / 取消点赞")
def toggle_like(guide_id: int, user: dict = Depends(require_user)):
    likes, liked = _toggle(guide_id, int(user["id"]), "guide_likes")
    if liked:
        with tx() as conn:
            conn.execute(
                "UPDATE users SET likes_received = likes_received + 1 WHERE id = (SELECT author_id FROM guides WHERE id = ?)",
                (guide_id,),
            )
    else:
        with tx() as conn:
            conn.execute(
                "UPDATE users SET likes_received = MAX(0, likes_received - 1) WHERE id = (SELECT author_id FROM guides WHERE id = ?)",
                (guide_id,),
            )
    return {"data": {"likes": likes, "liked": liked}}


@router.post("/guides/{guide_id}/fav", summary="收藏 / 取消收藏")
def toggle_fav(guide_id: int, user: dict = Depends(require_user)):
    favs, favored = _toggle(guide_id, int(user["id"]), "guide_favs")
    return {"data": {"favs": favs, "favored": favored}}


@router.post("/upload/cover", summary="上传攻略封面")
def upload_cover(file: UploadFile = File(...), user: dict = Depends(require_user)):
    saved = save_upload(file, int(user["id"]), category="cover")
    return {"url": saved["url"], "sha256": saved["sha256"], "bytes": saved["bytes"], "mime": saved["mime"]}
