"""账号注销：申请 → 7 天冷静期 → 到期自动删除账号与全部云端数据。

- POST   /api/account/deletion  提交申请（校验当前密码）
- GET    /api/account/deletion  查询进度
- DELETE /api/account/deletion  撤销申请
- 后台线程每小时扫描一次到期申请；删除范围与管理员删号一致：
  media 文件、users 行（级联删除攻略/评论/关注/私信等）、整个 user_root 文件夹。
"""
from __future__ import annotations

import logging
import shutil
import threading
import time
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException

from ..db import db, tx
from ..deps import audit, client_ip, require_user
from ..schemas import DeleteAccountRequest
from ..security import bcrypt_hash_prehashed, bcrypt_verify
from ..storage import delete_media_file, user_root

router = APIRouter(prefix="/api/account", tags=["账号"])
logger = logging.getLogger("myzuji.account")

GRACE_DAYS = 7
GRACE_SECONDS = GRACE_DAYS * 86400


def _iso(ts: int | None) -> str | None:
    if not ts:
        return None
    return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def _verify_current_password(user: dict, payload: DeleteAccountRequest) -> bool:
    with db() as conn:
        row = conn.execute("SELECT password_hash, pwd_scheme FROM users WHERE id = ?", (user["id"],)).fetchone()
    if row is None or int(row["pwd_scheme"] or 2) != 2:
        return False
    return bcrypt_verify(payload.password_hash, row["password_hash"])


def _request_row(user_id: int) -> dict | None:
    with db() as conn:
        row = conn.execute(
            "SELECT * FROM deletion_requests WHERE user_id = ? AND status = 0", (user_id,)
        ).fetchone()
    return dict(row) if row else None


@router.get("/deletion", summary="查询注销申请状态")
def get_deletion(user: dict = Depends(require_user)):
    now = int(time.time())
    row = _request_row(int(user["id"]))
    if row is None:
        return {"pending": False, "grace_days": GRACE_DAYS}
    return {
        "pending": True,
        "requested_at": _iso(row["requested_at"]),
        "scheduled_at": _iso(row["scheduled_at"]),
        "days_left": max(0, (int(row["scheduled_at"]) - now + 86399) // 86400),
        "grace_days": GRACE_DAYS,
    }


@router.post("/deletion", summary="申请注销账号（7 天冷静期，可撤销）")
def request_deletion(payload: DeleteAccountRequest, user: dict = Depends(require_user), ip: str = Depends(client_ip)):
    if not _verify_current_password(user, payload):
        raise HTTPException(status_code=401, detail="密码不正确")

    now = int(time.time())
    with tx() as conn:
        existing = conn.execute(
            "SELECT * FROM deletion_requests WHERE user_id = ? AND status = 0", (user["id"],)
        ).fetchone()
        if existing:
            scheduled = int(existing["scheduled_at"])
        else:
            scheduled = now + GRACE_SECONDS
            conn.execute(
                """INSERT INTO deletion_requests (user_id, status, requested_at, scheduled_at, reason)
                   VALUES (?,0,?,?,'')""",
                (user["id"], now, scheduled),
            )
    audit("system", "account_deletion_request", target=f"user:{user['id']}", ip=ip)
    return {
        "ok": True,
        "pending": True,
        "requested_at": _iso(now),
        "scheduled_at": _iso(scheduled),
        "days_left": max(0, (scheduled - now + 86399) // 86400),
        "grace_days": GRACE_DAYS,
        "detail": "冷静期内可随时撤销；到期后账号、云端足迹、照片和攻略评论将全部删除",
    }


@router.delete("/deletion", summary="撤销注销申请")
def cancel_deletion(user: dict = Depends(require_user), ip: str = Depends(client_ip)):
    with tx() as conn:
        row = conn.execute(
            "SELECT * FROM deletion_requests WHERE user_id = ? AND status = 0", (user["id"],)
        ).fetchone()
        if row is None:
            return {"ok": True, "pending": False}
        conn.execute(
            "UPDATE deletion_requests SET status = 1 WHERE user_id = ?", (user["id"],)
        )
    audit("system", "account_deletion_cancel", target=f"user:{user['id']}", ip=ip)
    return {"ok": True, "pending": False}


def purge_due_deletions() -> int:
    """删除所有已到期账号，返回执行数量。"""
    now = int(time.time())
    with db() as conn:
        due = conn.execute(
            "SELECT user_id FROM deletion_requests WHERE status = 0 AND scheduled_at <= ?", (now,)
        ).fetchall()
    removed = 0
    for item in due:
        uid = int(item["user_id"])
        try:
            with db() as conn:
                media_rows = conn.execute("SELECT rel_path FROM media WHERE user_id = ?", (uid,)).fetchall()
            for media in media_rows:
                delete_media_file(media["rel_path"])
            with tx() as conn:
                conn.execute("UPDATE deletion_requests SET status = 2 WHERE user_id = ?", (uid,))
                conn.execute("DELETE FROM users WHERE id = ?", (uid,))
            shutil.rmtree(user_root(uid), ignore_errors=True)
            removed += 1
            audit("system", "account_deletion_executed", target=f"user:{uid}")
            logger.info("已按注销申请删除账号 user_id=%s", uid)
        except Exception:
            logger.exception("删除到期账号失败 user_id=%s", uid)
    return removed


class DeletionJanitor:
    def __init__(self, interval_seconds: int = 3600) -> None:
        self.interval = interval_seconds
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="account-deletion-janitor", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3)

    def _run(self) -> None:
        # 启动先扫一次，之后每小时一次
        while not self._stop.is_set():
            try:
                purge_due_deletions()
            except Exception:
                logger.exception("注销清理线程异常")
            self._stop.wait(self.interval)


janitor = DeletionJanitor()
