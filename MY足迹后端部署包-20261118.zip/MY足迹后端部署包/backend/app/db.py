"""SQLite 数据访问层。

选 SQLite 而不是 PostgreSQL 的理由：单台服务器、单进程 uvicorn 就能跑，
备份就是复制一个文件，换机迁移成本最低。所有 SQL 都走参数绑定，不拼字符串。

并发：SQLite 打开 WAL，写入用 BEGIN IMMEDIATE 的短事务；接口函数是同步 def，
FastAPI 会放到线程池执行，不会阻塞事件循环。
"""
from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from typing import Any, Iterable, Iterator

from .config import settings
from .security import bcrypt_hash_prehashed, password_prehash

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL COLLATE NOCASE UNIQUE, -- 登录账号（唯一，大小写不敏感）
    reg_ip        TEXT NOT NULL DEFAULT '',            -- 注册 IP：同一 IP 最多 5 个账号
    nickname      TEXT NOT NULL DEFAULT '旅行者',
    signature     TEXT NOT NULL DEFAULT '',
    avatar        TEXT,
    password_hash TEXT NOT NULL,
    pwd_scheme    INTEGER NOT NULL DEFAULT 2,          -- 2=固定盐预哈希 / 3=旧账号待管理员重置
    status        INTEGER NOT NULL DEFAULT 1,          -- 1 正常 / 0 封禁
    default_public INTEGER NOT NULL DEFAULT 1,
    notif_enabled  INTEGER NOT NULL DEFAULT 1,
    share_enabled  INTEGER NOT NULL DEFAULT 1,
    token_version  INTEGER NOT NULL DEFAULT 1,         -- 改密/封禁时 +1，旧 token 全部失效
    login_fail_count INTEGER NOT NULL DEFAULT 0,
    locked_until  INTEGER NOT NULL DEFAULT 0,
    followers_count INTEGER NOT NULL DEFAULT 0,
    following_count INTEGER NOT NULL DEFAULT 0,
    likes_received  INTEGER NOT NULL DEFAULT 0,
    cities_count  INTEGER NOT NULL DEFAULT 0,
    footprint_count INTEGER NOT NULL DEFAULT 0,
    days_count    INTEGER NOT NULL DEFAULT 0,
    note          TEXT NOT NULL DEFAULT '',
    last_login_at INTEGER,
    created_at    INTEGER NOT NULL,
    updated_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);

-- 注册验证地址：地址里带一次性验证码；打开即视为验证通过，注册成功后整条删除
CREATE TABLE IF NOT EXISTS verify_links (
    id          TEXT PRIMARY KEY,                      -- URL 里的随机路径
    username    TEXT NOT NULL COLLATE NOCASE,
    code_hash   TEXT NOT NULL,
    verified_at INTEGER NOT NULL DEFAULT 0,
    used        INTEGER NOT NULL DEFAULT 0,
    ip          TEXT NOT NULL DEFAULT '',
    expires_at  INTEGER NOT NULL,
    created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_verify_links_user ON verify_links(username, created_at DESC);

-- 注销申请：7 天冷静期；到期由清理线程删除账号与全部云端数据
CREATE TABLE IF NOT EXISTS deletion_requests (
    user_id      INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    status       INTEGER NOT NULL DEFAULT 0,           -- 0 待删 / 1 已撤销 / 2 已执行
    requested_at INTEGER NOT NULL,
    scheduled_at INTEGER NOT NULL,
    reason       TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_deletion_sched ON deletion_requests(status, scheduled_at);
CREATE TABLE IF NOT EXISTS guides (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    author_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title        TEXT NOT NULL,
    intro        TEXT NOT NULL DEFAULT '',
    city         TEXT NOT NULL DEFAULT '',
    days         INTEGER NOT NULL DEFAULT 1,
    cost         TEXT NOT NULL DEFAULT '',
    theme        TEXT NOT NULL DEFAULT '',
    region       TEXT NOT NULL DEFAULT '',
    cover_seed   INTEGER NOT NULL DEFAULT 0,
    cover_image  TEXT,
    banner_title TEXT NOT NULL DEFAULT '',
    banner_subtitle TEXT NOT NULL DEFAULT '',
    tags         TEXT NOT NULL DEFAULT '[]',
    cost_breakdown TEXT NOT NULL DEFAULT '[]',
    tips         TEXT NOT NULL DEFAULT '[]',
    itinerary    TEXT NOT NULL DEFAULT '[]',
    likes        INTEGER NOT NULL DEFAULT 0,
    favs         INTEGER NOT NULL DEFAULT 0,
    viewed_count INTEGER NOT NULL DEFAULT 0,
    featured     INTEGER NOT NULL DEFAULT 0,
    status       INTEGER NOT NULL DEFAULT 1,           -- 1 正常 / 0 隐藏
    created_at   INTEGER NOT NULL,
    updated_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_guides_author ON guides(author_id);
CREATE INDEX IF NOT EXISTS idx_guides_status ON guides(status, created_at DESC);

CREATE TABLE IF NOT EXISTS guide_likes (
    guide_id INTEGER NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
    user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL,
    PRIMARY KEY (guide_id, user_id)
);

CREATE TABLE IF NOT EXISTS guide_favs (
    guide_id INTEGER NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
    user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL,
    PRIMARY KEY (guide_id, user_id)
);

CREATE TABLE IF NOT EXISTS comments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    guide_id   INTEGER NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    parent_id  INTEGER REFERENCES comments(id) ON DELETE CASCADE,
    content    TEXT NOT NULL,
    likes      INTEGER NOT NULL DEFAULT 0,
    dislikes   INTEGER NOT NULL DEFAULT 0,
    status     INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_comments_guide ON comments(guide_id, created_at);

CREATE TABLE IF NOT EXISTS routes (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title         TEXT NOT NULL,
    cities        TEXT NOT NULL DEFAULT '[]',
    date          TEXT NOT NULL DEFAULT '',
    year          INTEGER NOT NULL DEFAULT 0,
    note          TEXT NOT NULL DEFAULT '',
    cover_seed    INTEGER NOT NULL DEFAULT 0,
    special       INTEGER NOT NULL DEFAULT 0,
    special_reason TEXT NOT NULL DEFAULT '',
    tags          TEXT NOT NULL DEFAULT '[]',
    spots         TEXT NOT NULL DEFAULT '[]',
    photos        TEXT NOT NULL DEFAULT '[]',
    created_at    INTEGER NOT NULL,
    updated_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_routes_user ON routes(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS sync_footprints (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_id  INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    payload    TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    UNIQUE (user_id, client_id)
);
CREATE INDEX IF NOT EXISTS idx_sync_fp_user ON sync_footprints(user_id);

CREATE TABLE IF NOT EXISTS sync_routes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_id  INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    payload    TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    UNIQUE (user_id, client_id)
);
CREATE INDEX IF NOT EXISTS idx_sync_rt_user ON sync_routes(user_id);

CREATE TABLE IF NOT EXISTS sync_settings (
    user_id    INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    payload    TEXT NOT NULL,
    updated_at INTEGER NOT NULL
);

-- 通用分区同步：音乐收藏、评论、计划、自定义清单……
-- 不预设字段，payload 由客户端定义，服务端只负责幂等存取与镜像成文件。
CREATE TABLE IF NOT EXISTS sync_collections (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind       TEXT NOT NULL,
    client_id  TEXT NOT NULL,
    updated_at INTEGER NOT NULL,
    payload    TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    UNIQUE (user_id, kind, client_id)
);
CREATE INDEX IF NOT EXISTS idx_sync_col_user ON sync_collections(user_id, kind);

-- 整机档案：客户端把所有本地数据打成一份 JSON 上传，服务端按用户存一份最新 + 历史留档
CREATE TABLE IF NOT EXISTS user_archives (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    sections   TEXT NOT NULL DEFAULT '{}',
    bytes      INTEGER NOT NULL DEFAULT 0,
    rel_path   TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_archives_user ON user_archives(user_id, created_at DESC);

-- 隐私空间：端侧 AES-GCM 加密后的密文块，服务端只存 bytes，不解密
CREATE TABLE IF NOT EXISTS vault_files (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    sha256     TEXT NOT NULL,
    item_id    TEXT NOT NULL DEFAULT '',
    name       TEXT NOT NULL DEFAULT '',
    kind       TEXT NOT NULL DEFAULT 'image',
    bytes      INTEGER NOT NULL,
    rel_path   TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    UNIQUE (user_id, sha256)
);
CREATE INDEX IF NOT EXISTS idx_vault_user ON vault_files(user_id);

CREATE TABLE IF NOT EXISTS media (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    sha256     TEXT NOT NULL,
    url        TEXT NOT NULL,
    rel_path   TEXT NOT NULL,
    bytes      INTEGER NOT NULL,
    mime       TEXT NOT NULL,
    kind       TEXT NOT NULL DEFAULT 'image',
    created_at INTEGER NOT NULL,
    UNIQUE (user_id, sha256)
);
CREATE INDEX IF NOT EXISTS idx_media_user ON media(user_id);

CREATE TABLE IF NOT EXISTS captchas (
    id         TEXT PRIMARY KEY,
    code       TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    used       INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS user_follows (
    follower_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  INTEGER NOT NULL,
    PRIMARY KEY (follower_id, target_id)
);

CREATE TABLE IF NOT EXISTS follow_notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    actor_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL,
    read       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_follow_notifications_user
    ON follow_notifications(user_id, read, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    actor      TEXT NOT NULL,
    action     TEXT NOT NULL,
    target     TEXT NOT NULL DEFAULT '',
    detail     TEXT NOT NULL DEFAULT '',
    ip         TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);

CREATE TABLE IF NOT EXISTS revoked_tokens (
    jti        TEXT PRIMARY KEY,
    expires_at INTEGER NOT NULL
);

-- ==================== AI 端点配置（云端保管） ====================
-- 推理仍由手机直连服务商，这里只加密保存 base_url / api_key / 模型名，
-- 换机或重装登录后由本人拉回；管理员后台只看到条数与时间，不展示 Key。
CREATE TABLE IF NOT EXISTS ai_endpoints (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id                 INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_id               TEXT NOT NULL,              -- App 侧的端点 id（字符串）
    name                    TEXT NOT NULL DEFAULT '',
    format                  TEXT NOT NULL DEFAULT 'OPENAI',
    base_url                TEXT NOT NULL DEFAULT '',
    api_key_enc             TEXT NOT NULL DEFAULT '',   -- AES-256-GCM 密文，密钥由 SECRET_KEY 派生
    model                   TEXT NOT NULL DEFAULT '',
    vision_model            TEXT NOT NULL DEFAULT '',
    image_model             TEXT NOT NULL DEFAULT '',
    video_model             TEXT NOT NULL DEFAULT '',
    capabilities            TEXT NOT NULL DEFAULT '[]',
    context_tokens          INTEGER NOT NULL DEFAULT 200000,
    max_output_tokens       INTEGER NOT NULL DEFAULT 4096,
    vision_context_tokens   INTEGER NOT NULL DEFAULT 8000,
    vision_max_output_tokens INTEGER NOT NULL DEFAULT 1024,
    media_path              TEXT NOT NULL DEFAULT '',
    video_path              TEXT NOT NULL DEFAULT '',
    created_at              INTEGER NOT NULL,
    updated_at              INTEGER NOT NULL,
    UNIQUE (user_id, client_id)
);
CREATE INDEX IF NOT EXISTS idx_ai_endpoints_user ON ai_endpoints(user_id);

-- AI 偏好：当前选中的端点、单功能分配、OCR 端点等（不含任何 Key）
CREATE TABLE IF NOT EXISTS ai_state (
    user_id    INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    payload    TEXT NOT NULL DEFAULT '{}',
    updated_at INTEGER NOT NULL
);

-- ==================== 网页抓取与清洗 ====================

-- 内容源：一个站点 / 栏目 / RSS。后台配置，worker 按 interval_minutes 轮跑。
CREATE TABLE IF NOT EXISTS content_sources (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    name             TEXT NOT NULL,
    kind             TEXT NOT NULL DEFAULT 'html',   -- html | rss | sitemap
    list_url         TEXT NOT NULL,                  -- 列表页 / RSS / sitemap
    host             TEXT NOT NULL DEFAULT '',       -- 只在这个域名内发现链接，空 = 列表页同域
    url_prefix       TEXT NOT NULL DEFAULT '',       -- 只收以该前缀开头的链接
    default_category TEXT NOT NULL DEFAULT '',       -- 打给条目的分类（攻略/资讯/…）
    enabled          INTEGER NOT NULL DEFAULT 1,
    interval_minutes INTEGER NOT NULL DEFAULT 60,
    max_items        INTEGER NOT NULL DEFAULT 12,    -- 每轮最多新抓多少条
    last_run_at      INTEGER NOT NULL DEFAULT 0,
    last_status      TEXT NOT NULL DEFAULT '',
    created_at       INTEGER NOT NULL,
    updated_at       INTEGER NOT NULL
);

-- 清洗后的内容条目：App 只认这张表，不认原始 HTML
CREATE TABLE IF NOT EXISTS content_items (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id     INTEGER REFERENCES content_sources(id) ON DELETE SET NULL,
    url           TEXT NOT NULL,
    canonical_url TEXT NOT NULL DEFAULT '',
    url_hash      TEXT NOT NULL,                     -- sha256(规范化 URL)，去重用
    content_hash  TEXT NOT NULL DEFAULT '',          -- sha256(正文指纹)，转载去重用
    host          TEXT NOT NULL DEFAULT '',
    title         TEXT NOT NULL DEFAULT '',
    summary       TEXT NOT NULL DEFAULT '',
    body_text     TEXT NOT NULL DEFAULT '',
    blocks        TEXT NOT NULL DEFAULT '[]',         -- 结构化段落 [{type,text}]
    images        TEXT NOT NULL DEFAULT '[]',         -- 配图绝对 URL
    author        TEXT NOT NULL DEFAULT '',
    category      TEXT NOT NULL DEFAULT '',
    lang          TEXT NOT NULL DEFAULT '',
    word_count    INTEGER NOT NULL DEFAULT 0,
    published_at  INTEGER NOT NULL DEFAULT 0,
    fetched_at    INTEGER NOT NULL,
    status        INTEGER NOT NULL DEFAULT 1,         -- 1 正常 / 0 后台隐藏
    created_at    INTEGER NOT NULL,
    updated_at    INTEGER NOT NULL,
    UNIQUE (url_hash)
);
CREATE INDEX IF NOT EXISTS idx_content_feed ON content_items(status, id DESC);
CREATE INDEX IF NOT EXISTS idx_content_source ON content_items(source_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_content_content_hash ON content_items(content_hash);

-- 抓取任务队列：后台入队，worker 串行消费；失败带错误原因与重试次数
CREATE TABLE IF NOT EXISTS content_jobs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL DEFAULT 'url',         -- url（抓单页）| source（跑一个源）
    source_id   INTEGER,
    url         TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'queued',      -- queued | running | done | failed
    attempts    INTEGER NOT NULL DEFAULT 0,
    next_attempt_at INTEGER NOT NULL DEFAULT 0,      -- 失败退避：到点之前不重试
    created_items INTEGER NOT NULL DEFAULT 0,
    error       TEXT NOT NULL DEFAULT '',
    created_at  INTEGER NOT NULL,
    started_at  INTEGER NOT NULL DEFAULT 0,
    finished_at INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_content_jobs_status ON content_jobs(status, id);

-- ==================== 站内私信 ====================

-- 单聊会话：不预设方向，user_a < user_b，保证一对用户只有一条会话
CREATE TABLE IF NOT EXISTS conversations (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_a        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_b        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    last_message_id INTEGER NOT NULL DEFAULT 0,
    last_message_at INTEGER NOT NULL DEFAULT 0,
    last_preview  TEXT NOT NULL DEFAULT '',
    a_unread      INTEGER NOT NULL DEFAULT 0,
    b_unread      INTEGER NOT NULL DEFAULT 0,
    a_last_read_seq INTEGER NOT NULL DEFAULT 0,
    b_last_read_seq INTEGER NOT NULL DEFAULT 0,
    a_muted       INTEGER NOT NULL DEFAULT 0,
    b_muted       INTEGER NOT NULL DEFAULT 0,
    created_at    INTEGER NOT NULL,
    updated_at    INTEGER NOT NULL,
    UNIQUE (user_a, user_b)
);
CREATE INDEX IF NOT EXISTS idx_conv_a ON conversations(user_a, last_message_at DESC);
CREATE INDEX IF NOT EXISTS idx_conv_b ON conversations(user_b, last_message_at DESC);

-- 消息：seq 在会话内单调递增，客户端按 seq 做增量同步与已读水位
CREATE TABLE IF NOT EXISTS messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    seq             INTEGER NOT NULL,
    client_msg_id   TEXT NOT NULL DEFAULT '',       -- 客户端幂等键
    type            TEXT NOT NULL DEFAULT 'text',   -- text | image | system
    body            TEXT NOT NULL DEFAULT '',
    extra           TEXT NOT NULL DEFAULT '{}',
    status          INTEGER NOT NULL DEFAULT 1,     -- 1 正常 / 0 已撤回
    created_at      INTEGER NOT NULL,
    UNIQUE (conversation_id, seq),
    UNIQUE (conversation_id, client_msg_id)
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id, seq DESC);

-- 黑名单：任一方拉黑后，双方都不能再发（读历史不受影响）
CREATE TABLE IF NOT EXISTS user_blocks (
    owner_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    blocked_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL,
    PRIMARY KEY (owner_id, blocked_id)
);

-- ==================== 联网搜索（临时会话） ====================

-- 只存一次搜索的结果快照，TTL 到期或客户端关闭后整行删除；
-- 网页原始 HTML 从不落盘，也不进 content_items。
CREATE TABLE IF NOT EXISTS search_sessions (
    id         TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    query      TEXT NOT NULL,
    strength   TEXT NOT NULL DEFAULT 'balanced',   -- fast | balanced | deep
    provider   TEXT NOT NULL DEFAULT '',
    items      TEXT NOT NULL DEFAULT '[]',         -- 清洗后的结果 JSON
    item_count INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_search_sessions_user ON search_sessions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_search_sessions_expire ON search_sessions(expires_at);
"""


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(str(settings.db_file), timeout=30.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


@contextmanager
def db() -> Iterator[sqlite3.Connection]:
    conn = connect()
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def tx() -> Iterator[sqlite3.Connection]:
    """短事务：BEGIN IMMEDIATE 抢写锁，避免并发 upsert 相互覆盖。"""
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        yield conn
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        conn.close()


def _table_columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {str(row["name"]) for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def migrate() -> None:
    """老库无损升级：彻底移除 email，账号只保留 username。

    - 老库先把 email 前缀回填成用户名（重名加 _2/_3），再重建 users 表删掉 email 列；
    - 旧版密码是「邮箱盐」预哈希，没有邮箱就无法校验，统一标记 pwd_scheme=3，
      由管理员在后台重置为新版固定盐密码后再登录；
    - 删除历史 email_codes / email_send_log 两张邮件验证码表。
    """
    import re

    conn = connect()
    try:
        conn.execute("PRAGMA foreign_keys=OFF")
        cols = _table_columns(conn, "users")
        if "email" not in cols:
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username COLLATE NOCASE)"
            )
            conn.execute("DROP TABLE IF EXISTS email_codes")
            conn.execute("DROP TABLE IF EXISTS email_send_log")
            return

        conn.execute("BEGIN IMMEDIATE")
        if "username" not in cols:
            conn.execute("ALTER TABLE users ADD COLUMN username TEXT")
        if "reg_ip" not in cols:
            conn.execute("ALTER TABLE users ADD COLUMN reg_ip TEXT NOT NULL DEFAULT ''")
        if "pwd_scheme" not in cols:
            conn.execute("ALTER TABLE users ADD COLUMN pwd_scheme INTEGER NOT NULL DEFAULT 3")

        rows = conn.execute("SELECT id, email, username FROM users ORDER BY id").fetchall()
        used = {str(r["username"]).casefold() for r in rows if r["username"]}
        for row in rows:
            if row["username"]:
                continue
            local = str(row["email"] or "").split("@")[0]
            base = re.sub(r"[^A-Za-z0-9_\u4e00-\u9fa5]", "", local)[:20]
            if len(base) < 3:
                base = f"user{row['id']}"
            candidate = base
            index = 2
            while candidate.casefold() in used:
                suffix = f"_{index}"
                candidate = base[: 20 - len(suffix)] + suffix
                index += 1
            used.add(candidate.casefold())
            conn.execute("UPDATE users SET username = ? WHERE id = ?", (candidate, row["id"]))

        # 旧「邮箱盐」密码无法再校验，标记为待管理员重置
        conn.execute("UPDATE users SET pwd_scheme = 3 WHERE pwd_scheme = 1")

        conn.execute(
            """CREATE TABLE users_new (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                username      TEXT NOT NULL COLLATE NOCASE UNIQUE,
                reg_ip        TEXT NOT NULL DEFAULT '',
                nickname      TEXT NOT NULL DEFAULT '旅行者',
                signature     TEXT NOT NULL DEFAULT '',
                avatar        TEXT,
                password_hash TEXT NOT NULL,
                pwd_scheme    INTEGER NOT NULL DEFAULT 2,
                status        INTEGER NOT NULL DEFAULT 1,
                default_public INTEGER NOT NULL DEFAULT 1,
                notif_enabled  INTEGER NOT NULL DEFAULT 1,
                share_enabled  INTEGER NOT NULL DEFAULT 1,
                token_version  INTEGER NOT NULL DEFAULT 1,
                login_fail_count INTEGER NOT NULL DEFAULT 0,
                locked_until  INTEGER NOT NULL DEFAULT 0,
                followers_count INTEGER NOT NULL DEFAULT 0,
                following_count INTEGER NOT NULL DEFAULT 0,
                likes_received  INTEGER NOT NULL DEFAULT 0,
                cities_count  INTEGER NOT NULL DEFAULT 0,
                footprint_count INTEGER NOT NULL DEFAULT 0,
                days_count    INTEGER NOT NULL DEFAULT 0,
                note          TEXT NOT NULL DEFAULT '',
                last_login_at INTEGER,
                created_at    INTEGER NOT NULL,
                updated_at    INTEGER NOT NULL
            )"""
        )
        conn.execute(
            """INSERT INTO users_new (
                   id, username, reg_ip, nickname, signature, avatar, password_hash, pwd_scheme,
                   status, default_public, notif_enabled, share_enabled, token_version,
                   login_fail_count, locked_until, followers_count, following_count, likes_received,
                   cities_count, footprint_count, days_count, note, last_login_at, created_at, updated_at)
               SELECT id, username, reg_ip, nickname, signature, avatar, password_hash, pwd_scheme,
                   status, default_public, notif_enabled, share_enabled, token_version,
                   login_fail_count, locked_until, followers_count, following_count, likes_received,
                   cities_count, footprint_count, days_count, note, last_login_at, created_at, updated_at
               FROM users"""
        )
        conn.execute("DROP TABLE users")
        conn.execute("ALTER TABLE users_new RENAME TO users")
        conn.execute("CREATE UNIQUE INDEX idx_users_username ON users(username COLLATE NOCASE)")
        conn.execute("DROP TABLE IF EXISTS email_codes")
        conn.execute("DROP TABLE IF EXISTS email_send_log")
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        conn.execute("PRAGMA foreign_keys=ON")
        conn.close()


def init_db() -> None:
    settings.prepare_dirs()
    with db() as conn:
        conn.executescript(SCHEMA)
    migrate()
    seed()


def seed() -> None:
    """幂等初始化：写入测试账号与一条示例攻略（已存在则跳过）。"""
    now = int(time.time())
    with tx() as conn:
        conn.execute("DELETE FROM captchas WHERE expires_at < ?", (now - 3600,))
        conn.execute("DELETE FROM revoked_tokens WHERE expires_at < ?", (now,))

        username = settings.test_account_username.strip()
        if settings.seed_test_account and username:
            row = conn.execute(
                "SELECT id FROM users WHERE username = ? COLLATE NOCASE", (username,)
            ).fetchone()
            if row is None:
                prehashed = password_prehash(settings.test_account_password)
                conn.execute(
                    """INSERT INTO users (username, nickname, signature, password_hash, pwd_scheme, status,
                           default_public, notif_enabled, share_enabled, token_version,
                           created_at, updated_at)
                       VALUES (?,?,?,?,2,1,1,1,1,1,?,?)""",
                    (
                        username,
                        settings.test_account_nickname,
                        "山高路远，看世界，也找自己",
                        bcrypt_hash_prehashed(prehashed),
                        now,
                        now,
                    ),
                )


def row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


def json_load(raw: Any, default: Any = None) -> Any:
    if raw is None:
        return default
    if isinstance(raw, (list, dict)):
        return raw
    try:
        return json.loads(raw)
    except (TypeError, ValueError):
        return default


def json_dump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def count_rows(conn: sqlite3.Connection, table: str, where: str = "", params: Iterable[Any] = ()) -> int:
    sql = f"SELECT COUNT(*) AS c FROM {table} {where}"
    return int(conn.execute(sql, tuple(params)).fetchone()["c"])
