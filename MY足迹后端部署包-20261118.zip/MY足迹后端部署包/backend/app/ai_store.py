"""AI 端点配置的云端保管。

业务约定（与 App 侧一致）：
- **推理请求仍然由手机直接发往模型服务商**，服务器不代理、不中转对话内容；
- 服务器只负责把用户填写的 `base_url` / `api_key` / 模型名等配置加密保存，
  换机或重装后由本人登录拉回，避免用户重填、也避免 Key 只存在一台设备上。

安全边界：
- `api_key` 以 AES-256-GCM 加密后落库，密钥由 `SECRET_KEY` 经 HKDF-SHA256 派生，
  与 JWT 签名密钥同源但用途隔离（不同 salt/info，不能互相复用）；
- 只有 `require_user` 通过的本人能读到解密后的配置，管理员后台只看到条数与时间；
- 日志、审计、错误信息里都不出现 Key 原文。
"""
from __future__ import annotations

import base64
import json
import os
import re
import time
from typing import Any, Iterable

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .config import get_jwt_secret
from .db import json_dump, json_load, tx

SEALED_PREFIX = "v1:"
_CLIENT_ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,64}$")
_FORMATS = {"OPENAI", "ANTHROPIC", "GEMINI"}
_CAPABILITIES = {"TEXT", "VISION", "IMAGE_GEN", "VIDEO_GEN"}
MAX_ENDPOINTS = 32


def _aead_key() -> bytes:
    return HKDF(
        algorithm=SHA256(),
        length=32,
        salt=b"myzuji/ai-endpoint/v1",
        info=b"aes-256-gcm",
    ).derive(get_jwt_secret().encode("utf-8"))


def seal_secret(plaintext: str) -> str:
    """把明文（这里是 API Key）加密成可入库的字符串；空串保持空串。"""
    value = (plaintext or "").strip()
    if not value:
        return ""
    nonce = os.urandom(12)
    ct = AESGCM(_aead_key()).encrypt(nonce, value.encode("utf-8"), b"ai-endpoint")
    return SEALED_PREFIX + base64.urlsafe_b64encode(nonce + ct).decode("ascii")


def open_secret(sealed: str) -> str:
    """解密；格式不对或密钥变更时抛出 ValueError，由调用方决定是清空还是报错。"""
    value = (sealed or "").strip()
    if not value:
        return ""
    if not value.startswith(SEALED_PREFIX):
        raise ValueError("密文格式不正确")
    raw = base64.urlsafe_b64decode(value[len(SEALED_PREFIX):].encode("ascii"))
    if len(raw) < 13:
        raise ValueError("密文长度不正确")
    nonce, ct = raw[:12], raw[12:]
    return AESGCM(_aead_key()).decrypt(nonce, ct, b"ai-endpoint").decode("utf-8")


def normalize_endpoint(item: dict[str, Any]) -> dict[str, Any]:
    """字段裁剪与类型收敛；非法值抛 ValueError（由路由转成 422）。"""
    client_id = str(item.get("client_id") or item.get("id") or "").strip()
    if not _CLIENT_ID_RE.match(client_id):
        raise ValueError("端点 id 只能包含字母、数字、下划线、点、冒号、短横线，最长 64 位")

    fmt = str(item.get("format") or "OPENAI").strip().upper()
    if fmt not in _FORMATS:
        raise ValueError("不支持的接口协议")
    name = str(item.get("name") or "自定义 API").strip()[:60]
    base_url = str(item.get("base_url") or item.get("baseUrl") or "").strip()[:500]
    if not (base_url.startswith("http://") or base_url.startswith("https://")):
        raise ValueError("接口地址必须以 http:// 或 https:// 开头")
    if "@" in base_url.split("//", 1)[-1].split("/", 1)[0]:
        raise ValueError("接口地址不能包含用户名口令")

    def _cap(raw: Any) -> list[str]:
        if isinstance(raw, str):
            raw = [part for part in re.split(r"[,\s]+", raw) if part]
        if not isinstance(raw, Iterable) or isinstance(raw, (str, bytes)):
            return []
        out: list[str] = []
        for part in raw:
            value = str(part).strip().upper()
            if value in _CAPABILITIES and value not in out:
                out.append(value)
        return out

    def _int(raw: Any, default: int, low: int, high: int) -> int:
        try:
            value = int(raw)
        except (TypeError, ValueError):
            value = default
        return max(low, min(high, value))

    return {
        "client_id": client_id,
        "name": name or "自定义 API",
        "format": fmt,
        "base_url": base_url,
        "api_key": str(item.get("api_key") or item.get("apiKey") or "").strip()[:4096],
        "model": str(item.get("model") or "").strip()[:160],
        "vision_model": str(item.get("vision_model") or item.get("visionModel") or "").strip()[:160],
        "image_model": str(item.get("image_model") or item.get("imageModel") or "").strip()[:160],
        "video_model": str(item.get("video_model") or item.get("videoModel") or "").strip()[:160],
        "capabilities": _cap(item.get("capabilities")),
        "context_tokens": _int(item.get("context_tokens") or item.get("contextTokens"), 200_000, 1024, 2_000_000),
        "max_output_tokens": _int(item.get("max_output_tokens") or item.get("maxOutputTokens"), 4096, 1, 262_144),
        "vision_context_tokens": _int(
            item.get("vision_context_tokens") or item.get("visionContextTokens"), 8000, 1024, 2_000_000
        ),
        "vision_max_output_tokens": _int(
            item.get("vision_max_output_tokens") or item.get("visionMaxOutputTokens"), 1024, 1, 262_144
        ),
        "media_path": str(item.get("media_path") or item.get("mediaPath") or "").strip()[:200],
        "video_path": str(item.get("video_path") or item.get("videoPath") or "").strip()[:200],
        "builtin": False,
    }


def _row_to_endpoint(row) -> dict[str, Any]:
    try:
        api_key = open_secret(row["api_key_enc"])
    except ValueError:
        # 密钥轮换或密文损坏时不阻断整体恢复：这条端点按“未配置 Key”返回，用户重填即可
        api_key = ""
    return {
        "client_id": row["client_id"],
        "name": row["name"],
        "format": row["format"],
        "base_url": row["base_url"],
        "api_key": api_key,
        "model": row["model"],
        "vision_model": row["vision_model"],
        "image_model": row["image_model"],
        "video_model": row["video_model"],
        "capabilities": json_load(row["capabilities"], []),
        "context_tokens": int(row["context_tokens"]),
        "max_output_tokens": int(row["max_output_tokens"]),
        "vision_context_tokens": int(row["vision_context_tokens"]),
        "vision_max_output_tokens": int(row["vision_max_output_tokens"]),
        "media_path": row["media_path"],
        "video_path": row["video_path"],
        "builtin": False,
        "updated_at": int(row["updated_at"]),
    }


def list_endpoints(conn, user_id: int) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT * FROM ai_endpoints WHERE user_id = ? ORDER BY updated_at ASC, id ASC",
        (user_id,),
    ).fetchall()
    return [_row_to_endpoint(r) for r in rows]


def get_state(conn, user_id: int) -> dict[str, Any]:
    row = conn.execute("SELECT payload, updated_at FROM ai_state WHERE user_id = ?", (user_id,)).fetchone()
    if row is None:
        return {}
    return json_load(row["payload"], {})


def config_for_user(user_id: int) -> dict[str, Any]:
    from .db import db

    with db() as conn:
        return {
            "endpoints": list_endpoints(conn, user_id),
            "state": get_state(conn, user_id),
        }


def save_config(
    user_id: int,
    items: list[dict[str, Any]],
    deleted_client_ids: list[str] | None = None,
    state: dict[str, Any] | None = None,
    updated_at: int | None = None,
) -> dict[str, int]:
    if len(items) > MAX_ENDPOINTS:
        raise ValueError(f"最多保存 {MAX_ENDPOINTS} 个模型端点")
    normalized = [normalize_endpoint(item) for item in items]
    now = int(time.time())
    stamp = int(updated_at or now)
    # App 传的是毫秒时间戳；统一归一到秒，方便后台按时间排序
    if stamp > 100_000_000_000:
        stamp //= 1000
    if state is not None and len(json_dump(state).encode("utf-8")) > 32 * 1024:
        raise ValueError("AI 偏好数据过大")
    created = updated = 0

    with tx() as conn:
        for item in normalized:
            existing = conn.execute(
                "SELECT id, updated_at, api_key_enc FROM ai_endpoints WHERE user_id = ? AND client_id = ?",
                (user_id, item["client_id"]),
            ).fetchone()
            if existing is None:
                conn.execute(
                    """INSERT INTO ai_endpoints
                       (user_id, client_id, name, format, base_url, api_key_enc, model,
                        vision_model, image_model, video_model, capabilities,
                        context_tokens, max_output_tokens, vision_context_tokens,
                        vision_max_output_tokens, media_path, video_path, created_at, updated_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        user_id, item["client_id"], item["name"], item["format"], item["base_url"],
                        seal_secret(item["api_key"]), item["model"], item["vision_model"],
                        item["image_model"], item["video_model"], json_dump(item["capabilities"]),
                        item["context_tokens"], item["max_output_tokens"], item["vision_context_tokens"],
                        item["vision_max_output_tokens"], item["media_path"], item["video_path"],
                        now, stamp,
                    ),
                )
                created += 1
            else:
                # 客户端这次没带 Key（例如只改模型名）时保留原有密文，避免误清空
                sealed = seal_secret(item["api_key"]) or (existing["api_key_enc"] or "")
                conn.execute(
                    """UPDATE ai_endpoints SET
                         name = ?, format = ?, base_url = ?, api_key_enc = ?, model = ?,
                         vision_model = ?, image_model = ?, video_model = ?, capabilities = ?,
                         context_tokens = ?, max_output_tokens = ?, vision_context_tokens = ?,
                         vision_max_output_tokens = ?, media_path = ?, video_path = ?, updated_at = ?
                       WHERE id = ?""",
                    (
                        item["name"], item["format"], item["base_url"], sealed,
                        item["model"], item["vision_model"], item["image_model"], item["video_model"],
                        json_dump(item["capabilities"]), item["context_tokens"], item["max_output_tokens"],
                        item["vision_context_tokens"], item["vision_max_output_tokens"],
                        item["media_path"], item["video_path"], stamp, existing["id"],
                    ),
                )
                updated += 1

        deleted = 0
        for client_id in deleted_client_ids or []:
            cur = conn.execute(
                "DELETE FROM ai_endpoints WHERE user_id = ? AND client_id = ?", (user_id, str(client_id)[:64])
            )
            deleted += cur.rowcount or 0

        if state is not None:
            raw = json_dump(state)
            conn.execute(
                """INSERT INTO ai_state (user_id, payload, updated_at) VALUES (?,?,?)
                   ON CONFLICT(user_id) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at""",
                (user_id, raw, stamp),
            )

    return {"created": created, "updated": updated, "deleted": deleted, "total": len(normalized)}


def clear_config(user_id: int) -> int:
    with tx() as conn:
        cur = conn.execute("DELETE FROM ai_endpoints WHERE user_id = ?", (user_id,))
        conn.execute("DELETE FROM ai_state WHERE user_id = ?", (user_id,))
        return cur.rowcount or 0
