"""网页抓取与清洗。

整条链路：入队 → 取页面 → 正文抽取/清洗 → 去重 → 落 content_items → App 增量拉取。

设计取舍：
- 只用标准库 + httpx（requirements 里已有），不引入 BeautifulSoup/Playwright，
  保证服务器上 `pip install -r requirements.txt` 就能跑；需要渲染的动态站点后续可加
  可选的 Playwright 分支。
- 抓取全部在后台线程里做，接口只负责入队和读结果，慢站点不会拖住请求。
- SSRF 防护：只允许 http/https；每一跳都校验目标 IP，默认拒绝内网/回环/云元数据段
  （生产强制；开发要抓本机需显式 CONTENT_ALLOW_PRIVATE=true）。
- 合规：抓之前查 robots.txt（带缓存），遵守 Disallow；不抓登录态、不存原始 HTML。
"""
from __future__ import annotations

import hashlib
import ipaddress
import logging
import re
import socket
import threading
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from html.parser import HTMLParser
from typing import Any
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

import httpx

from .config import settings
from .db import db, json_dump, tx

logger = logging.getLogger("myzuji.content")

# ---------- URL 规范化 / 去重 ----------

_TRACKING_PARAMS = {
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "spm", "from", "share_token", "share_source", "ref", "referrer", "fbclid", "gclid",
}
_URL_BAD_SCHEMES = {"javascript", "data", "file", "ftp", "mailto", "tel"}


def normalize_url(url: str) -> str:
    """去掉 fragment、跟踪参数与多余斜杠，输出可做唯一键的规范化 URL。"""
    raw = (url or "").strip()
    if not raw:
        return ""
    try:
        p = urlparse(raw)
    except ValueError:
        return ""
    if p.scheme.lower() not in {"http", "https"} or not p.netloc:
        return ""
    netloc = p.netloc.lower()
    if netloc.endswith(":80") and p.scheme == "http":
        netloc = netloc[:-3]
    if netloc.endswith(":443") and p.scheme == "https":
        netloc = netloc[:-4]
    query = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if k.lower() not in _TRACKING_PARAMS]
    path = re.sub(r"/{2,}", "/", p.path or "/")
    if path != "/":
        path = path.rstrip("/")
    return urlunparse((p.scheme.lower(), netloc, path, p.params, urlencode(query), ""))


def url_hash(url: str) -> str:
    return hashlib.sha256(normalize_url(url).encode("utf-8")).hexdigest()


def content_hash(text: str) -> str:
    """正文指纹：去掉空白后取 sha256，用来识别转载/重复。"""
    core = re.sub(r"\s+", "", text or "")[:8000]
    return hashlib.sha256(core.encode("utf-8")).hexdigest()


# ---------- SSRF 防护 ----------

_PRIVATE_NETS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("100.64.0.0/10"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]


def _ip_is_private(host: str) -> bool:
    try:
        infos = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
    except OSError:
        return True  # 解析不了就不抓
    for info in infos:
        addr = info[4][0]
        try:
            ip = ipaddress.ip_address(addr)
        except ValueError:
            return True
        if any(ip in net for net in _PRIVATE_NETS):
            return True
    return False


def url_is_allowed(url: str) -> tuple[bool, str]:
    normalized = normalize_url(url)
    if not normalized:
        return False, "URL 不合法（只支持 http/https）"
    if urlparse(url).scheme.lower() in _URL_BAD_SCHEMES:
        return False, "不支持的协议"
    host = urlparse(normalized).hostname or ""
    if not host:
        return False, "URL 缺少主机名"
    if not settings.content_private_allowed and _ip_is_private(host):
        return False, "禁止抓取内网 / 回环地址"
    return True, ""


# ---------- robots.txt ----------

_robots_cache: dict[str, tuple[float, list[tuple[str, bool]]]] = {}
_robots_lock = threading.Lock()
_ROBOTS_TTL = 3600


def _load_robots(host: str) -> list[tuple[str, bool]]:
    """返回 [(path 模式, 是否允许)]，只认 User-agent: *。"""
    with _robots_lock:
        cached = _robots_cache.get(host)
        if cached and time.time() - cached[0] < _ROBOTS_TTL:
            return cached[1]
    rules: list[tuple[str, bool]] = []
    try:
        scheme = "https"
        resp = httpx.get(
            f"{scheme}://{host}/robots.txt",
            timeout=6.0,
            follow_redirects=True,
            headers={"User-Agent": settings.content_user_agent},
        )
        if resp.status_code == 200 and len(resp.text) < 200_000:
            applies = False
            for line in resp.text.splitlines():
                line = line.split("#", 1)[0].strip()
                if not line:
                    continue
                key, _, value = line.partition(":")
                key, value = key.strip().lower(), value.strip()
                if key == "user-agent":
                    applies = value == "*"
                elif applies and key in {"allow", "disallow"}:
                    if value:
                        rules.append((value, key == "allow"))
    except Exception:  # noqa: BLE001 - robots 取不到就按允许处理
        rules = []
    with _robots_lock:
        _robots_cache[host] = (time.time(), rules)
    return rules


def robots_allows(url: str) -> bool:
    host = urlparse(url).hostname or ""
    path = urlparse(url).path or "/"
    rules = _load_robots(host)
    best_len, allowed = -1, True
    for pattern, is_allow in rules:
        prefix = pattern.rstrip("*")
        if path.startswith(prefix) and len(prefix) > best_len:
            best_len, allowed = len(prefix), is_allow
    return allowed


# ---------- 取页面 ----------

class FetchError(RuntimeError):
    pass


def fetch_html(url: str) -> tuple[str, str]:
    """取页面并返回 (最终 URL, HTML)。最多跟 3 跳重定向，每一跳都做 SSRF 校验。"""
    current = url
    headers = {
        "User-Agent": settings.content_user_agent,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.6",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6",
    }
    for _ in range(3):
        ok, reason = url_is_allowed(current)
        if not ok:
            raise FetchError(reason)
        if not robots_allows(current):
            raise FetchError("robots.txt 不允许抓取该路径")
        try:
            with httpx.Client(timeout=settings.content_fetch_timeout, headers=headers) as client:
                with client.stream("GET", current, follow_redirects=False) as resp:
                    if resp.status_code in {301, 302, 303, 307, 308}:
                        location = resp.headers.get("location", "")
                        if not location:
                            raise FetchError(f"HTTP {resp.status_code} 但没有 Location")
                        current = urljoin(current, location)
                        continue
                    if resp.status_code >= 400:
                        raise FetchError(f"HTTP {resp.status_code}")
                    ctype = resp.headers.get("content-type", "").lower()
                    if ctype and not any(t in ctype for t in ("text/html", "application/xhtml", "text/plain")):
                        raise FetchError(f"不支持的内容类型 {ctype[:60]}")
                    chunks: list[bytes] = []
                    total = 0
                    for chunk in resp.iter_bytes(65536):
                        total += len(chunk)
                        if total > settings.content_max_bytes:
                            raise FetchError("页面超过大小上限")
                        chunks.append(chunk)
                    body = b"".join(chunks)
                    return str(resp.url), decode_body(body, ctype)
        except httpx.HTTPError as exc:
            raise FetchError(f"网络错误 {type(exc).__name__}") from exc
    raise FetchError("重定向次数过多")


def decode_body(body: bytes, content_type: str) -> str:
    charset = ""
    match = re.search(r"charset=([\w-]+)", content_type or "", re.I)
    if match:
        charset = match.group(1)
    if not charset:
        head = body[:2048].decode("ascii", errors="ignore")
        meta = re.search(r'charset=["\']?([\w-]+)', head, re.I)
        if meta:
            charset = meta.group(1)
    for candidate in [charset, "utf-8", "gb18030"]:
        if not candidate:
            continue
        try:
            return body.decode(candidate, errors="strict")
        except (LookupError, UnicodeDecodeError):
            continue
    return body.decode("utf-8", errors="replace")


# ---------- HTML 清洗 ----------

_SKIP_TAGS = {
    "script", "style", "noscript", "template", "svg", "canvas", "iframe", "object",
    "nav", "header", "footer", "aside", "form", "button", "select", "option", "textarea",
    "input", "label", "figure", "figcaption", "video", "audio", "source",
}
_BLOCK_TAGS = {"p", "div", "section", "article", "main", "br", "li", "tr", "td", "blockquote", "pre"}
_HEADING_TAGS = {"h1", "h2", "h3", "h4"}
_SKIP_HINTS = ("comment", "sidebar", "footer", "header", "nav", "menu", "advert", "ads-",
               "related", "recommend", "share", "breadcrumb", "copyright", "cookie")


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.skip_depth = 0
        self.blocks: list[dict[str, str]] = []
        self._buf: list[str] = []
        self._buf_type = "p"
        self.title_parts: list[str] = []
        self._in_title = False
        self.first_h1 = ""
        self._in_h1 = False

    # -- 内部 --
    def _flush(self) -> None:
        text = re.sub(r"[ \t\r\f\v]+", " ", "".join(self._buf)).strip()
        self._buf.clear()
        if len(text) < 2:
            return
        self.blocks.append({"type": self._buf_type, "text": text})
        self._buf_type = "p"

    # -- HTMLParser 回调 --
    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        hint = " ".join(v or "" for k, v in attrs if k in {"class", "id"}).lower()
        if tag in _SKIP_TAGS or (hint and any(h in hint for h in _SKIP_HINTS)):
            if tag not in {"br", "img"}:
                self.skip_depth += 1
            return
        if self.skip_depth:
            return
        if tag == "title":
            self._in_title = True
        elif tag == "h1" and not self.first_h1:
            self._in_h1 = True
            self._flush()
            self._buf_type = "h1"
        elif tag in _HEADING_TAGS:
            self._flush()
            self._buf_type = tag
        elif tag in _BLOCK_TAGS:
            self._flush()
            self._buf_type = "p"

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in _SKIP_TAGS or (tag in {"br", "img"}):
            if self.skip_depth and tag not in {"br", "img"}:
                self.skip_depth = max(0, self.skip_depth - 1)
            return
        if self.skip_depth:
            return
        if tag == "title":
            self._in_title = False
        elif tag == "h1" and self._in_h1:
            self._in_h1 = False
            self._flush()
        elif tag in _BLOCK_TAGS or tag in _HEADING_TAGS:
            self._flush()

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title_parts.append(data)
            return
        if self.skip_depth:
            return
        if self._in_h1 and not self.first_h1:
            self.first_h1 = (self.first_h1 + data).strip()[:200]
        if data.strip():
            self._buf.append(data)


_META_RE = re.compile(r"<meta\b[^>]*>", re.I)
_TAG_ATTR_RE = re.compile(r'([\w:-]+)\s*=\s*("([^"]*)"|\'([^\']*)\')', re.I)


def _meta_map(html: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for tag in _META_RE.findall(html):
        attrs = {m.group(1).lower(): (m.group(3) if m.group(3) is not None else m.group(4)) or ""
                 for m in _TAG_ATTR_RE.finditer(tag)}
        key = (attrs.get("property") or attrs.get("name") or "").lower()
        if key and attrs.get("content"):
            out.setdefault(key, attrs["content"].strip())
    return out


_IMG_RE = re.compile(r"<img\b[^>]*>", re.I)
_SRC_ATTR_RE = re.compile(r'(?:data-src|data-original|src)\s*=\s*("([^"]*)"|\'([^\']*)\')', re.I)


def _extract_images(html: str, base_url: str, limit: int = 8) -> list[str]:
    urls: list[str] = []
    for tag in _IMG_RE.findall(html):
        m = _SRC_ATTR_RE.search(tag)
        if not m:
            continue
        raw = (m.group(2) if m.group(2) is not None else m.group(3)) or ""
        if not raw or raw.startswith("data:"):
            continue
        absolute = urljoin(base_url, raw)
        if absolute.startswith(("http://", "https://")) and absolute not in urls:
            urls.append(absolute)
        if len(urls) >= limit:
            break
    return urls


def _parse_datetime(value: str) -> int:
    if not value:
        return 0
    text = value.strip()
    try:
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp())
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y-%m-%d", "%Y/%m/%d"):
        try:
            return int(datetime.strptime(text[:19], fmt).replace(tzinfo=timezone.utc).timestamp())
        except ValueError:
            continue
    return 0


def _count_words(text: str) -> int:
    cjk = len(re.findall(r"[\u4e00-\u9fff]", text))
    latin = len(re.findall(r"[A-Za-z0-9]+", text))
    return cjk + latin


def clean_html(html: str, page_url: str) -> dict[str, Any]:
    """把 HTML 变成结构化正文。返回字段与 content_items 一一对应。"""
    meta = _meta_map(html)
    parser = _TextExtractor()
    try:
        parser.feed(html)
        parser.close()
        parser._flush()
    except Exception:  # noqa: BLE001 - 解析器对残缺 HTML 容错
        logger.warning("HTML 解析中断 %s", page_url)

    title = (meta.get("og:title") or meta.get("twitter:title") or "").strip()
    if not title:
        title = re.sub(r"\s+", " ", "".join(parser.title_parts)).strip()
    if not title:
        title = parser.first_h1
    title = re.sub(r"\s*[-_|—]\s*[^-_|—]{1,24}$", "", title)[:200]

    summary = (meta.get("og:description") or meta.get("description") or "").strip()
    blocks = [b for b in parser.blocks if b["text"]]
    if not summary and blocks:
        summary = blocks[0]["text"]
    summary = re.sub(r"\s+", " ", summary)[:300]

    # 去掉极短的重复块（版权行、导航残留）
    seen: set[str] = set()
    cleaned: list[dict[str, str]] = []
    for b in blocks:
        t = b["text"]
        if len(t) < 4 and b["type"] == "p":
            continue
        key = t[:80]
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(b)

    body_text = "\n".join(b["text"] for b in cleaned)[:20000]
    images = _extract_images(html, page_url)
    og_image = meta.get("og:image") or meta.get("twitter:image")
    if og_image:
        absolute = urljoin(page_url, og_image)
        if absolute.startswith(("http://", "https://")) and absolute not in images:
            images.insert(0, absolute)

    published = _parse_datetime(
        meta.get("article:published_time") or meta.get("publishdate") or meta.get("date") or ""
    )
    author = (meta.get("article:author") or meta.get("author") or "").strip()[:80]
    lang = (meta.get("og:locale") or "").strip()[:10]
    if not lang:
        m = re.search(r'<html[^>]+lang=["\']([\w-]+)', html[:4000], re.I)
        lang = m.group(1)[:10] if m else ""

    return {
        "title": title or (page_url[:120]),
        "summary": summary,
        "body_text": body_text,
        "blocks": cleaned[:200],
        "images": images[:8],
        "author": author,
        "published_at": published,
        "lang": "zh" if re.search(r"[\u4e00-\u9fff]", body_text) else (lang or ""),
        "word_count": _count_words(body_text),
        "content_hash": content_hash(body_text),
        "final_url": page_url,
    }


# ---------- 列表页 / RSS 的链接发现 ----------

_LINK_RE = re.compile(r'<a\b[^>]*href\s*=\s*("([^"]*)"|\'([^\']*)\')[^>]*>(.*?)</a>', re.I | re.S)
_STRIP_TAGS_RE = re.compile(r"<[^>]+>")


def discover_links(html: str, list_url: str, host: str, url_prefix: str, limit: int = 50) -> list[str]:
    found: list[str] = []
    for match in _LINK_RE.finditer(html):
        raw = match.group(2) if match.group(2) is not None else match.group(3)
        text = _STRIP_TAGS_RE.sub("", match.group(4) or "").strip()
        if not raw or raw.startswith(("#", "javascript:", "mailto:")):
            continue
        absolute = urljoin(list_url, raw.strip())
        normalized = normalize_url(absolute)
        if not normalized:
            continue
        if host and urlparse(normalized).hostname != host:
            continue
        if url_prefix and not normalized.startswith(url_prefix):
            continue
        if not text:
            continue
        if normalized in found:
            continue
        found.append(normalized)
        if len(found) >= limit:
            break
    return found


def parse_rss(xml_text: str, limit: int = 50) -> list[str]:
    links: list[str] = []
    try:
        root = ET.fromstring(xml_text.strip())
    except ET.ParseError:
        return links
    for node in root.iter():
        tag = node.tag.split("}")[-1].lower()
        if tag not in {"item", "entry"}:
            continue
        link = ""
        for child in node:
            ctag = child.tag.split("}")[-1].lower()
            if ctag == "link" and (child.text or "").strip():
                link = (child.text or "").strip()
                break
            if ctag == "link":
                link = child.attrib.get("href", "").strip()
                if link:
                    break
        if link:
            normalized = normalize_url(link)
            if normalized and normalized not in links:
                links.append(normalized)
        if len(links) >= limit:
            break
    return links


def parse_sitemap(xml_text: str, limit: int = 50) -> list[str]:
    links: list[str] = []
    try:
        root = ET.fromstring(xml_text.strip())
    except ET.ParseError:
        return links
    for node in root.iter():
        if node.tag.split("}")[-1].lower() != "loc":
            continue
        normalized = normalize_url((node.text or "").strip())
        if normalized and not normalized.endswith(".xml") and normalized not in links:
            links.append(normalized)
        if len(links) >= limit:
            break
    return links


# ---------- 入库 ----------

def save_item(source_id: int | None, url: str, cleaned: dict[str, Any], category: str = "") -> int | None:
    """写一条清洗后的内容；URL 已存在或正文重复时返回 None（去重）。"""
    now = int(time.time())
    normalized = normalize_url(url) or url
    uhash = url_hash(normalized)
    chash = cleaned.get("content_hash", "")
    with tx() as conn:
        existing = conn.execute("SELECT id FROM content_items WHERE url_hash = ?", (uhash,)).fetchone()
        if existing:
            conn.execute(
                "UPDATE content_items SET title = ?, summary = ?, status = 1, updated_at = ? WHERE id = ?",
                ((cleaned.get("title") or "")[:200], (cleaned.get("summary") or "")[:300], now, existing["id"]),
            )
            return None
        if chash:
            dup = conn.execute(
                "SELECT id FROM content_items WHERE content_hash = ? AND status = 1 LIMIT 1", (chash,)
            ).fetchone()
            if dup:
                logger.info("正文重复，跳过 %s", normalized)
                return None
        cur = conn.execute(
            """INSERT INTO content_items
               (source_id, url, canonical_url, url_hash, content_hash, host, title, summary, body_text,
                blocks, images, author, category, lang, word_count, published_at, fetched_at,
                status, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)""",
            (
                source_id, normalized, normalized, uhash, chash,
                urlparse(normalized).hostname or "",
                (cleaned.get("title") or "")[:200],
                (cleaned.get("summary") or "")[:300],
                (cleaned.get("body_text") or "")[:20000],
                json_dump(cleaned.get("blocks") or []),
                json_dump(cleaned.get("images") or []),
                (cleaned.get("author") or "")[:80],
                (category or "")[:40],
                (cleaned.get("lang") or "")[:10],
                int(cleaned.get("word_count") or 0),
                int(cleaned.get("published_at") or 0),
                now, now, now,
            ),
        )
        return int(cur.lastrowid)


def fetch_and_store(url: str, source_id: int | None = None, category: str = "") -> int | None:
    final_url, html = fetch_html(url)
    cleaned = clean_html(html, final_url)
    if len(cleaned.get("body_text") or "") < settings.content_min_chars:
        raise FetchError(f"正文过短（{len(cleaned.get('body_text') or '')} 字符），按模板页/失败处理")
    return save_item(source_id, final_url, cleaned, category)


# ---------- 任务队列 ----------

def enqueue_url(url: str, category: str = "", source_id: int | None = None) -> int:
    now = int(time.time())
    with tx() as conn:
        cur = conn.execute(
            """INSERT INTO content_jobs (kind, source_id, url, status, attempts, created_at)
               VALUES ('url', ?, ?, 'queued', 0, ?)""",
            (source_id, normalize_url(url) or url, now),
        )
        return int(cur.lastrowid)


def enqueue_source(source_id: int) -> int:
    now = int(time.time())
    with tx() as conn:
        cur = conn.execute(
            """INSERT INTO content_jobs (kind, source_id, url, status, attempts, created_at)
               VALUES ('source', ?, '', 'queued', 0, ?)""",
            (source_id, now),
        )
        return int(cur.lastrowid)


def claim_job() -> dict[str, Any] | None:
    now = int(time.time())
    with tx() as conn:
        row = conn.execute(
            """SELECT * FROM content_jobs
               WHERE status = 'queued' AND next_attempt_at <= ?
               ORDER BY id LIMIT 1""",
            (now,),
        ).fetchone()
        if row is None:
            return None
        conn.execute(
            "UPDATE content_jobs SET status = 'running', attempts = attempts + 1, started_at = ? WHERE id = ?",
            (now, row["id"]),
        )
        return dict(row)


def finish_job(job_id: int, ok: bool, created: int = 0, error: str = "", attempts: int = 1) -> None:
    now = int(time.time())
    with tx() as conn:
        if ok:
            conn.execute(
                """UPDATE content_jobs SET status = 'done', created_items = ?, error = '',
                   finished_at = ? WHERE id = ?""",
                (created, now, job_id),
            )
            return
        if attempts < 3:
            backoff = min(600, 30 * (2 ** (attempts - 1)))
            conn.execute(
                """UPDATE content_jobs SET status = 'queued', error = ?, next_attempt_at = ?,
                   finished_at = ? WHERE id = ?""",
                (error[:300], now + backoff, now, job_id),
            )
        else:
            conn.execute(
                """UPDATE content_jobs SET status = 'failed', error = ?, finished_at = ?
                   WHERE id = ?""",
                (error[:300], now, job_id),
            )


def run_job(job: dict[str, Any]) -> tuple[int, str]:
    """执行一条任务，返回 (新增条数, 错误信息)。"""
    kind = job.get("kind") or "url"
    if kind == "url":
        try:
            created = 1 if fetch_and_store(job["url"], job.get("source_id"), "") else 0
            return created, ""
        except FetchError as exc:
            return 0, str(exc)
        except Exception as exc:  # noqa: BLE001
            logger.exception("抓取失败 %s", job.get("url"))
            return 0, f"内部错误 {type(exc).__name__}"

    source_id = int(job.get("source_id") or 0)
    with db() as conn:
        source = conn.execute("SELECT * FROM content_sources WHERE id = ?", (source_id,)).fetchone()
    if source is None:
        return 0, "内容源不存在"
    try:
        final_url, page = fetch_html(source["list_url"])
    except FetchError as exc:
        return 0, f"列表页抓取失败：{exc}"
    except Exception as exc:  # noqa: BLE001
        logger.exception("列表页抓取失败 %s", source["list_url"])
        return 0, f"列表页内部错误 {type(exc).__name__}"

    host = source["host"] or (urlparse(final_url).hostname or "")
    if source["kind"] == "rss":
        links = parse_rss(page, limit=source["max_items"] * 2)
    elif source["kind"] == "sitemap":
        links = parse_sitemap(page, limit=source["max_items"] * 2)
    else:
        links = discover_links(page, final_url, host, source["url_prefix"] or "", limit=source["max_items"] * 3)

    created = 0
    errors = 0
    for link in links:
        if created >= int(source["max_items"] or settings.content_max_items_per_run):
            break
        try:
            if fetch_and_store(link, source_id, source["default_category"] or ""):
                created += 1
        except FetchError as exc:
            errors += 1
            logger.info("跳过 %s：%s", link, exc)
        except Exception:  # noqa: BLE001
            errors += 1
            logger.exception("抓取失败 %s", link)

    with tx() as conn:
        conn.execute(
            "UPDATE content_sources SET last_run_at = ?, last_status = ?, updated_at = ? WHERE id = ?",
            (int(time.time()), f"ok {created} 新增 / {errors} 跳过", int(time.time()), source_id),
        )
    return created, ""


class ContentWorker:
    """进程内后台 worker：串行消费抓取任务 + 到点自动跑内容源。

    不用 Celery 的原因：单机单进程部署，SQLite 队列 + 一个线程足够；
    真要横向扩容，把 claim_job/run_job 换成独立进程即可，表结构不用动。
    """

    def __init__(self) -> None:
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if not settings.content_enabled:
            logger.info("内容抓取 worker 已关闭（CONTENT_ENABLED=false）")
            return
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, name="content-worker", daemon=True)
        self._thread.start()
        logger.info("内容抓取 worker 已启动，轮询 %ss", settings.content_worker_seconds)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _recover(self) -> None:
        """进程重启后，把「卡在 running」的任务放回队列。"""
        with tx() as conn:
            conn.execute(
                "UPDATE content_jobs SET status = 'queued' WHERE status = 'running'"
            )

    def _scheduler_tick(self) -> None:
        now = int(time.time())
        with db() as conn:
            due = conn.execute(
                """SELECT id, last_run_at, interval_minutes FROM content_sources
                   WHERE enabled = 1 AND (last_run_at + interval_minutes * 60) <= ?""",
                (now,),
            ).fetchall()
        if not due:
            return
        with db() as conn:
            for row in due:
                pending = conn.execute(
                    "SELECT 1 FROM content_jobs WHERE source_id = ? AND status IN ('queued','running') LIMIT 1",
                    (row["id"],),
                ).fetchone()
                if pending is None:
                    enqueue_source(int(row["id"]))

    def _loop(self) -> None:
        self._recover()
        last_schedule = 0.0
        while not self._stop.is_set():
            try:
                if time.time() - last_schedule > 60:
                    last_schedule = time.time()
                    self._scheduler_tick()
                job = claim_job()
                if job is None:
                    self._stop.wait(settings.content_worker_seconds)
                    continue
                created, error = run_job(job)
                finish_job(int(job["id"]), error == "", created, error, int(job["attempts"]) + 1)
            except Exception:  # noqa: BLE001 - worker 不能因为单次异常退出
                logger.exception("内容 worker 循环异常")
                self._stop.wait(settings.content_worker_seconds)


worker = ContentWorker()
