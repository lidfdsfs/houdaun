"""鉴权依赖、客户端 IP、审计日志、限流依赖。"""
from __future__ import annotations

import time
from typing import Any, Callable

from fastapi import Header, HTTPException, Request

from .config import settings
from .db import db
from .security import AuthError, decode_token, limiter


def client_ip(request: Request) -> str:
    if settings.trust_proxy_headers:
        forwarded = request.headers.get("x-forwarded-for", "")
        if forwarded:
            return forwarded.split(",")[0].strip()
        real = request.headers.get("x-real-ip", "")
        if real:
            return real.strip()
    return request.client.host if request.client else "unknown"


def _bearer(authorization: str | None) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="未登录", headers={"WWW-Authenticate": "Bearer"})
    token = authorization[7:].strip()
    if not token:
        raise HTTPException(status_code=401, detail="未登录", headers={"WWW-Authenticate": "Bearer"})
    return token


def _check_revoked(jti: str) -> bool:
    with db() as conn:
        row = conn.execute("SELECT jti FROM revoked_tokens WHERE jti = ?", (jti,)).fetchone()
        return row is not None


def require_user(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    token = _bearer(authorization)
    try:
        payload = decode_token(token, "user")
    except AuthError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message)
    if _check_revoked(payload.get("jti", "")):
        raise HTTPException(status_code=401, detail="登录已失效，请重新登录")

    try:
        uid = int(payload["sub"])
    except (KeyError, TypeError, ValueError):
        raise HTTPException(status_code=401, detail="登录凭证无效")

    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="账号不存在")
    if int(row["status"]) != 1:
        raise HTTPException(status_code=403, detail="账号已被停用，请联系管理员")
    if int(payload.get("ver", 0)) != int(row["token_version"]):
        raise HTTPException(status_code=401, detail="登录已失效，请重新登录")
    return dict(row)


def optional_user(authorization: str | None = Header(default=None)) -> dict[str, Any] | None:
    """公开接口里识别「已登录用户」用；没带 token 就返回 None，不报 401。"""
    if not authorization:
        return None
    try:
        return require_user(authorization)
    except HTTPException:
        return None


def require_admin(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    token = _bearer(authorization)
    try:
        payload = decode_token(token, "admin")
    except AuthError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message)
    if _check_revoked(payload.get("jti", "")):
        raise HTTPException(status_code=401, detail="后台登录已失效，请重新登录")
    return {"name": payload.get("sub", "admin"), "jti": payload.get("jti"), "exp": payload.get("exp", 0)}


def audit(actor: str, action: str, target: str = "", detail: str = "", ip: str = "") -> None:
    with db() as conn:
        conn.execute(
            "INSERT INTO audit_logs (actor, action, target, detail, ip, created_at) VALUES (?,?,?,?,?,?)",
            (actor[:80], action[:80], target[:120], detail[:500], ip[:60], int(time.time())),
        )


def rate_limit(bucket: str, limit: int) -> Callable[[Request], None]:
    """生成一个限流依赖。返回的依赖用请求 IP 作为 key。"""

    def _dependency(request: Request) -> None:
        allowed, retry_after = limiter.check(bucket, client_ip(request), limit, 60)
        if not allowed:
            raise HTTPException(
                status_code=429,
                detail=f"请求过于频繁，请 {retry_after} 秒后重试",
                headers={"Retry-After": str(retry_after)},
            )

    return _dependency
