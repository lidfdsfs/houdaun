(function () {
  "use strict";

  const TOKEN_KEY = "myzuji_admin_token";
  const PAGE_SIZE = 30;

  const state = {
    view: "overview",
    page: 0,
    q: "",
    extra: "",
    admin: null,
    system: null,
  };

  const VIEW_META = {
    overview: { title: "概览", sub: "服务运行状态与关键数据" },
    users: { title: "用户", sub: "账号状态、登录情况与云端数据量" },
    userdata: { title: "用户数据", sub: "按用户查看磁盘文件夹：足迹图片、音乐收藏、评论、隐私空间" },
    content: { title: "内容中心", sub: "网页抓取源、抓取队列与清洗后的内容条目" },
    guides: { title: "攻略", sub: "内容审核、推荐位与下线管理" },
    comments: { title: "评论", sub: "用户评论与清理" },
    footprints: { title: "云端足迹", sub: "App 同步上来的足迹记录" },
    media: { title: "媒体文件", sub: "照片与视频占用、清理" },
    audit: { title: "审计日志", sub: "后台操作与登录事件" },
    system: { title: "系统配置", sub: "运行参数（不含密钥）与验证码发信记录" },
  };

  // ---------------- 基础工具 ----------------

  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }

  function esc(value) {
    return String(value === null || value === undefined ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function bytes(n) {
    n = Number(n || 0);
    if (n < 1024) return n + " B";
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " KB";
    if (n < 1024 * 1024 * 1024) return (n / (1024 * 1024)).toFixed(1) + " MB";
    return (n / (1024 * 1024 * 1024)).toFixed(2) + " GB";
  }

  function toast(message, bad) {
    const el = qs("#toast");
    el.textContent = message;
    el.className = "toast" + (bad ? " bad" : "");
    el.hidden = false;
    clearTimeout(toast._timer);
    toast._timer = setTimeout(function () { el.hidden = true; }, 2600);
  }

  function token() {
    return localStorage.getItem(TOKEN_KEY) || "";
  }

  async function api(path, options) {
    const opts = options || {};
    const headers = { Accept: "application/json" };
    if (opts.auth !== false) {
      const t = token();
      if (t) headers.Authorization = "Bearer " + t;
    }
    let body;
    if (opts.body !== undefined && opts.body !== null) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(opts.body);
    }
    const res = await fetch(path, { method: opts.method || "GET", headers: headers, body: body });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (res.status === 401 && opts.auth !== false) {
      signOut(true);
      throw new Error("登录已失效，请重新登录");
    }
    if (!res.ok) {
      const detail = data && data.detail;
      throw new Error(typeof detail === "string" ? detail : ("请求失败（HTTP " + res.status + "）"));
    }
    return data;
  }

  // ---------------- 登录态 ----------------

  function showLogin(message) {
    qs("#login-view").hidden = false;
    qs("#app-view").hidden = true;
    const err = qs("#login-error");
    if (message) {
      err.textContent = message;
      err.hidden = false;
    } else {
      err.hidden = true;
    }
  }

  function showApp() {
    qs("#login-view").hidden = true;
    qs("#app-view").hidden = false;
  }

  function signOut(silent) {
    localStorage.removeItem(TOKEN_KEY);
    state.admin = null;
    showLogin(silent ? "登录已失效，请重新登录" : "");
    if (!silent) toast("已退出登录");
  }

  qs("#login-form").addEventListener("submit", async function (ev) {
    ev.preventDefault();
    const btn = qs("#login-btn");
    const err = qs("#login-error");
    btn.disabled = true;
    btn.textContent = "登录中…";
    err.hidden = true;
    try {
      const data = await api("/admin/api/login", {
        method: "POST",
        auth: false,
        body: {
          username: qs("#login-username").value.trim(),
          password: qs("#login-password").value,
        },
      });
      localStorage.setItem(TOKEN_KEY, data.access_token);
      state.admin = data.admin;
      qs("#admin-chip").textContent = data.admin && data.admin.name ? data.admin.name : "管理员";
      await boot();
      toast("登录成功");
    } catch (e) {
      err.textContent = e.message;
      err.hidden = false;
    } finally {
      btn.disabled = false;
      btn.textContent = "登录";
    }
  });

  qs("#logout-btn").addEventListener("click", async function () {
    try { await api("/admin/api/logout", { method: "POST" }); } catch (e) { /* 忽略 */ }
    signOut(false);
  });

  // ---------------- 视图框架 ----------------

  function setView(view) {
    state.view = view;
    state.page = 0;
    state.q = "";
    state.extra = "";
    const meta = VIEW_META[view];
    qs("#view-title").textContent = meta.title;
    qs("#view-sub").textContent = meta.sub;
    Array.prototype.forEach.call(qs("#nav").querySelectorAll("button"), function (btn) {
      btn.classList.toggle("active", btn.dataset.view === view);
    });
    render();
  }

  qs("#nav").addEventListener("click", function (ev) {
    const btn = ev.target.closest("button[data-view]");
    if (btn) setView(btn.dataset.view);
  });

  qs("#refresh-btn").addEventListener("click", function () { render(); });

  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Enter" && ev.target && ev.target.id === "search-input") {
      state.q = ev.target.value.trim();
      state.page = 0;
      render();
    }
  });

  async function render() {
    const root = qs("#view-root");
    const renderers = {
      overview: renderOverview,
      users: renderUsers,
      userdata: renderUserData,
      content: renderContent,
      guides: renderGuides,
      comments: renderComments,
      footprints: renderFootprints,
      media: renderMedia,
      audit: renderAudit,
      system: renderSystem,
    };
    root.innerHTML = '<div class="card"><div class="empty">加载中…</div></div>';
    try {
      await renderers[state.view](root);
    } catch (e) {
      root.innerHTML = '<div class="card"><div class="empty">' + esc(e.message) + "</div></div>";
    }
  }

  function pager(total, page, onPrev, onNext) {
    const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    return (
      '<div class="pager"><span>共 ' + total + " 条 · 第 " + (page + 1) + " / " + pages + " 页</span>" +
      '<button type="button" class="btn btn-ghost btn-sm" data-act="prev"' + (page <= 0 ? " disabled" : "") + ">上一页</button>" +
      '<button type="button" class="btn btn-ghost btn-sm" data-act="next"' + (page + 1 >= pages ? " disabled" : "") + ">下一页</button></div>"
    );
  }

  function toolbar(placeholder, extraOptions) {
    let extra = "";
    if (extraOptions && extraOptions.length) {
      extra = '<select id="filter-select">' + extraOptions.map(function (o) {
        return '<option value="' + esc(o.value) + '"' + (state.extra === o.value ? " selected" : "") + ">" + esc(o.label) + "</option>";
      }).join("") + "</select>";
    }
    return (
      '<div class="toolbar">' +
      '<input id="search-input" type="search" placeholder="' + esc(placeholder) + '" value="' + esc(state.q) + '">' +
      extra +
      '<button type="button" class="btn btn-ghost btn-sm" data-act="search">搜索</button>' +
      '<div class="spacer"></div>' +
      "</div>"
    );
  }

  // ---------------- 概览 ----------------

  async function renderOverview(root) {
    const d = await api("/admin/api/overview");
    const bars = d.signup_series.length
      ? d.signup_series
      : [{ date: "-", count: 0 }];
    const maxCount = Math.max.apply(null, bars.map(function (b) { return b.count; }).concat([1]));
    const barHtml = bars.map(function (b) {
      const h = Math.max(3, Math.round((b.count / maxCount) * 82));
      return '<div class="bar"><i style="height:' + h + 'px"></i><span>' + esc(b.date.slice(5)) + "</span></div>";
    }).join("");

    const recent = (d.recent_audit || []).map(function (a) {
      return '<div class="row"><span class="t">' + esc(new Date(a.created_at * 1000).toLocaleString("zh-CN", { hour12: false })) +
        "</span><span>" + esc(a.actor) + " · " + esc(a.action) + " " + esc(a.target) + "</span></div>";
    }).join("") || '<div class="empty">暂无操作记录</div>';

    root.innerHTML =
      '<div class="grid grid-4">' +
        statCard("用户总数", d.users.total, "正常 " + d.users.active + " · 封禁 " + d.users.banned, "7 日新增 " + d.users.new_7d) +
        statCard("攻略", d.guides.total, "推荐 " + d.guides.featured + " · 隐藏 " + d.guides.hidden, "") +
        statCard("评论", d.comments.total, "全部评论数", "") +
        statCard("媒体占用", bytes(d.sync.media_bytes), d.sync.media_count + " 个文件", "数据库 " + bytes(d.storage.db_bytes)) +
      "</div>" +
      '<div class="grid grid-2" style="margin-top:14px">' +
        '<div class="card"><div class="card-title"><h3>近 7 天注册</h3></div><div class="bars">' + barHtml + "</div></div>" +
        '<div class="card"><div class="card-title"><h3>云端同步数据</h3></div>' +
          '<div class="kv"><dt>足迹</dt><dd>' + d.sync.footprints + " 条</dd>" +
          "<dt>行程</dt><dd>" + d.sync.routes + " 条</dd>" +
          "<dt>设置快照</dt><dd>" + d.sync.settings_users + " 个用户</dd>" +
          "</div></div>" +
      "</div>" +
      '<div class="card" style="margin-top:14px"><div class="card-title"><h3>最近操作</h3></div><div class="list">' + recent + "</div></div>";
  }

  function statCard(label, value, sub, extra) {
    return '<div class="card stat"><div class="label">' + esc(label) + '</div><div class="value">' + esc(value) +
      '</div><div class="sub">' + esc(sub) + (extra ? " · " + esc(extra) : "") + "</div></div>";
  }

  // ---------------- 用户数据 ----------------

  const UD_SECTIONS = [
    { key: "footprints", label: "足迹" },
    { key: "music", label: "音乐收藏" },
    { key: "comments", label: "评论" },
    { key: "plans", label: "计划" },
    { key: "vault", label: "隐私空间" },
    { key: "files", label: "文件" },
    { key: "archive", label: "原始档案" },
  ];

  function udTabs(active) {
    return UD_SECTIONS.map(function (s) {
      return '<button type="button" class="btn btn-ghost btn-sm ud-tab' + (s.key === active ? " active" : "") +
        '" data-ud="' + s.key + '">' + esc(s.label) + "</button>";
    }).join("");
  }

  async function renderUserData(root) {
    const list = await api("/admin/api/users?skip=0&limit=100");
    if (!list.items.length) {
      root.innerHTML = '<div class="card"><div class="empty">还没有用户</div></div>';
      return;
    }
    const has = list.items.some(function (u) { return u.id === state.userId; });
    state.userId = has ? state.userId : list.items[0].id;
    state.section = state.section || "footprints";
    const d = await api("/admin/api/users/" + state.userId + "/data");

    const opts = list.items.map(function (u) {
      return '<option value="' + u.id + '"' + (u.id === state.userId ? " selected" : "") + ">" +
        esc(u.username) + " · " + esc(u.nickname) + "</option>";
    }).join("");

    const dirs = Object.keys(d.folder.dirs || {}).map(function (k) {
      return esc(k) + " " + d.folder.dirs[k].files + " 个 / " + bytes(d.folder.dirs[k].bytes);
    }).join("；") || "空";

    const cols = d.collections || [];
    const music = (cols.filter(function (c) { return c.kind === "music"; })[0] || {}).count || 0;
    const comments = (cols.filter(function (c) { return c.kind === "comments"; })[0] || {}).count || 0;
    const plans = (cols.filter(function (c) { return c.kind === "plans"; })[0] || {}).count || 0;

    root.innerHTML =
      '<div class="card"><div class="toolbar">' +
        '<select id="ud-user">' + opts + "</select>" +
        '<div class="spacer"></div>' +
        '<button type="button" class="btn btn-ghost btn-sm" data-act="ud-export">导出文件夹 zip</button>' +
      "</div>" +
        '<div class="kv"><dt>账号</dt><dd>' + esc(d.user.username) + ' <span class="muted">' + esc(d.user.nickname) + "</span></dd>" +
        '<dt>磁盘文件夹</dt><dd class="mono">storage/' + esc(d.folder.folder) + "</dd>" +
        "<dt>占用</dt><dd>" + bytes(d.folder.total_bytes) + " · " + d.folder.total_files + " 个文件</dd>" +
        "<dt>子目录</dt><dd>" + dirs + "</dd>" +
        "<dt>档案</dt><dd>" + (d.archive.available ? ("已上传 · " + bytes(d.archive.bytes) + " · " + new Date(d.archive.created_at * 1000).toLocaleString("zh-CN", { hour12: false })) : "尚未上传") + "</dd>" +
        "</div></div>" +
      '<div class="grid grid-4" style="margin-top:14px">' +
        statCard("足迹", d.counts.footprints, "云端同步条数", "") +
        statCard("音乐收藏", music, "收藏条目数", "") +
        statCard("评论", comments, "本地评论条数", "") +
        statCard("隐私空间", d.counts.vault_files, "密文块 · " + bytes(d.counts.vault_bytes), "计划 " + plans + " 条") +
      "</div>" +
      '<div class="card" style="margin-top:14px"><div class="tabs" id="ud-tabs">' + udTabs(state.section) +
        '</div><div id="ud-content"><div class="empty">加载中…</div></div></div>';

    qs("#ud-user").addEventListener("change", function (ev) {
      state.userId = Number(ev.target.value);
      render();
    });
    qs("#ud-tabs").addEventListener("click", function (ev) {
      const b = ev.target.closest("button[data-ud]");
      if (!b) return;
      state.section = b.dataset.ud;
      Array.prototype.forEach.call(qs("#ud-tabs").querySelectorAll("button"), function (x) {
        x.classList.toggle("active", x === b);
      });
      renderUDSection(state.userId, state.section);
    });
    const exp = qs('[data-act="ud-export"]');
    if (exp) {
      exp.addEventListener("click", async function () {
        try {
          const res = await fetch("/admin/api/users/" + state.userId + "/export", {
            headers: { Authorization: "Bearer " + token() },
          });
          if (!res.ok) throw new Error("导出失败（HTTP " + res.status + "）");
          const blob = await res.blob();
          const a = document.createElement("a");
          a.href = URL.createObjectURL(blob);
          a.download = "user-" + state.userId + "-data.zip";
          document.body.appendChild(a);
          a.click();
          a.remove();
          URL.revokeObjectURL(a.href);
          toast("已开始下载");
        } catch (e) {
          toast(e.message, true);
        }
      });
    }

    await renderUDSection(state.userId, state.section);
  }

  async function renderUDSection(userId, section) {
    const box = qs("#ud-content");
    if (!box) return;
    box.innerHTML = '<div class="empty">加载中…</div>';
    try {
      if (section === "files") {
        const f = await api("/admin/api/users/" + userId + "/files");
        const rows = (f.files || []).map(function (x) {
          return "<tr><td class=\"mono\">" + esc(x.path) + "</td><td>" + bytes(x.bytes) + "</td><td>" +
            new Date(x.updated_at * 1000).toLocaleString("zh-CN", { hour12: false }) + "</td><td>" +
            (x.url ? '<a href="' + esc(x.url) + '" target="_blank" rel="noopener">打开</a>' : "—") + "</td></tr>";
        }).join("") || '<tr><td colspan="4" class="empty">这个用户的文件夹还是空的</td></tr>';
        box.innerHTML = '<table><thead><tr><th>路径</th><th>大小</th><th>更新时间</th><th>操作</th></thead><tbody>' + rows + "</tbody></table>";
        return;
      }
      if (section === "archive") {
        const a = await api("/admin/api/users/" + userId + "/section/archive");
        box.innerHTML = a.available
          ? '<div class="muted" style="margin-bottom:8px">users/' + userId + '/data/archive.json（最新一次全量档案）</div><pre class="mono" style="max-height:520px;overflow:auto;white-space:pre-wrap">' + esc(JSON.stringify(a.data, null, 2).slice(0, 40000)) + "</pre>"
          : '<div class="empty">该用户还没上传全量档案</div>';
        return;
      }
      if (section === "vault") {
        const v = await api("/admin/api/users/" + userId + "/vault");
        const note = '<div class="muted" style="margin-bottom:10px">' + esc(v.note) + "（共 " + v.total + " 条）</div>";
        const rows = (v.items || []).map(function (x) {
          return "<tr><td>" + esc(x.name || x.item_id) + "</td><td>" + esc(x.kind) + "</td><td>" + bytes(x.bytes) + "</td><td class=\"mono\">" +
            esc(x.sha256.slice(0, 16)) + "…</td><td>" + new Date(x.created_at * 1000).toLocaleString("zh-CN", { hour12: false }) +
            '</td><td><a href="' + esc(x.url) + '" target="_blank" rel="noopener">下载密文</a></td></tr>';
        }).join("") || '<tr><td colspan="6" class="empty">还没有上传隐私空间内容</td></tr>';
        box.innerHTML = note + "<table><thead><tr><th>名称</th><th>类型</th><th>大小</th><th>sha256</th><th>上传时间</th><th>操作</th></thead><tbody>" + rows + "</tbody></table>";
        return;
      }

      const sec = await api("/admin/api/users/" + userId + "/section/" + section);
      if (!sec.available) {
        box.innerHTML = '<div class="empty">该分区还没有数据</div>';
        return;
      }
      box.innerHTML = udRenderData(section, sec.data);
    } catch (e) {
      box.innerHTML = '<div class="empty">' + esc(e.message) + "</div>";
    }
  }

  function udRenderData(section, data) {
    if (section === "footprints" && Array.isArray(data)) {
      const items = data.map(function (fp) {
        const photos = (fp.photos || []).filter(function (p) { return typeof p === "string" && p.indexOf("/uploads/") === 0; });
        const imgs = photos.slice(0, 6).map(function (p) {
          return '<img class="thumb" src="' + esc(p) + '" alt="">';
        }).join("");
        return '<div class="ud-fp"><div class="t"><b>' + esc(fp.name || fp.city || "未命名足迹") + "</b> " +
          '<span class="muted">' + esc(fp.city || "") + " · " + esc(fp.date || "") + "</span></div>" +
          (fp.note ? '<div class="muted">' + esc(String(fp.note).slice(0, 120)) + "</div>" : "") +
          (imgs ? '<div class="thumbs">' + imgs + "</div>" : "") + "</div>";
      }).join("");
      return '<div class="ud-list">' + (items || '<div class="empty">没有足迹</div>') + "</div>";
    }
    if (section === "music" && data && Array.isArray(data.favorites)) {
      const rows = data.favorites.map(function (s, i) {
        return "<tr><td>" + (i + 1) + "</td><td>" + esc(s.title || s.name || s.id) + "</td><td>" + esc(s.artist || "—") + "</td><td>" + esc(s.album || "—") + "</td></tr>";
      }).join("") || '<tr><td colspan="4" class="empty">还没有收藏歌曲</td></tr>';
      return "<table><thead><tr><th>#</th><th>歌名</th><th>歌手</th><th>专辑</th></tr></thead><tbody>" + rows + "</tbody></table>" +
        '<div class="muted" style="margin-top:8px">最近播放 ' + ((data.recent || []).length) + " 首 · 播放统计 " + Object.keys(data.play_counts || {}).length + " 首</div>";
    }
    if (Array.isArray(data)) {
      const text = data.map(function (x, i) {
        return (i + 1) + ". " + (x.content || x.title || x.name || JSON.stringify(x).slice(0, 80));
      }).join("<br>");
      return '<div class="ud-json">' + esc(text).replace(/&lt;br&gt;/g, "<br>") + "</div>";
    }
    return '<pre class="mono" style="max-height:520px;overflow:auto;white-space:pre-wrap">' + esc(JSON.stringify(data, null, 2).slice(0, 40000)) + "</pre>";
  }



  async function renderUsers(root) {
    const status = state.extra === "ban" ? "0" : (state.extra === "ok" ? "1" : "");
    let url = "/admin/api/users?skip=" + state.page * PAGE_SIZE + "&limit=" + PAGE_SIZE + "&q=" + encodeURIComponent(state.q);
    if (status) url += "&status=" + status;
    const d = await api(url);
    const rows = d.items.map(function (u) {
      const badge = u.status === 1
        ? '<span class="badge badge-ok">正常</span>'
        : '<span class="badge badge-danger">已封禁</span>';
      return "<tr>" +
        '<td><span class="avatar">' + esc((u.nickname || "?").slice(0, 1)) + "</span><strong>" + esc(u.nickname) +
          '</strong><div class="muted mono" style="font-size:11.5px">@' + esc(u.username) + " · #" + u.id + "</div></td>" +
        "<td>" + badge + (u.note ? '<div class="muted" style="font-size:11px;margin-top:4px">' + esc(u.note) + "</div>" : "") + "</td>" +
        "<td>" + u.footprint_count + " 足迹 / " + u.guides + " 攻略</td>" +
        '<td class="muted">注册 ' + esc(u.created_at) + "<br>登录 " + esc(u.last_login_at || "-") + "</td>" +
        '<td class="actions">' +
          (u.status === 1
            ? '<button type="button" class="btn btn-danger btn-sm" data-act="user-ban" data-id="' + u.id + '">封禁</button>'
            : '<button type="button" class="btn btn-ghost btn-sm" data-act="user-unban" data-id="' + u.id + '">解封</button>') +
          '<button type="button" class="btn btn-ghost btn-sm" data-act="user-reset" data-id="' + u.id + '" data-account="' + esc(u.username) + '">重置</button>' +
          '<button type="button" class="btn btn-ghost btn-sm" data-act="user-note" data-id="' + u.id + '">备注</button>' +
          '<button type="button" class="btn btn-danger btn-sm" data-act="user-delete" data-id="' + u.id + '" data-account="' + esc(u.username) + '">删除</button>' +
        "</td></tr>";
    }).join("") || '<tr><td colspan="5"><div class="empty">没有匹配的用户</div></td></tr>';

    root.innerHTML = '<div class="card">' +
      toolbar("搜索账号或昵称", [
        { value: "", label: "全部状态" },
        { value: "ok", label: "仅正常" },
        { value: "ban", label: "仅封禁" },
      ]) +
      '<div class="toolbar" style="margin-top:-4px"><div class="spacer"></div>' +
        '<button type="button" class="btn btn-primary btn-sm" data-act="user-add">新增账号</button></div>' +
      '<div class="table-wrap"><table><thead><tr><th>账号</th><th>状态</th><th>云端数据</th><th>时间</th><th>操作</th></tr></thead><tbody>' +
      rows + "</tbody></table></div>" + pager(d.total, state.page) + "</div>";
  }

  // ---------------- 攻略 ----------------

  async function renderGuides(root) {
    const status = state.extra === "hidden" ? "0" : (state.extra === "shown" ? "1" : "");
    let url = "/admin/api/guides?skip=" + state.page * PAGE_SIZE + "&limit=" + PAGE_SIZE + "&q=" + encodeURIComponent(state.q);
    if (status) url += "&status=" + status;
    const d = await api(url);
    const rows = d.items.map(function (g) {
      return "<tr>" +
        "<td>" + g.id + "</td>" +
        "<td><strong>" + esc(g.title) + '</strong><div class="muted" style="font-size:11.5px">' + esc(g.city || "-") + "</div></td>" +
        "<td>" + esc(g.author_name) + "</td>" +
        "<td>" + g.likes + " / " + g.favs + " / " + g.viewed_count + "</td>" +
        "<td>" + (g.featured ? '<span class="badge badge-warn">推荐</span> ' : "") +
          (g.status === 1 ? '<span class="badge badge-ok">在线</span>' : '<span class="badge badge-off">已隐藏</span>') + "</td>" +
        '<td class="muted">' + esc(g.created_at) + "</td>" +
        '<td class="actions">' +
          '<button type="button" class="btn btn-ghost btn-sm" data-act="guide-feature" data-id="' + g.id + '" data-value="' + (g.featured ? 0 : 1) + '">' +
            (g.featured ? "取消推荐" : "推荐") + "</button>" +
          '<button type="button" class="btn btn-ghost btn-sm" data-act="guide-status" data-id="' + g.id + '" data-value="' + (g.status === 1 ? 0 : 1) + '">' +
            (g.status === 1 ? "下线" : "上线") + "</button>" +
          '<button type="button" class="btn btn-danger btn-sm" data-act="guide-delete" data-id="' + g.id + '">删除</button>' +
        "</td></tr>";
    }).join("") || '<tr><td colspan="7"><div class="empty">暂无攻略</div></td></tr>';

    root.innerHTML = '<div class="card">' +
      toolbar("搜索标题 / 城市 / 作者", [
        { value: "", label: "全部状态" },
        { value: "shown", label: "仅在线" },
        { value: "hidden", label: "仅隐藏" },
      ]) +
      '<div class="table-wrap"><table><thead><tr><th>ID</th><th>标题</th><th>作者</th><th>赞/藏/看</th><th>状态</th><th>发布时间</th><th>操作</th></tr></thead><tbody>' +
      rows + "</tbody></table></div>" + pager(d.total, state.page) + "</div>";
  }

  // ---------------- 评论 ----------------

  async function renderComments(root) {
    const d = await api("/admin/api/comments?skip=" + state.page * PAGE_SIZE + "&limit=" + PAGE_SIZE + "&q=" + encodeURIComponent(state.q));
    const rows = d.items.map(function (c) {
      return "<tr>" +
        "<td>" + c.id + "</td>" +
        "<td>" + esc(c.user_name) + '<div class="muted mono" style="font-size:11px">@' + esc(c.user_account) + "</div></td>" +
        '<td class="muted">' + esc(c.guide_title || ("#" + c.guide_id)) + "</td>" +
        '<td class="wrap">' + esc(c.content) + (c.parent_id ? '<div class="muted" style="font-size:11px">回复 #' + c.parent_id + "</div>" : "") + "</td>" +
        "<td>" + c.likes + "</td>" +
        '<td class="muted">' + esc(c.created_at) + "</td>" +
        '<td class="actions"><button type="button" class="btn btn-danger btn-sm" data-act="comment-delete" data-id="' + c.id + '">删除</button></td>' +
        "</tr>";
    }).join("") || '<tr><td colspan="7"><div class="empty">暂无评论</div></td></tr>';

    root.innerHTML = '<div class="card">' +
      toolbar("搜索内容或用户") +
      '<div class="table-wrap"><table><thead><tr><th>ID</th><th>用户</th><th>攻略</th><th>内容</th><th>赞</th><th>时间</th><th>操作</th></tr></thead><tbody>' +
      rows + "</tbody></table></div>" + pager(d.total, state.page) + "</div>";
  }

  // ---------------- 云端足迹 ----------------

  async function renderFootprints(root) {
    const q = state.q;
    const asUser = /^\d+$/.test(q) ? ("&user_id=" + q) : "";
    const d = await api("/admin/api/footprints?skip=" + state.page * PAGE_SIZE + "&limit=" + PAGE_SIZE + "&q=" + encodeURIComponent(asUser ? "" : q) + asUser);
    const rows = d.items.map(function (f) {
      return "<tr>" +
        "<td>" + esc(f.nickname) + '<div class="muted mono" style="font-size:11px">@' + esc(f.username) + "</div></td>" +
        "<td><strong>" + esc(f.city || "-") + "</strong>" + (f.name ? '<div class="muted" style="font-size:11.5px">' + esc(f.name) + "</div>" : "") + "</td>" +
        '<td class="muted">' + esc(f.date || "-") + "</td>" +
        "<td>" + f.photos + (f.has_video ? " + 视频" : "") + "</td>" +
        '<td class="muted">' + esc(f.updated_at) + "</td>" +
        '<td class="actions"><button type="button" class="btn btn-danger btn-sm" data-act="fp-delete" data-id="' + f.user_id + '" data-cid="' + f.client_id + '">删除</button></td>' +
        "</tr>";
    }).join("") || '<tr><td colspan="6"><div class="empty">没有同步数据</div></td></tr>';

    root.innerHTML = '<div class="card">' +
      toolbar("搜索内容，或输入用户 ID 精确筛选") +
      '<div class="table-wrap"><table><thead><tr><th>用户</th><th>地点</th><th>日期</th><th>媒体</th><th>更新时间</th><th>操作</th></tr></thead><tbody>' +
      rows + "</tbody></table></div>" + pager(d.total, state.page) + "</div>";
  }

  // ---------------- 媒体 ----------------

  async function renderMedia(root) {
    const d = await api("/admin/api/media?skip=" + state.page * PAGE_SIZE + "&limit=" + PAGE_SIZE);
    const rows = d.items.map(function (m) {
      const thumb = m.kind === "image"
        ? '<img class="thumb" src="' + esc(m.url) + '" alt="" loading="lazy">'
        : '<div class="thumb" style="display:grid;place-items:center;color:#93a1b0">视频</div>';
      return "<tr>" +
        "<td>" + thumb + "</td>" +
        "<td>" + esc(m.nickname) + '<div class="muted mono" style="font-size:11px">user ' + m.user_id + "</div></td>" +
        "<td>" + esc(m.kind) + " · " + esc(m.mime) + "</td>" +
        "<td>" + bytes(m.bytes) + "</td>" +
        '<td class="muted">' + esc(m.created_at) + "</td>" +
        '<td class="actions"><a class="btn btn-ghost btn-sm" href="' + esc(m.url) + '" target="_blank" rel="noopener">查看</a>' +
        '<button type="button" class="btn btn-danger btn-sm" data-act="media-delete" data-id="' + m.id + '">删除</button></td>' +
        "</tr>";
    }).join("") || '<tr><td colspan="6"><div class="empty">暂无媒体文件</div></td></tr>';

    root.innerHTML = '<div class="card">' +
      '<div class="toolbar"><div class="spacer"></div><span class="chip">共 ' + d.total + " 个文件</span></div>" +
      '<div class="table-wrap"><table><thead><tr><th>预览</th><th>用户</th><th>类型</th><th>大小</th><th>上传时间</th><th>操作</th></tr></thead><tbody>' +
      rows + "</tbody></table></div>" + pager(d.total, state.page) + "</div>";
  }

  // ---------------- 审计 ----------------

  async function renderAudit(root) {
    const d = await api("/admin/api/audit?skip=" + state.page * PAGE_SIZE + "&limit=" + PAGE_SIZE + "&q=" + encodeURIComponent(state.q));
    const rows = d.items.map(function (a) {
      return "<tr>" +
        '<td class="muted">' + esc(a.created_at) + "</td>" +
        "<td>" + esc(a.actor) + "</td>" +
        "<td><span class=\"badge badge-off\">" + esc(a.action) + "</span></td>" +
        "<td>" + esc(a.target) + "</td>" +
        '<td class="muted">' + esc(a.detail) + "</td>" +
        '<td class="muted mono" style="font-size:11.5px">' + esc(a.ip) + "</td>" +
        "</tr>";
    }).join("") || '<tr><td colspan="6"><div class="empty">暂无记录</div></td></tr>';

    root.innerHTML = '<div class="card">' +
      toolbar("搜索操作者 / 动作 / 对象") +
      '<div class="table-wrap"><table><thead><tr><th>时间</th><th>操作者</th><th>动作</th><th>对象</th><th>详情</th><th>IP</th></tr></thead><tbody>' +
      rows + "</tbody></table></div>" + pager(d.total, state.page) + "</div>";
  }

  // ---------------- 系统 ----------------

  async function renderSystem(root) {
    const s = await api("/admin/api/system");
    state.system = s;
    qs("#env-label").textContent = "env: " + s.env;

    root.innerHTML =
      '<div class="grid grid-2">' +
        '<div class="card"><div class="card-title"><h3>运行参数</h3></div><div class="kv">' +
          "<dt>服务</dt><dd>" + esc(s.app_name) + " v" + esc(s.version) + "</dd>" +
          "<dt>环境</dt><dd>" + esc(s.env) + "</dd>" +
          "<dt>登录有效期</dt><dd>" + s.token_ttl_days + " 天</dd>" +
          "<dt>后台会话</dt><dd>" + s.admin_token_ttl_hours + " 小时</dd>" +
          "<dt>每人配额</dt><dd>" + bytes(s.quota_bytes) + "</dd>" +
          "<dt>图片上限</dt><dd>" + bytes(s.max_image_bytes) + "</dd>" +
          "<dt>视频上限</dt><dd>" + bytes(s.max_video_bytes) + "</dd>" +
          "<dt>JWT 密钥来源</dt><dd>" + esc(s.secret_key_source) + "</dd>" +
          "<dt>测试账号</dt><dd>" + esc(s.test_account || "未启用") + "</dd>" +
        "</div></div>" +
        '<div class="card"><div class="card-title"><h3>存储</h3></div><div class="kv">' +
          "<dt>数据库</dt><dd class=\"mono\">" + esc(s.database_path) + "<br>" + bytes(s.db_bytes) + "</dd>" +
          "<dt>存储目录</dt><dd class=\"mono\">" + esc(s.storage_path) + "<br>" + bytes(s.storage_bytes) + "</dd>" +
          "<dt>媒体占用</dt><dd>" + bytes(s.media_bytes) + "</dd>" +
          "<dt>服务端检索</dt><dd>" + (s.search_configured ? "已配置" : "未配置（App 走本地检索）") + "</dd>" +
        "</div></div>" +
      "</div>";
  }

  // ---------------- 内容中心 ----------------

  const JOB_BADGE = { queued: "badge-off", running: "badge-warn", done: "badge-ok", failed: "badge-danger" };

  async function renderContent(root) {
    const overview = await api("/admin/api/content/overview");
    const ov = overview.data;
    const sources = (await api("/admin/api/content/sources")).data || [];
    const jobs = (await api("/admin/api/content/jobs?limit=12")).data || [];
    const items = (await api("/admin/api/content/items?limit=12")).data || [];

    const sourceRows = sources.map(function (s) {
      return "<tr>" +
        "<td>" + s.id + "</td>" +
        "<td><strong>" + esc(s.name) + '</strong><div class="muted mono" style="font-size:11px">' + esc(s.list_url) + "</div></td>" +
        "<td>" + esc(s.kind) + "</td>" +
        "<td>" + s.interval_minutes + " 分钟 / 最多 " + s.max_items + " 条</td>" +
        "<td>" + (s.enabled ? '<span class="badge badge-ok">启用</span>' : '<span class="badge badge-off">停用</span>') +
          '<div class="muted" style="font-size:11.5px">' + esc(s.last_status || "还没跑过") + "</div></td>" +
        '<td class="actions">' +
          '<button type="button" class="btn btn-ghost btn-sm" data-act="content-run" data-id="' + s.id + '">立即抓取</button>' +
          '<button type="button" class="btn btn-danger btn-sm" data-act="content-source-del" data-id="' + s.id + '">删除</button>' +
        "</td></tr>";
    }).join("") || '<tr><td colspan="6"><div class="empty">还没有内容源，点右上角「新增内容源」</div></td></tr>';

    const jobRows = jobs.map(function (j) {
      return "<tr>" +
        "<td>" + j.id + "</td>" +
        "<td>" + esc(j.kind) + "</td>" +
        '<td class="wrap mono" style="font-size:11.5px">' + esc(j.url || ("source #" + j.source_id)) + "</td>" +
        '<td><span class="badge ' + (JOB_BADGE[j.status] || "badge-off") + '">' + esc(j.status) + "</span></td>" +
        "<td>" + j.created_items + "</td>" +
        '<td class="muted wrap">' + esc(j.error || "—") + "</td>" +
        '<td class="muted">' + esc(j.created_at) + "</td>" +
        '<td class="actions">' + (j.status === "failed"
          ? '<button type="button" class="btn btn-ghost btn-sm" data-act="content-job-retry" data-id="' + j.id + '">重试</button>'
          : "—") + "</td></tr>";
    }).join("") || '<tr><td colspan="8"><div class="empty">暂无抓取任务</div></td></tr>';

    const itemRows = items.map(function (it) {
      return "<tr>" +
        "<td>" + it.id + "</td>" +
        '<td><strong>' + esc(it.title) + '</strong><div class="muted" style="font-size:11.5px">' + esc(it.summary).slice(0, 80) + "</div></td>" +
        "<td>" + esc(it.host) + "</td>" +
        "<td>" + esc(it.category || "—") + "</td>" +
        "<td>" + it.word_count + "</td>" +
        '<td class="muted">' + esc(it.fetched_at) + "</td>" +
        '<td class="actions"><a class="btn btn-ghost btn-sm" href="' + esc(it.url) + '" target="_blank" rel="noopener">原文</a>' +
          '<button type="button" class="btn btn-ghost btn-sm" data-act="content-item-hide" data-id="' + it.id + '">隐藏</button>' +
          '<button type="button" class="btn btn-danger btn-sm" data-act="content-item-del" data-id="' + it.id + '">删除</button></td>' +
        "</tr>";
    }).join("") || '<tr><td colspan="7"><div class="empty">还没有抓取到内容</div></td></tr>';

    root.innerHTML =
      '<div class="grid grid-4">' +
        statCard("内容源", ov.sources, "启用 " + ov.enabled_sources, "") +
        statCard("已入库内容", ov.items, "24 小时新增 " + ov.new_24h, "") +
        statCard("队列", ov.queued_jobs, "等待抓取的任务", "") +
        statCard("失败任务", ov.failed_jobs, "可在下方重试", "") +
      "</div>" +
      '<div class="card" style="margin-top:14px"><div class="card-title"><h3>内容源</h3>' +
        '<div class="spacer"></div>' +
        '<button type="button" class="btn btn-ghost btn-sm" data-act="content-fetch">抓取单个 URL</button>' +
        '<button type="button" class="btn btn-primary btn-sm" data-act="content-source-add">新增内容源</button></div>' +
        '<div class="table-wrap"><table><thead><tr><th>ID</th><th>名称 / 列表页</th><th>类型</th><th>频率</th><th>状态</th><th>操作</th></tr></thead><tbody>' +
        sourceRows + "</tbody></table></div></div>" +
      '<div class="card" style="margin-top:14px"><div class="card-title"><h3>抓取任务（最近 12 条）</h3></div>' +
        '<div class="table-wrap"><table><thead><tr><th>ID</th><th>类型</th><th>目标</th><th>状态</th><th>新增</th><th>错误</th><th>创建时间</th><th>操作</th></tr></thead><tbody>' +
        jobRows + "</tbody></table></div></div>" +
      '<div class="card" style="margin-top:14px"><div class="card-title"><h3>最近内容</h3></div>' +
        '<div class="table-wrap"><table><thead><tr><th>ID</th><th>标题</th><th>来源域名</th><th>分类</th><th>字数</th><th>抓取时间</th><th>操作</th></tr></thead><tbody>' +
        itemRows + "</tbody></table></div></div>";
  }

  // ---------------- 交互动作 ----------------

  document.addEventListener("click", async function (ev) {
    const target = ev.target.closest("[data-act]");
    if (!target) return;
    const act = target.dataset.act;

    if (act === "prev") { state.page = Math.max(0, state.page - 1); render(); return; }
    if (act === "next") { state.page += 1; render(); return; }
    if (act === "search") {
      const input = qs("#search-input");
      state.q = input ? input.value.trim() : "";
      const select = qs("#filter-select");
      if (select) state.extra = select.value;
      state.page = 0;
      render();
      return;
    }

    const id = target.dataset.id;
    try {
      if (act === "user-add") {
        openModal({
          title: "新增账号",
          desc: "直接创建一个 App 账号，跳过注册验证地址。建完让用户用这个账号和密码登录即可。",
          fields: [
            { name: "username", label: "账号（3–20 位，字母/数字/_/中文）", value: "" },
            { name: "nickname", label: "昵称（可空）", value: "旅行者" },
            { name: "password", label: "初始密码（至少 6 位）", type: "password", value: "" },
          ],
          submitText: "创建账号",
          onSubmit: async function (values) {
            if (!values.username) throw new Error("账号必填");
            if (values.password.length < 6) throw new Error("密码至少 6 位");
            const r = await api("/admin/api/users", {
              method: "POST",
              body: { username: values.username, nickname: values.nickname, password: values.password },
            });
            toast("已创建：" + r.data.username);
            render();
          },
        });
      } else if (act === "user-ban" || act === "user-unban") {
        const status = act === "user-ban" ? 0 : 1;
        await api("/admin/api/users/" + id + "/status?status=" + status, { method: "POST" });
        toast(status ? "已解封" : "已封禁");
        render();
      } else if (act === "user-reset") {
        openModal({
          title: "重置用户密码",
          desc: "为 " + target.dataset.account + " 设置新密码。用户所有旧登录会被强制失效。",
          fields: [{ name: "new_password", label: "新密码（至少 6 位）", type: "password", value: "" }],
          submitText: "重置",
          onSubmit: async function (values) {
            if (values.new_password.length < 6) throw new Error("新密码至少 6 位");
            await api("/admin/api/users/" + id + "/reset_password", { method: "POST", body: { new_password: values.new_password } });
            toast("密码已重置");
          },
        });
      } else if (act === "user-note") {
        openModal({
          title: "添加备注",
          desc: "备注仅后台可见，用于标记测试账号、异常用户等。",
          fields: [{ name: "note", label: "备注（留空即清除）", type: "text", value: "" }],
          submitText: "保存",
          onSubmit: async function (values) {
            await api("/admin/api/users/" + id + "/note", { method: "POST", body: { note: values.note } });
            toast("已保存");
            render();
          },
        });
      } else if (act === "user-delete") {
        confirmModal("删除用户", "将删除 " + target.dataset.account + " 及其攻略、评论、云端足迹与媒体文件，不可恢复。", async function () {
          await api("/admin/api/users/" + id, { method: "DELETE" });
          toast("用户已删除");
          render();
        });
      } else if (act === "guide-feature") {
        await api("/admin/api/guides/" + id, { method: "PATCH", body: { featured: target.dataset.value === "1" } });
        toast("已更新推荐状态");
        render();
      } else if (act === "guide-status") {
        await api("/admin/api/guides/" + id, { method: "PATCH", body: { status: Number(target.dataset.value) } });
        toast("已更新上下线状态");
        render();
      } else if (act === "guide-delete") {
        confirmModal("删除攻略", "删除后该攻略及其评论会一并移除，不可恢复。", async function () {
          await api("/admin/api/guides/" + id, { method: "DELETE" });
          toast("攻略已删除");
          render();
        });
      } else if (act === "comment-delete") {
        await api("/admin/api/comments/" + id, { method: "DELETE" });
        toast("评论已删除");
        render();
      } else if (act === "fp-delete") {
        confirmModal("删除云端足迹", "只删除服务器副本，不影响用户手机上的数据。", async function () {
          await api("/admin/api/footprints/" + id + "/" + target.dataset.cid, { method: "DELETE" });
          toast("已删除");
          render();
        });
      } else if (act === "media-delete") {
        confirmModal("删除媒体文件", "将从磁盘删除该文件，引用它的云端足迹会失去图片。", async function () {
          await api("/admin/api/media/" + id, { method: "DELETE" });
          toast("文件已删除");
          render();
        });
      } else if (act === "content-source-add") {
        openModal({
          title: "新增内容源",
          desc: "填列表页 / RSS / sitemap 地址。worker 会按频率自动跑，也可以用「立即抓取」手动触发。",
          fields: [
            { name: "name", label: "名称（如：马蜂窝·攻略）", value: "" },
            { name: "list_url", label: "列表页 URL（http/https）", value: "" },
            { name: "kind", label: "类型：html / rss / sitemap", value: "html" },
            { name: "host", label: "限定域名（可空，默认列表页同域）", value: "" },
            { name: "default_category", label: "默认分类（如：攻略）", value: "攻略" },
            { name: "interval_minutes", label: "抓取间隔（分钟，最小 5）", value: "120" },
            { name: "max_items", label: "每轮最多新增条数", value: "12" },
          ],
          submitText: "创建",
          onSubmit: async function (values) {
            if (!values.name || !values.list_url) throw new Error("名称和列表页 URL 必填");
            const kind = (values.kind || "html").toLowerCase();
            if (["html", "rss", "sitemap"].indexOf(kind) < 0) throw new Error("类型只能是 html / rss / sitemap");
            await api("/admin/api/content/sources", {
              method: "POST",
              body: {
                name: values.name,
                list_url: values.list_url,
                kind: kind,
                host: values.host,
                default_category: values.default_category,
                interval_minutes: Number(values.interval_minutes) || 60,
                max_items: Number(values.max_items) || 12,
              },
            });
            toast("内容源已创建");
            render();
          },
        });
      } else if (act === "content-fetch") {
        openModal({
          title: "抓取单个 URL",
          desc: "抓取 → 清洗 → 去重后进内容库，App 下一次拉取就能看到。",
          fields: [{ name: "url", label: "文章 URL", value: "" }],
          submitText: "抓取",
          onSubmit: async function (values) {
            if (!values.url) throw new Error("请填文章 URL");
            const r = await api("/admin/api/content/fetch-url", { method: "POST", body: { url: values.url } });
            toast("已入队，任务 #" + r.data.job_id);
            render();
          },
        });
      } else if (act === "content-run") {
        const r = await api("/admin/api/content/sources/" + id + "/run", { method: "POST" });
        toast("已入队，任务 #" + r.data.job_id);
        render();
      } else if (act === "content-source-del") {
        confirmModal("删除内容源", "只删除抓取配置，已入库的内容会保留。", async function () {
          await api("/admin/api/content/sources/" + id, { method: "DELETE" });
          toast("内容源已删除");
          render();
        });
      } else if (act === "content-job-retry") {
        await api("/admin/api/content/jobs/" + id + "/retry", { method: "POST" });
        toast("已重新入队");
        render();
      } else if (act === "content-item-hide") {
        await api("/admin/api/content/items/" + id, { method: "PATCH", body: { status: 0 } });
        toast("已从 App 端隐藏");
        render();
      } else if (act === "content-item-del") {
        confirmModal("删除内容", "App 端将不再下发这条内容，不可恢复。", async function () {
          await api("/admin/api/content/items/" + id, { method: "DELETE" });
          toast("内容已删除");
          render();
        });
      }
    } catch (e) {
      toast(e.message, true);
    }
  });

  // ---------------- 弹窗 ----------------

  const modal = qs("#modal");

  function openModal(options) {
    qs("#modal-title").textContent = options.title;
    qs("#modal-desc").textContent = options.desc || "";
    const body = qs("#modal-body");
    body.innerHTML = (options.fields || []).map(function (f) {
      return '<label class="field"><span>' + esc(f.label) + '</span><input name="' + esc(f.name) +
        '" type="' + esc(f.type || "text") + '" value="' + esc(f.value || "") + '" autocomplete="off"></label>';
    }).join("");
    qs("#modal-submit").textContent = options.submitText || "确定";
    const form = qs("#modal-form");
    form.onsubmit = async function (ev) {
      ev.preventDefault();
      const values = {};
      Array.prototype.forEach.call(body.querySelectorAll("input"), function (input) { values[input.name] = input.value.trim(); });
      try {
        await options.onSubmit(values);
        modal.close();
      } catch (e) {
        toast(e.message, true);
      }
    };
    modal.showModal();
    const first = body.querySelector("input");
    if (first) first.focus();
  }

  function confirmModal(title, desc, onConfirm) {
    qs("#modal-title").textContent = title;
    qs("#modal-desc").textContent = desc;
    qs("#modal-body").innerHTML = "";
    qs("#modal-submit").textContent = "确认删除";
    qs("#modal-form").onsubmit = async function (ev) {
      ev.preventDefault();
      try {
        await onConfirm();
        modal.close();
      } catch (e) {
        toast(e.message, true);
      }
    };
    modal.showModal();
  }

  qs("#modal-cancel").addEventListener("click", function () { modal.close(); });

  // 搜索框下方的状态筛选跟着变化
  document.addEventListener("change", function (ev) {
    if (ev.target && ev.target.id === "filter-select") {
      state.extra = ev.target.value;
      state.page = 0;
      render();
    }
  });

  // ---------------- 启动 ----------------

  async function boot() {
    showApp();
    try {
      const s = await api("/admin/api/system");
      state.system = s;
      qs("#env-label").textContent = "env: " + s.env;
    } catch (e) { /* 概览会再报 */ }
    setView(state.view);
  }

  (async function init() {
    const t = token();
    if (!t) { showLogin(""); return; }
    try {
      const session = await api("/admin/api/session");
      state.admin = session.admin;
      qs("#admin-chip").textContent = session.admin && session.admin.name ? session.admin.name : "管理员";
      await boot();
    } catch (e) {
      localStorage.removeItem(TOKEN_KEY);
      showLogin("登录已失效，请重新登录");
    }
  })();
})();
