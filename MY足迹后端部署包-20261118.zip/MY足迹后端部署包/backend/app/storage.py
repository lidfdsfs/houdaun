"""上传落盘与类型嗅探。

安全要点：
1. 不信客户端 Content-Type —— 按文件头判断真实类型，伪装成图片的 HTML/SVG 会被 415 拒绝；
2. 文件名不参与路径 —— 落盘名是 sha256 + 白名单后缀，杜绝 `../` 目录穿越；
3. 边写边算 sha256，不把整段视频读进内存；
4. 超限立刻中断并删除临时文件，避免磁盘被撑爆。
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any, BinaryIO

from fastapi import HTTPException, UploadFile

from .config import settings

# 每种上传类别落到用户目录下的哪个子目录
# 存储布局：storage/users/{user_id}/{category}/{sha[:2]}/{sha}{ext}
# 一个用户的所有东西（照片、视频、头像、封面、隐私空间密文、数据镜像）都在同一个文件夹里。
CATEGORIES = {
    "media": "media",
    "avatar": "avatar",
    "cover": "cover",
    "vault": "vault",
}

EXT_BY_MIME = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "image/heic": ".heic",
    "image/heif": ".heif",
    "video/mp4": ".mp4",
    "video/quicktime": ".mov",
    "video/3gpp": ".3gp",
    "video/webm": ".webm",
    "video/x-msvideo": ".avi",
}

_FTYP_IMAGE = {"heic", "heix", "hevc", "hevx", "mif1", "msf1", "mif2"}
_FTYP_MP4 = {"isom", "iso2", "iso3", "iso4", "iso5", "iso6", "mp41", "mp42", "avc1", "dash", "M4V ", "m4v1"}
_FTYP_MOV = {"qt  "}
_FTYP_3GP = {"3gp4", "3gp5", "3gp6", "3g2a", "3g2b"}


def sniff_mime(head: bytes) -> str | None:
    """按文件头返回 MIME；认不出来返回 None。"""
    if len(head) < 12:
        return None
    if head[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "image/webp"
    if head[:4] == b"RIFF" and head[8:12] == b"AVI ":
        return "video/x-msvideo"
    if head[:4] == b"\x1a\x45\xdf\xa3":
        return "video/webm"
    if head[4:8] == b"ftyp":
        brand = head[8:12].decode("latin-1")
        if brand in _FTYP_IMAGE:
            return "image/heif" if brand in {"mif1", "msf1", "mif2"} else "image/heic"
        if brand in _FTYP_MOV:
            return "video/quicktime"
        if brand in _FTYP_3GP:
            return "video/3gpp"
        if brand in _FTYP_MP4:
            return "video/mp4"
    return None


def allowed_mimes(category: str) -> set[str]:
    if category == "media":
        return settings.image_mimes | settings.video_mimes
    return settings.image_mimes


def size_cap(category: str) -> int:
    if category == "media":
        return max(settings.max_image_bytes, settings.max_video_bytes)
    if category == "avatar":
        return settings.max_avatar_bytes
    return settings.max_image_bytes


def user_root(user_id: int) -> Path:
    """每个用户一个文件夹：storage/users/{id}。"""
    p = settings.storage_path / "users" / str(int(user_id))
    p.mkdir(parents=True, exist_ok=True)
    return p


def user_dir(user_id: int, category: str) -> Path:
    if category not in CATEGORIES:
        raise ValueError(f"未知的上传类别：{category}")
    p = user_root(user_id) / CATEGORIES[category]
    p.mkdir(parents=True, exist_ok=True)
    return p


def user_data_dir(user_id: int) -> Path:
    p = user_root(user_id) / "data"
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_user_json(user_id: int, name: str, payload: Any) -> Path:
    """把某个分区的数据镜像写成 users/{id}/data/{name}.json。

    后台既可以从库里读，也可以直接看这个文件——两者内容一致。
    """
    target = user_data_dir(user_id) / f"{name}.json"
    tmp = target.with_name(target.name + ".part")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, target)
    return target


def read_user_json(user_id: int, name: str) -> Any:
    target = user_data_dir(user_id) / f"{name}.json"
    if not target.is_file():
        return None
    try:
        return json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def user_folder_summary(user_id: int) -> dict[str, Any]:
    """统计用户文件夹：各子目录文件数与字节数。"""
    root = user_root(user_id)
    dirs: dict[str, dict[str, int]] = {}
    total_files = 0
    total_bytes = 0
    for item in root.rglob("*"):
        if not item.is_file():
            continue
        rel = item.relative_to(root).parts
        bucket = rel[0] if len(rel) > 1 else "(根目录)"
        size = item.stat().st_size
        d = dirs.setdefault(bucket, {"files": 0, "bytes": 0})
        d["files"] += 1
        d["bytes"] += size
        total_files += 1
        total_bytes += size
    return {
        "folder": f"users/{int(user_id)}",
        "abs_path": str(root),
        "total_files": total_files,
        "total_bytes": total_bytes,
        "dirs": dirs,
    }


def list_user_files(user_id: int, limit: int = 500) -> list[dict[str, Any]]:
    root = user_root(user_id)
    out: list[dict[str, Any]] = []
    for item in sorted(root.rglob("*")):
        if not item.is_file():
            continue
        rel = item.relative_to(root).as_posix()
        out.append(
            {
                "path": rel,
                "bytes": item.stat().st_size,
                "updated_at": int(item.stat().st_mtime),
                "url": f"/uploads/users/{int(user_id)}/{rel}" if rel.startswith(("media/", "avatar/", "cover/", "vault/")) else None,
            }
        )
        if len(out) >= limit:
            break
    return out


def _stream_to_temp(fileobj: BinaryIO, max_bytes: int) -> tuple[Path, int, str, bytes]:
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".part")
    sha = hashlib.sha256()
    total = 0
    head = b""
    try:
        while True:
            chunk = fileobj.read(1024 * 1024)
            if not chunk:
                break
            if not head:
                head = chunk[:64]
            total += len(chunk)
            if total > max_bytes:
                raise HTTPException(status_code=413, detail=f"文件过大，上限 {max_bytes // (1024 * 1024)}MB")
            sha.update(chunk)
            tmp.write(chunk)
    except HTTPException:
        tmp.close()
        os.unlink(tmp.name)
        raise
    except OSError:
        tmp.close()
        os.unlink(tmp.name)
        raise HTTPException(status_code=500, detail="写入文件失败")
    finally:
        try:
            tmp.close()
        except OSError:
            pass
    return Path(tmp.name), total, sha.hexdigest(), head


def save_upload(upload: UploadFile, user_id: int, category: str = "media") -> dict:
    if category not in CATEGORIES:
        raise HTTPException(status_code=400, detail="未知的上传类别")
    cap = size_cap(category)
    # 先读一次镜像文件句柄（FastAPI 已经把内容落在 SpooledTemporaryFile）
    upload.file.seek(0)
    tmp_path, total, digest, head = _stream_to_temp(upload.file, cap)

    mime = sniff_mime(head)
    allowed = allowed_mimes(category)
    if mime is None or mime not in allowed:
        os.unlink(tmp_path)
        if category == "media":
            raise HTTPException(status_code=415, detail="不支持的文件类型（仅限 JPG/PNG/WebP/GIF/HEIC/MP4/MOV/3GP/WebM/AVI）")
        raise HTTPException(status_code=415, detail="不支持的图片类型（仅限 JPG/PNG/WebP/GIF/HEIC）")

    if category == "media":
        limit = settings.max_video_bytes if mime.startswith("video/") else settings.max_image_bytes
        if total > limit:
            os.unlink(tmp_path)
            label = "视频" if mime.startswith("video/") else "图片"
            raise HTTPException(status_code=413, detail=f"{label}过大，上限 {limit // (1024 * 1024)}MB")

    ext = EXT_BY_MIME.get(mime, ".bin")
    subdir = CATEGORIES[category]
    final_dir = user_root(user_id) / subdir / digest[:2]
    final_dir.mkdir(parents=True, exist_ok=True)
    final = final_dir / f"{digest}{ext}"
    rel = f"users/{int(user_id)}/{subdir}/{digest[:2]}/{digest}{ext}"

    dedup = final.exists()
    if dedup:
        os.unlink(tmp_path)
    else:
        try:
            os.replace(tmp_path, final)
        except OSError:
            os.unlink(tmp_path)
            raise HTTPException(status_code=500, detail="保存文件失败")

    return {
        "url": f"/uploads/{rel}",
        "sha256": digest,
        "bytes": total,
        "mime": mime,
        "dedup": dedup,
        "rel_path": rel,
        "kind": "video" if mime.startswith("video/") else "image",
    }


def save_encrypted_blob(upload: UploadFile, user_id: int) -> dict:
    """隐私空间的密文块：端侧 AES-GCM 加密后的字节，服务端不做类型嗅探、不解密。

    布局：users/{id}/vault/{sha[:2]}/{sha}.bin
    """
    upload.file.seek(0)
    tmp_path, total, digest, _head = _stream_to_temp(upload.file, settings.max_video_bytes)
    subdir = CATEGORIES["vault"]
    final_dir = user_root(user_id) / subdir / digest[:2]
    final_dir.mkdir(parents=True, exist_ok=True)
    final = final_dir / f"{digest}.bin"
    rel = f"users/{int(user_id)}/{subdir}/{digest[:2]}/{digest}.bin"
    dedup = final.exists()
    if dedup:
        os.unlink(tmp_path)
    else:
        try:
            os.replace(tmp_path, final)
        except OSError:
            os.unlink(tmp_path)
            raise HTTPException(status_code=500, detail="保存密文失败")
    return {"url": f"/uploads/{rel}", "sha256": digest, "bytes": total, "rel_path": rel, "dedup": dedup}


def delete_media_file(rel_path: str) -> bool:
    """删除 storage 下的文件；只接受 storage 内的相对路径。"""
    if not rel_path:
        return False
    target = (settings.storage_path / rel_path).resolve()
    try:
        target.relative_to(settings.storage_path)
    except ValueError:
        return False
    try:
        target.unlink()
        return True
    except FileNotFoundError:
        return True
    except OSError:
        return False
