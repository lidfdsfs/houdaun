# MY足迹 后端服务

「MY足迹」安卓 App 的云端后端，含**管理员后台 UI**。单机可跑，零外部依赖（SQLite + 本地磁盘），
生产用 systemd / Docker + Nginx + HTTPS 部署即可。

- 框架：FastAPI + Uvicorn
- 存储：SQLite（WAL）+ 本地磁盘
- 认证：客户端 SHA-256 预哈希 → 服务端 bcrypt；JWT（带 token 版本号，改密/封禁即失效）
- 后台：`/admin` 单页控制台（用户、攻略、评论、云端足迹、媒体、审计、系统配置）

## 一、它解决什么

App 原本是纯本地应用（Room + 本机文件），打开「设置 → 数据与备份 → 云端同步」后走这里：

1. 用户名登录 / 注册（图形验证码 + 一次性验证地址），忘记密码由管理员后台重置
2. 攻略与评论（发布、点赞、收藏、楼中楼）
3. 足迹与行程（结构化接口 + 批量同步接口）
4. 照片 / 视频上传（sha256 去重、每人 2GB 配额）
5. 设置快照、整库快照（换机恢复用）
6. 可选的服务端网页索引（接自建 SearXNG）
7. **网页抓取 + 清洗 + 回传**：后台维护内容源（html/rss/sitemap），worker 抓取并抽正文，
   App 按 `since_id` 增量拉取（`/api/content/feed`）
8. **站内私信**：单聊会话、会话内 seq、发送幂等、未读/已读回执、限时撤回、拉黑、SSE 实时推送
9. **联网搜索（临时会话）**：服务器按 `fast/balanced/deep` 检索网页、并发抓正文清洗，
   结果只在服务器短期保留，关闭会话或到期自动删除；不落原始 HTML
10. **后台直接建号**：管理员在「用户」页填用户名 + 初始密码，建完 App 可直接登录（跳过注册验证码）

## 二、目录结构

```
backend/
├── app/
│   ├── main.py            # 应用入口、中间件、/uploads、/admin 页面
│   ├── config.py          # 环境变量与启动安全检查
│   ├── db.py              # SQLite 建表、事务、种子数据
│   ├── security.py        # 预哈希、bcrypt、JWT、图形验证码、限流
│   ├── schemas.py         # 请求参数校验（含长度上限）
│   ├── deps.py            # 鉴权依赖、客户端 IP、审计
│   ├── storage.py         # 上传落盘 + 文件头嗅探 + 去重
│   ├── content.py         # 网页抓取、HTML 清洗、去重、任务队列与后台 worker
│   ├── search_online.py   # 联网搜索：Bing/SearXNG、正文清洗、临时会话与清理线程
│   ├── routers/
│   │   ├── auth.py        # /auth/*
│   │   ├── users.py       # /users/*
│   │   ├── guides.py      # /guides/*、/upload/cover
│   │   ├── comments.py    # /comments、/guides/{id}/comments
│   │   ├── routes.py      # /routes/*
│   │   ├── sync.py        # /api/sync/*
│   │   ├── search.py      # /api/search、/api/search/online、/admin/api/search/*
│   │   ├── content.py     # /api/content/*、/admin/api/content/*
│   │   ├── messages.py    # /api/messages/*（含 SSE）
│   │   └── admin.py       # /admin/api/*（含后台建号）
│   └── admin_ui/          # 后台前端（index.html / app.js / style.css）
├── scripts/
│   ├── verify_local.py         # 全链路冒烟测试（39 项）
│   ├── verify_auth_flows.py    # 认证边界测试（注册/改密/验证码/封禁）
│   ├── verify_full_data.py     # 全量上传 / 用户文件夹（14 项）
│   ├── verify_content_messages.py # 抓取 + 私信（30 项，临时库）
│   ├── verify_search_admin.py  # 联网搜索 + 后台建号（23 项，临时库）
│   └── backup.py               # 数据库 + 媒体备份
├── deploy/                     # nginx.conf、systemd 单元
├── docs/                       # 后端总览、配置清单、接口清单、局域网联调
├── Dockerfile / docker-compose.yml
├── requirements.txt / .env.example
```

## 三、本地跑起来（3 分钟）

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env             # 本地可先不改，默认 dev 环境
uvicorn app.main:app --reload --port 8000
```

打开：

- 后台：<http://127.0.0.1:8000/admin> → 账号 `admin`，密码 `admin-dev-2026`（仅开发环境默认值）
- 接口文档：<http://127.0.0.1:8000/docs>
- 测试账号：`user1` / `123456`（首次启动自动创建，App 可直接登录）

自检：

```bash
python scripts/verify_local.py --base http://127.0.0.1:8000
python scripts/verify_auth_flows.py --base http://127.0.0.1:8000
python scripts/verify_full_data.py --base http://127.0.0.1:8000
python scripts/verify_content_messages.py          # 抓取 + 私信，自带临时库与本地 fixture
```

## 四、生产部署

完整步骤、变量说明、HTTPS、备份、验收清单一律见 **[docs/配置清单.md](docs/配置清单.md)**。
最快的两条路：

```bash
# 方式 A：systemd + venv（推荐，日志进 journald）
sudo cp deploy/myzuji-api.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now myzuji-api

# 方式 B：Docker
docker compose up -d --build
```

两种方式都要在前面放 Nginx 并配 HTTPS（App 端 `usesCleartextTraffic=false`，明文 HTTP 会被安卓直接拒绝）。

## 五、安全设计

| 环节 | 做法 |
|---|---|
| 密码传输 | 客户端先 `SHA256("myzuji_salt_v2:密码")`，服务端只收到哈希；明文不出设备 |
| 密码存储 | bcrypt cost=12，存的是「预哈希值的 bcrypt」，即使库泄露也拿不到明文 |
| 登录令牌 | JWT HS256，30 天；带 `ver`，改密/封禁/重置后旧 token 立即失效；登出把 jti 进黑名单 |
| 暴力破解 | 连续 3 次失败要求图形验证码，8 次锁 15 分钟；认证接口按 IP 限流 20 次/分 |
| 图形验证码 | Pillow 生成，5 分钟有效、一次性消费、答案存库不返回 |
| 注册验证 | 生成一次性验证地址（含验证码），15 分钟有效；浏览器打开验证后地址立即失效，注册成功彻底删除 |
| 上传安全 | 按文件头嗅探真实类型（伪装成图片的 HTML 直接 415）；落盘名是 sha256+白名单后缀；`/uploads` 只允许读 storage 内路径 |
| 后台 | 独立口令（不建用户记录）、12 小时会话、登录限流、全部写操作落审计日志、写接口日志不含口令 |
| 其他 | 统一安全响应头（nosniff / DENY / HSTS / CSP）、请求体硬上限、异常不泄露堆栈、配置里没有默认密钥 |

生产启动时会主动拒绝：`SECRET_KEY` 仍是占位值、`ADMIN_PASSWORD` 未设置或少于 8 位。

## 六、给 App 用之前必须改一处

`app/src/main/java/com/example/my/data/CloudConfig.kt`：

```kotlin
const val SERVER_URL = "https://你的域名"
```

改完重新打包 APK。App 默认「云端同步」是关闭的，需要用户在设置里手动打开才会连服务器。

## 七、文档

- **[工程交接](docs/工程交接.md)**：第一次接手先读这个，30 分钟了解全貌
- [后端总览](docs/后端总览.md)：模块、数据模型、接口地图、抓取与私信设计、部署步骤
- [配置清单](docs/配置清单.md)：从买服务器到验收的每一步
- [接口清单](docs/接口清单.md)：全部接口、字段与错误语义
- `/docs`：运行时的 Swagger 交互文档

