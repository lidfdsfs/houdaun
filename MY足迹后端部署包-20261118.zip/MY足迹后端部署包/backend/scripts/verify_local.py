"""本地全链路自检脚本。

用法：
    python scripts/verify_local.py [--base http://127.0.0.1:8011]
先启动服务，再跑这个脚本。它按安卓端 BackendApi 的真实请求顺序打一遍接口，
全部通过会打印 PASS 汇总并以 0 退出；任何一条失败以 1 退出，便于部署时当冒烟测试用。

注意：脚本会向测试账号写入一条足迹、一条攻略与一张测试图，并在结束时清理掉；
不要指向生产库执行（会留下少量数据）。
"""
from __future__ import annotations

import argparse
import hashlib
import io
import sys
import time
from typing import Any

import httpx
from PIL import Image, ImageDraw

ACCOUNT = "user1"
PASSWORD = "123456"
ADMIN_USER = "admin"
ADMIN_PASSWORD = "admin-dev-2026"  # 与 config.py 开发环境默认口令一致

results: list[tuple[bool, str, str]] = []


def check(ok: bool, name: str, detail: str = "") -> bool:
    results.append((ok, name, detail))
    mark = "PASS" if ok else "FAIL"
    print(f"[{mark}] {name}" + (f" — {detail}" if detail else ""))
    return ok


def prehash(password: str) -> str:
    return hashlib.sha256(f"myzuji_salt_v2:{password}".encode()).hexdigest()


def png_bytes(color: tuple[int, int, int]) -> bytes:
    """生成一张带随机噪点的 PNG：每次运行内容不同，才能测出「首次上传 dedup=false」。"""
    import random

    img = Image.new("RGB", (64, 64), color)
    draw = ImageDraw.Draw(img)
    draw.rectangle((8, 8, 56, 56), outline=(255, 255, 255), width=3)
    rnd = random.Random(time.time_ns())
    for _ in range(40):
        x, y = rnd.randrange(64), rnd.randrange(64)
        draw.point((x, y), fill=(rnd.randrange(256), rnd.randrange(256), rnd.randrange(256)))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="http://127.0.0.1:8011")
    args = parser.parse_args()
    base = args.base.rstrip("/")

    client = httpx.Client(base_url=base, timeout=30.0)

    # 1. 存活
    r = client.get("/ping")
    check(r.status_code == 200 and r.json().get("ok") is True, "GET /ping")

    # 2. 图形验证码
    r = client.get("/auth/captcha")
    cap = r.json() if r.status_code == 200 else {}
    ok = r.status_code == 200 and cap.get("captcha_id") and cap.get("image")
    if ok:
        try:
            Image.open(io.BytesIO(__import__("base64").b64decode(cap["image"]))).verify()
        except Exception as exc:  # noqa: BLE001
            ok = False
            cap["detail"] = str(exc)
    check(ok, "GET /auth/captcha（返回可解码 PNG）")

    # 3. 未登录访问受保护接口应 401
    r = client.get("/users/me")
    check(r.status_code == 401, "未带 token 访问 /users/me 应为 401", f"实际 {r.status_code}")

    # 4. 错误密码：先确认连续失败会升级为 need_captcha，但只打两次，避免锁号
    for i in range(2):
        r = client.post("/auth/login", json={"username": ACCOUNT, "password_hash": prehash("wrong-password")})
        check(r.status_code == 401, f"错误密码第 {i + 1} 次应 401", f"实际 {r.status_code}")

    # 5. 正确密码登录（测试账号）
    r = client.post("/auth/login", json={"username": ACCOUNT, "password_hash": prehash(PASSWORD)})
    ok = r.status_code == 200
    token = ""
    if ok:
        body = r.json()
        token = body.get("access_token", "")
        ok = bool(token) and body.get("user", {}).get("id", 0) > 0
    check(ok, "POST /auth/login（1@qq.com / 123456）", "未拿到 token" if not ok else "拿到 access_token")
    if not token:
        return summary()
    auth = {"Authorization": f"Bearer {token}"}

    # 6. 伪造 token 应被拒
    r = client.get("/users/me", headers={"Authorization": "Bearer fake.token.value"})
    check(r.status_code == 401, "伪造 token 访问应 401", f"实际 {r.status_code}")

    # 7. 我的资料
    r = client.get("/users/me", headers=auth)
    me = r.json() if r.status_code == 200 else {}
    check(r.status_code == 200 and me.get("id", 0) > 0, "GET /users/me", f"nickname={me.get('nickname')}")
    # 字段必须齐全，缺一个 App 就会显示空白
    required = ["cities_count", "footprint_count", "days_count", "followers", "following", "likes_received",
                "default_public", "notif_enabled", "share_enabled"]
    missing = [k for k in required if k not in me]
    check(not missing, "GET /users/me 字段完整", f"缺少 {missing}" if missing else "")

    # 8. 更新资料
    r = client.put("/users/me", headers=auth, json={"signature": "自检签名 " + str(int(time.time()))})
    check(r.status_code == 200, "PUT /users/me")

    # 9. 媒体上传 + 去重
    img = png_bytes((14, 118, 110))
    files = {"file": ("verify.png", img, "image/png")}
    r = client.post("/api/sync/media", headers=auth, files=files)
    media = r.json() if r.status_code == 200 else {}
    check(r.status_code == 200 and media.get("url", "").startswith("/uploads/") and media.get("dedup") is False,
          "POST /api/sync/media（首次上传）", f"状态 {r.status_code}")
    if media.get("url"):
        r2 = client.get(media["url"])
        check(r2.status_code == 200 and r2.headers.get("content-type", "").startswith("image/png"),
              "媒体 URL 公网可读", f"{r2.status_code} {r2.headers.get('content-type')}")
        r = client.post("/api/sync/media", headers=auth, files=files)
        check(r.status_code == 200 and r.json().get("dedup") is True, "POST /api/sync/media（重复上传去重）")

    # 10. 伪装成图片的文本应 415
    r = client.post("/api/sync/media", headers=auth, files={"file": ("evil.png", b"<html>not an image</html>", "image/png")})
    check(r.status_code == 415, "伪装图片（HTML 内容）应 415", f"实际 {r.status_code}")

    # 11. 批量上传足迹
    now_ms = int(time.time() * 1000)
    items = [
        {"client_id": 990001, "updated_at": now_ms, "payload": {
            "city": "重庆", "name": "洪崖洞", "date": "2026-11-10", "note": "自检足迹 A",
            "photos": [media.get("url", "")] if media.get("url") else []}},
        {"client_id": 990002, "updated_at": now_ms, "payload": {
            "city": "成都", "name": "宽窄巷子", "date": "2026-11-11", "note": "自检足迹 B"}},
    ]
    r = client.put("/api/sync/footprints", headers=auth, json={"items": items, "deleted_client_ids": []})
    body = r.json() if r.status_code == 200 else {}
    check(r.status_code == 200 and body.get("created") == 2, "PUT /api/sync/footprints 写入 2 条", str(body))

    # 12. 旧 updated_at 不应覆盖
    r = client.put("/api/sync/footprints", headers=auth, json={
        "items": [{"client_id": 990001, "updated_at": now_ms - 1000, "payload": {"city": "旧", "note": "旧数据"}}],
        "deleted_client_ids": [],
    })
    body = r.json() if r.status_code == 200 else {}
    check(r.status_code == 200 and body.get("unchanged") == 1, "旧 updated_at 不覆盖新数据", str(body))

    # 13. 拉取足迹，中文不乱码
    r = client.get("/api/sync/footprints", headers=auth)
    data = r.json() if r.status_code == 200 else []
    ok = r.status_code == 200 and any(x["payload"].get("city") == "重庆" for x in data)
    check(ok, "GET /api/sync/footprints（中文完整）")

    # 14. 设置快照
    r = client.put("/api/sync/settings", headers=auth, json={"payload": {"theme": "liquid_glass", "notif": True}, "updated_at": now_ms})
    check(r.status_code == 200, "PUT /api/sync/settings")
    r = client.get("/api/sync/settings", headers=auth)
    check(r.status_code == 200 and r.json().get("payload", {}).get("theme") == "liquid_glass", "GET /api/sync/settings")

    # 15. 状态与配额
    r = client.get("/api/sync/status", headers=auth)
    st = r.json() if r.status_code == 200 else {}
    check(r.status_code == 200 and st.get("quota_bytes", 0) > 0 and "used_bytes" in st, "GET /api/sync/status")

    # 16. 攻略发布 / 列表 / 点赞 / 收藏
    r = client.post("/guides", headers=auth, json={
        "title": "自检攻略", "intro": "这是自检创建的内容", "city": "重庆", "days": 2, "cost": "800",
        "theme": "城市漫游", "tags": ["自检"], "tips": ["带上相机"],
        "cost_breakdown": [{"label": "住宿", "amount": "400", "total": False}],
        "itinerary": [{"day": 1, "title": "第一天", "spots": [{"name": "解放碑", "note": "夜景", "cost": "0", "seed": 1}]}],
    })
    gid = (r.json() or {}).get("id") if r.status_code == 200 else None
    check(r.status_code == 200 and isinstance(gid, int), "POST /guides", f"id={gid}")

    r = client.get("/guides?skip=0&limit=50")
    arr = r.json() if r.status_code == 200 else []
    g = next((x for x in arr if x.get("id") == gid), None) if isinstance(arr, list) else None
    ok = g is not None and all(k in g for k in ("author_name", "likes", "favored", "cover_seed", "itinerary"))
    check(ok, "GET /guides 返回字段对齐 App")

    if gid:
        r = client.post(f"/guides/{gid}/like", headers=auth)
        check(r.status_code == 200 and r.json()["data"]["liked"] is True, "POST /guides/{id}/like")
        r = client.post(f"/guides/{gid}/fav", headers=auth)
        check(r.status_code == 200 and r.json()["data"]["favored"] is True, "POST /guides/{id}/fav")

        # 17. 评论 + 楼中楼
        r = client.post("/comments", headers=auth, json={"guide_id": gid, "content": "自检评论"})
        cid = (r.json() or {}).get("id") if r.status_code == 200 else None
        check(r.status_code == 200 and isinstance(cid, int), "POST /comments", f"id={cid}")
        if cid:
            r = client.post("/comments", headers=auth, json={"guide_id": gid, "content": "自检回复", "parent_id": cid})
            check(r.status_code == 200, "POST /comments（楼中楼）")
        r = client.get(f"/guides/{gid}/comments")
        cs = r.json() if r.status_code == 200 else []
        ok = isinstance(cs, list) and any(c["id"] == cid and c.get("replies") for c in cs)
        check(ok, "GET /guides/{id}/comments（含回复）")

    # 18. 结构化足迹接口
    r = client.post("/routes", headers=auth, json={
        "title": "自检行程", "cities": ["重庆", "成都"], "date": "2026-11-10", "year": 2026,
        "note": "自检", "special": True, "special_reason": "第一次", "tags": ["自检"],
        "spots": [{"name": "洪崖洞", "note": "夜景", "cost": "0", "seed": 2}],
    })
    rid = (r.json() or {}).get("id") if r.status_code == 200 else None
    check(r.status_code == 200 and isinstance(rid, int), "POST /routes", f"id={rid}")
    r = client.get("/routes/me?year=0&special_only=false", headers=auth)
    check(r.status_code == 200 and isinstance(r.json(), list), "GET /routes/me")

    # 19. 服务端检索（未配置时应干净返回空列表）
    r = client.post("/api/search", json={"query": "重庆 洪崖洞", "limit": 5, "depth": "balanced"})
    ok = r.status_code == 200 and isinstance(r.json().get("hits"), list)
    check(ok, "POST /api/search（未配置时返回空列表）", str(r.json().get("provider")))

    # 20. 管理后台
    r = client.post("/admin/api/login", json={"username": ADMIN_USER, "password": ADMIN_PASSWORD})
    admin_token = (r.json() or {}).get("access_token") if r.status_code == 200 else None
    check(r.status_code == 200 and bool(admin_token), "POST /admin/api/login", f"状态 {r.status_code}")
    if admin_token:
        ah = {"Authorization": f"Bearer {admin_token}"}
        r = client.get("/admin/api/overview", headers=ah)
        check(r.status_code == 200 and "users" in r.json(), "GET /admin/api/overview")
        r = client.get("/admin/api/users?q=1%40qq.com", headers=ah)
        ok = r.status_code == 200 and r.json().get("total", 0) >= 1
        check(ok, "GET /admin/api/users（能搜到测试账号）")
        r = client.get("/admin/api/system", headers=ah)
        check(r.status_code == 200 and r.json().get("version"), "GET /admin/api/system")
        if gid:
            r = client.patch(f"/admin/api/guides/{gid}", headers=ah, json={"featured": True})
            check(r.status_code == 200, "PATCH /admin/api/guides/{id}（推荐）")
        r = client.get("/admin/api/audit?limit=10", headers=ah)
        check(r.status_code == 200 and isinstance(r.json().get("items"), list), "GET /admin/api/audit")
        r = client.get("/admin", headers={"Accept": "text/html"})
        check(r.status_code == 200 and "<title>" in r.text, "GET /admin（后台页面可打开）")
        # 无 token 访问后台接口应 401
        r = client.get("/admin/api/overview")
        check(r.status_code == 401, "未登录访问 /admin/api/overview 应 401")

    # 21. 清理自检数据
    if gid:
        client.delete(f"/guides/{gid}", headers=auth)
    if rid:
        client.delete(f"/routes/{rid}", headers=auth)
    for cid_ in (990001, 990002):
        client.delete(f"/api/sync/footprints/{cid_}", headers=auth)
    client.put("/api/sync/settings", headers=auth, json={"payload": {}, "updated_at": int(time.time() * 1000)})
    # 删掉自检上传的媒体（后台接口会同时删磁盘文件）
    if admin_token and media.get("url"):
        try:
            listing = client.get("/admin/api/media?limit=100", headers=admin_h).json()
            for item in listing.get("items", []):
                if item.get("url") == media["url"]:
                    client.delete(f"/admin/api/media/{item['id']}", headers=admin_h)
        except Exception:  # noqa: BLE001
            pass
    check(True, "清理自检数据（攻略 / 行程 / 足迹 / 媒体）")

    return summary()


def summary() -> int:
    passed = sum(1 for ok, _, _ in results if ok)
    total = len(results)
    print("\n" + "=" * 56)
    print(f"通过 {passed}/{total}")
    failed = [name for ok, name, _ in results if not ok]
    if failed:
        print("失败项：")
        for name in failed:
            print("  - " + name)
        return 1
    print("全部通过 ✅")
    return 0


if __name__ == "__main__":
    sys.exit(main())
