"""账号体系自检（用户名注册 / 验证地址 / 登录 / 账号搜索）。

用法（backend 目录）：
    python scripts\verify_auth_flows.py

使用临时库与临时存储，不影响真实数据；不访问外网。
"""
from __future__ import annotations

import hashlib
import os
import sqlite3
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import urlparse

TMP = Path(tempfile.mkdtemp(prefix="myzuji_auth_verify_"))
os.environ.update(
    {
        "ENV": "dev",
        "DATABASE_PATH": str(TMP / "verify.db"),
        "STORAGE_DIR": str(TMP / "storage"),
        "BACKUP_DIR": str(TMP / "backups"),
        "CONTENT_ENABLED": "false",
        "SEARCH_ONLINE_ENABLED": "false",
    }
)
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402

PASSWORD = "Verify123!"
HASH = hashlib.sha256(f"myzuji_salt_v2:{PASSWORD}".encode()).hexdigest()
results: list[tuple[bool, str, str]] = []


def check(ok: bool, name: str, detail: str = "") -> None:
    results.append((ok, name, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))


def captcha(client: TestClient) -> tuple[str, str]:
    r = client.get("/auth/captcha")
    cid = r.json()["captcha_id"]
    conn = sqlite3.connect(os.environ["DATABASE_PATH"])
    code = conn.execute("SELECT code FROM captchas WHERE id = ?", (cid,)).fetchone()[0]
    conn.close()
    return cid, code


def register(client: TestClient, account: str) -> None:
    cid, code = captcha(client)
    r = client.post("/auth/register_link", json={"username": account, "captcha_id": cid, "captcha_text": code})
    check("生成注册验证地址", r.status_code == 200 and "/auth/verify/" in r.json().get("verify_url", ""), r.text[:160])
    parsed = urlparse(r.json()["verify_url"])
    r = client.get(parsed.path + ("?" + parsed.query if parsed.query else ""))
    check("验证地址通过", r.status_code == 200 and "验证成功" in r.text, r.text[:120])
    cid, code = captcha(client)
    r = client.post(
        "/auth/register",
        json={"username": account, "password_hash": HASH, "captcha_id": cid, "captcha_text": code},
    )
    check("完成注册", r.status_code == 200 and r.json()["user"]["username"] == account, r.text[:200])


def main() -> int:
    suffix = str(int(time.time()))[-5:]
    account_a = f"autha{suffix}"
    account_b = f"authb{suffix}"
    with TestClient(app) as client:
        register(client, account_a)
        register(client, account_b)
        r = client.post("/auth/login", json={"username": account_a, "password_hash": HASH})
        check("用户名登录", r.status_code == 200 and r.json().get("access_token"), r.text[:200])
        check("返回资料含账号", r.json()["user"].get("username") == account_a)
        h = {"Authorization": f"Bearer {r.json()['access_token']}"}
        r = client.get("/users/search", params={"username": account_b}, headers=h)
        check("按账号搜索用户", r.status_code == 200 and r.json()["data"]["user"]["username"] == account_b, r.text[:200])
        r = client.get("/users/search", params={"username": account_a}, headers=h)
        check("搜索自己被拒绝", r.status_code == 400, r.text[:160])
        r = client.post("/auth/login", json={"username": "old@example.com", "password_hash": HASH})
        check("旧式标识被拒绝", r.status_code == 422, r.text[:160])
    ok = sum(1 for x in results if x[0])
    print(f"\n{ok}/{len(results)} passed")
    return 0 if ok == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
