"""数据库 / 媒体备份。

SQLite 用官方在线备份 API（sqlite3.Connection.backup），运行中也能得到一致快照，
不会出现「备份到一半数据库被写坏」。

用法：
    python scripts/backup.py                 # 只备份数据库
    python scripts/backup.py --with-media    # 数据库 + 上传文件打包
    python scripts/backup.py --keep 14       # 保留最近 14 份（默认 30）
建议加到 crontab：
    30 3 * * * cd /opt/myzuji/backend && .venv/bin/python scripts/backup.py --with-media >> logs/backup.log 2>&1
"""
from __future__ import annotations

import argparse
import shutil
import sqlite3
import sys
import tarfile
import time
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_DIR))

from app.config import settings  # noqa: E402


def backup_db(target: Path) -> int:
    target.parent.mkdir(parents=True, exist_ok=True)
    src = sqlite3.connect(str(settings.db_file))
    dst = sqlite3.connect(str(target))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return target.stat().st_size


def backup_media(target: Path) -> int:
    with tarfile.open(target, "w:gz") as tar:
        tar.add(settings.storage_path, arcname="storage")
    return target.stat().st_size


def prune(directory: Path, pattern: str, keep: int) -> None:
    files = sorted(directory.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in files[keep:]:
        try:
            old.unlink()
        except OSError:
            pass


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--with-media", action="store_true", help="同时打包 storage 目录")
    parser.add_argument("--keep", type=int, default=30, help="保留份数")
    args = parser.parse_args()

    if not settings.db_file.exists():
        print(f"数据库不存在：{settings.db_file}")
        return 1

    stamp = time.strftime("%Y%m%d-%H%M%S")
    out_dir = settings.backup_path
    db_file = out_dir / f"app-{stamp}.db"
    size = backup_db(db_file)
    print(f"数据库备份完成：{db_file}（{size / 1024:.1f} KB）")
    prune(out_dir, "app-*.db", args.keep)

    if args.with_media:
        media_file = out_dir / f"storage-{stamp}.tar.gz"
        msize = backup_media(media_file)
        print(f"媒体备份完成：{media_file}（{msize / 1024 / 1024:.1f} MB）")
        prune(out_dir, "storage-*.tar.gz", args.keep)

    print(f"备份目录：{out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
