"""内容抓取 + 站内私信 端到端自检。

用法（backend 目录下）：
    python scripts\verify_content_messages.py

脚本自己起一个临时 SQLite 库、临时存储目录、一个本地 fixture 站点
（127.0.0.1 随机端口），不会碰 data/app.db，也不会往公网发请求。
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="myzuji_verify_"))
os.environ.update(
    {
        "ENV": "dev",
        "DATABASE_PATH": str(TMP / "verify.db"),
        "STORAGE_DIR": str(TMP / "storage"),
        "BACKUP_DIR": str(TMP / "backups"),
        "CONTENT_ENABLED": "true",
        "CONTENT_WORKER_SECONDS": "1",
        "CONTENT_ALLOW_PRIVATE": "true",   # 只在本进程内放开 127.0.0.1
        "MESSAGE_RATE_PER_MINUTE": "120",
        "SEARCH_ENDPOINT": "",
    }
)

BACKEND = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND))

ARTICLE = (
    "<html><head><title>山城步道三日游 - 示例旅行网</title>"
    "<meta name='description' content='重庆山城步道三日行程，含路线、交通与预算。'>"
    "<meta property='article:published_time' content='2026-11-01T09:00:00Z'>"
    "</head><body><nav>首页 攻略 目的地 关于我们</nav>"
    "<article><h1>山城步道三日游</h1>"
    + "".join(
        f"<p>第{i}段：从较场口出发沿山城步道向上，沿途可以看到吊脚楼、老居民区和江景。"
        f"建议早上八点前出发避开人流，带一瓶水，穿防滑的鞋。这一段大约需要四十分钟，"
        f"途中会经过若干观景平台，适合拍照休息。</p>"
        for i in range(1, 7)
    )
    + "<img src='/img/step.jpg' alt='步道'>"
    "<p>预算参考：交通 20 元，餐饮 80 元，门票免费。晚上可以回到解放碑吃小面。</p>"
    "</article><footer>版权所有 示例旅行网 2026</footer></body></html>"
)

DUP = ARTICLE.replace("<article>", "<article><!-- 转载自示例旅行网 -->")
LIST = """<html><body><ul>
<li><a href="/a.html">山城步道三日游</a></li>
<li><a href="/b.html">洪崖洞夜景攻略</a></li>
</ul></body></html>"""
B = ARTICLE.replace("山城步道三日游", "洪崖洞夜景攻略").replace("/img/step.jpg", "/img/hongya.jpg")


class Fixture(BaseHTTPRequestHandler):
    def log_message(self, *args):  # 静音
        return

    def do_GET(self):  # noqa: N802
        path = self.path.split("?")[0]
        if path == "/robots.txt":
            body, ctype = "User-agent: *\nAllow: /\n", "text/plain"
        elif path == "/":
            body, ctype = LIST, "text/html; charset=utf-8"
        elif path == "/a.html":
            body, ctype = ARTICLE, "text/html; charset=utf-8"
        elif path == "/b.html":
            body, ctype = B, "text/html; charset=utf-8"
        elif path == "/dup.html":
            body, ctype = DUP, "text/html; charset=utf-8"
        else:
            self.send_response(404)
            self.end_headers()
            return
        raw = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


def main() -> int:
    results: list[tuple[str, bool, str]] = []

    def check(name: str, ok: bool, detail: str = "") -> None:
        results.append((name, bool(ok), detail))
        print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  ({detail})" if detail and not ok else ""))

    server = ThreadingHTTPServer(("127.0.0.1", 0), Fixture)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{server.server_address[1]}"

    from fastapi.testclient import TestClient
    from app.config import settings
    from app.db import tx
    from app.main import app
    from app.security import bcrypt_hash_prehashed, create_token, password_prehash

    with TestClient(app) as client:
        # ---------- 基础 ----------
        r = client.get("/ping")
        check("服务存活", r.status_code == 200 and r.json()["ok"], r.text[:120])

        account = settings.test_account_username
        r = client.post("/auth/login", json={
            "username": account,
            "password_hash": password_prehash(settings.test_account_password),
        })
        check("测试账号登录", r.status_code == 200 and r.json().get("access_token"), r.text[:160])
        me_token = r.json()["access_token"]
        me_id = int(r.json()["user"]["id"])
        h_me = {"Authorization": f"Bearer {me_token}"}

        # ---------- 造一个对端用户 ----------
        peer_account = "verifypeer"
        with tx() as conn:
            row = conn.execute("SELECT id FROM users WHERE username = ?", (peer_account,)).fetchone()
            if row is None:
                now = int(time.time())
                cur = conn.execute(
                    """INSERT INTO users (username, nickname, password_hash, status, token_version,
                           created_at, updated_at) VALUES (?,?,?,1,1,?,?)""",
                    (peer_account, "对端用户",
                     bcrypt_hash_prehashed(password_prehash("123456")), now, now),
                )
                peer_id = int(cur.lastrowid)
            else:
                peer_id = int(row["id"])
        peer_token = create_token(str(peer_id), "user", 3600, 1)[0]
        h_peer = {"Authorization": f"Bearer {peer_token}"}

        # ---------- 私信：互关限聊 ----------
        # 先验证未互关时后端会拦发送；再互关，后续消息流程才允许
        r = client.post("/api/messages/conversations", json={"peer_id": peer_id}, headers=h_me)
        check("打开会话", r.status_code == 200 and r.json()["data"]["peer"]["id"] == peer_id, r.text[:160])
        conv_id = r.json()["data"]["id"]
        r = client.post(f"/api/messages/conversations/{conv_id}/messages", headers=h_me,
                        json={"client_msg_id": "c-before", "type": "text", "body": "未互关不应发出"})
        check("未互关发送被后端拦截", r.status_code == 403, r.text[:200])
        client.post(f"/users/{peer_id}/follow", headers=h_me)
        client.post(f"/users/{me_id}/follow", headers=h_peer)
        r = client.get(f"/api/messages/conversations/{conv_id}", headers=h_me)
        check("互关后 can_send=true", r.json()["data"]["can_send"] is True, r.text[:160])

        r2 = client.post("/api/messages/conversations", json={"peer_id": peer_id}, headers=h_me)
        check("会话唯一（重复打开同一条）", r2.json()["data"]["id"] == conv_id, r2.text[:120])

        r = client.post(f"/api/messages/conversations/{conv_id}/messages", headers=h_me,
                        json={"client_msg_id": "c-1", "type": "text", "body": "你好，这是一条测试消息"})
        check("发送消息", r.status_code == 200 and r.json()["data"]["message"]["seq"] == 1, r.text[:200])
        msg1 = r.json()["data"]["message"]

        r = client.post(f"/api/messages/conversations/{conv_id}/messages", headers=h_me,
                        json={"client_msg_id": "c-1", "type": "text", "body": "你好，这是一条测试消息"})
        dup = r.json()["data"]
        check("client_msg_id 幂等", dup["duplicate"] is True and dup["message"]["id"] == msg1["id"],
              r.text[:200])

        r = client.get(f"/api/messages/conversations/{conv_id}/messages", headers=h_me)
        check("拉取消息", r.status_code == 200 and len(r.json()["data"]["items"]) == 1, r.text[:200])

        r = client.get("/api/messages/conversations", headers=h_peer)
        unread = r.json()["data"]["total_unread"]
        check("对端未读=1", unread == 1, str(unread))

        r = client.post(f"/api/messages/conversations/{conv_id}/read", headers=h_peer, json={"seq": 1})
        check("已读水位", r.status_code == 200 and r.json()["data"]["unread"] == 0, r.text[:200])
        r = client.get(f"/api/messages/conversations/{conv_id}", headers=h_me)
        check("发送方看到对方已读", r.json()["data"]["peer_last_read_seq"] == 1, r.text[:200])

        r = client.post(f"/api/messages/conversations/{conv_id}/messages", headers=h_me,
                        json={"client_msg_id": "c-2", "type": "text", "body": "这条要被撤回"})
        msg2 = r.json()["data"]["message"]
        r = client.post(f"/api/messages/recall/{msg2['id']}", headers=h_me)
        check("撤回消息", r.status_code == 200 and r.json()["data"]["status"] == 0, r.text[:200])
        r = client.get(f"/api/messages/conversations/{conv_id}/messages", headers=h_peer)
        recalled = [m for m in r.json()["data"]["items"] if m["id"] == msg2["id"]][0]
        check("撤回后对端看到空正文", recalled["recalled"] is True and recalled["body"] == "", json.dumps(recalled)[:200])

        r = client.post(f"/api/messages/users/{me_id}/block", headers=h_peer, json={"blocked": True})
        check("拉黑", r.status_code == 200 and r.json()["data"]["blocked"], r.text[:160])
        r = client.post(f"/api/messages/conversations/{conv_id}/messages", headers=h_me,
                        json={"client_msg_id": "c-3", "type": "text", "body": "被拉黑还能发吗"})
        check("拉黑后禁止发送", r.status_code == 403, r.text[:160])
        r = client.post(f"/api/messages/users/{me_id}/block", headers=h_peer, json={"blocked": False})
        check("取消拉黑", r.status_code == 200 and not r.json()["data"]["blocked"], r.text[:160])

        r = client.post("/api/messages/conversations", json={"peer_id": me_id}, headers=h_me)
        check("不能和自己建会话", r.status_code == 400, r.text[:160])

        r = client.get("/api/messages/unread", headers=h_me)
        check("总未读接口", r.status_code == 200 and "total" in r.json()["data"], r.text[:160])

        # SSE：只读第一条（retry 行），验证协议与鉴权
        with client.stream("GET", "/api/messages/stream?since_id=0", headers=h_me) as stream:
            first = next(stream.iter_lines())
        check("SSE 实时流", stream.status_code == 200 and first.startswith("retry:"), str(first)[:120])

        # ---------- 内容抓取 ----------
        r = client.post("/admin/api/login", json={"username": "admin", "password": "admin-dev-2026"})
        check("后台登录", r.status_code == 200 and r.json().get("access_token"), r.text[:160])
        h_admin = {"Authorization": f"Bearer {r.json()['access_token']}"}

        r = client.post("/admin/api/content/sources", headers=h_admin, json={
            "name": "自检站点", "kind": "html", "list_url": base + "/",
            "host": "127.0.0.1", "interval_minutes": 1440, "max_items": 3,
        })
        check("新建内容源", r.status_code == 200, r.text[:200])
        source_id = r.json()["data"]["id"]

        r = client.post(f"/admin/api/content/sources/{source_id}/run", headers=h_admin)
        check("内容源任务入队", r.status_code == 200, r.text[:160])

        deadline = time.time() + 30
        job = None
        while time.time() < deadline:
            rows = client.get("/admin/api/content/jobs", headers=h_admin).json()["data"]
            job = next((j for j in rows if j["source_id"] == source_id), None)
            if job and job["status"] in {"done", "failed"}:
                break
            time.sleep(0.5)
        check("内容源抓取完成", bool(job) and job["status"] == "done",
              json.dumps(job, ensure_ascii=False)[:240] if job else "no job")

        r = client.get("/api/content/feed?limit=10", headers=h_me)
        feed = r.json()["data"]
        check("内容入库≥2 条", len(feed["items"]) >= 2, json.dumps(feed, ensure_ascii=False)[:200])
        item = feed["items"][0]
        r = client.get(f"/api/content/items/{item['id']}", headers=h_me)
        full = r.json()["data"]
        check("详情含正文与段落", full["body_text"] and full["blocks"], json.dumps(full)[:160])
        check("正文已清洗掉导航/版权", "版权所有" not in full["body_text"] and "首页 攻略" not in full["body_text"],
              full["body_text"][:80])

        r = client.get(f"/api/content/feed?since_id={item['id']}&limit=10", headers=h_me)
        check("Feed 增量游标", r.status_code == 200 and all(i["id"] > item["id"] for i in r.json()["data"]["items"]),
              r.text[:160])

        # 单页抓取 + 正文指纹去重
        r = client.post("/admin/api/content/fetch-url", headers=h_admin, json={"url": base + "/dup.html"})
        check("单页抓取入队", r.status_code == 200, r.text[:160])
        job_id = r.json()["data"]["job_id"]
        deadline = time.time() + 20
        while time.time() < deadline:
            rows = client.get("/admin/api/content/jobs", headers=h_admin).json()["data"]
            j = next((x for x in rows if x["id"] == job_id), None)
            if j and j["status"] in {"done", "failed"}:
                break
            time.sleep(0.5)
        check("正文指纹去重（转载不入库）", j and j["status"] == "done" and j["created_items"] == 0,
              json.dumps(j, ensure_ascii=False)[:200])

        # 生产口径下（禁止内网）必须 400 拦掉
        old_allow = settings.content_allow_private
        settings.content_allow_private = False
        try:
            r = client.post("/admin/api/content/fetch-url", headers=h_admin,
                            json={"url": "http://169.254.169.254/latest/meta-data/"})
        finally:
            settings.content_allow_private = old_allow
        check("SSRF 拦截云元数据地址", r.status_code == 400, r.text[:160])

        r = client.get("/admin/api/content/overview", headers=h_admin)
        check("内容总览", r.status_code == 200 and r.json()["data"]["items"] >= 2, r.text[:160])

        # 清掉开发环境里的自动调度，避免影响下一次运行
        client.delete(f"/admin/api/content/sources/{source_id}", headers=h_admin)

    server.shutdown()

    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n=== {passed}/{len(results)} 通过 ===")
    failed = [f"{n}: {d}" for n, ok, d in results if not ok]
    if failed:
        for line in failed:
            print("未通过 ->", line)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
