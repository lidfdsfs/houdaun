"""联网搜索 + 后台建号 自检（离线、临时库）。

用法（backend 目录）：
    python scripts\verify_search_admin.py

搜索部分 monkeypatch 了搜索源与正文抓取，不访问公网；只验证：
强度分级、结果结构、会话读取、关闭即清除、过期清理、后台统计/清空、
Bing 结果解析、后台创建账号并直接登录、重复账号拦截。
"""
from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="myzuji_search_verify_"))
os.environ.update(
    {
        "ENV": "dev",
        "DATABASE_PATH": str(TMP / "verify.db"),
        "STORAGE_DIR": str(TMP / "storage"),
        "BACKUP_DIR": str(TMP / "backups"),
        "SEARCH_ONLINE_ENABLED": "true",
        "SEARCH_PROVIDER": "bing",
        "SEARCH_SESSION_TTL_SECONDS": "600",
        "SEARCH_CLEANUP_SECONDS": "3600",
        "CONTENT_ENABLED": "false",
        "MESSAGE_RATE_PER_MINUTE": "120",
    }
)

BACKEND = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND))

BING_FIXTURE = """
<ul>
<li class="b_algo"><h2><a href="https://www.zhihu.com/question/1">重庆怎么玩</a></h2>
<div class="b_caption"><p>三天两晚的路线与预算。</p></div></li>
<li class="b_algo"><h2><a href="https://www.bing.com/ck/a?u=abc">跳转壳</a></h2>
<p>不应出现</p></li>
<li class="b_algo"><h2><a href="https://mafengwo.cn/gonglve/2">重庆攻略</a></h2>
<p>景点、美食与交通。</p></li>
</ul>
"""


def main() -> int:
    results: list[tuple[str, bool, str]] = []

    def check(name: str, ok: bool, detail: str = "") -> None:
        results.append((name, bool(ok), detail))
        print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  ({detail})" if detail and not ok else ""))

    from fastapi.testclient import TestClient

    from app import search_online
    from app.config import settings
    from app.db import db, tx
    from app.main import app
    from app.security import password_prehash

    # ---------- Bing 解析（离线 fixture） ----------
    parsed = search_online.parse_bing_html(BING_FIXTURE, 10)
    check("Bing 解析出 2 条（过滤跳转壳）", len(parsed) == 2, str(parsed))
    check("Bing 标题/摘要/站点", parsed[0]["title"] == "重庆怎么玩" and "三天" in parsed[0]["snippet"]
          and parsed[0]["site"] == "zhihu.com", str(parsed[0]))

    # ---------- 假搜索源 ----------
    fake_hits = [
        {"title": f"重庆攻略 {i}", "url": f"https://example.com/p/{i}", "snippet": f"摘要 {i}",
         "site": "example.com", "rank": i}
        for i in range(1, 7)
    ]
    fake_hits[1]["url"] = "https://www.mafengwo.cn/gonglve/3"
    fake_hits[1]["site"] = "mafengwo.cn"

    def fake_search(query: str, limit: int):
        return "bing", fake_hits[:limit]

    def fake_excerpt(url: str, limit: int = 800) -> str:
        if any(k in url for k in ("p/1", "mafengwo", "p/3", "p/4")):
            return "这里是清洗后的正文摘要：山城步道、洪崖洞、解放碑，三天两晚路线与预算。"[:limit]
        return ""

    search_online.search_web = fake_search
    search_online.fetch_excerpt = fake_excerpt

    with TestClient(app) as client:
        # ---------- 后台建号 ----------
        admin = client.post("/admin/api/login", json={"username": "admin", "password": "admin-dev-2026"})
        check("后台登录", admin.status_code == 200, admin.text[:160])
        h_admin = {"Authorization": f"Bearer {admin.json()['access_token']}"}

        new_account = f"made{int(time.time())}"
        r = client.post("/admin/api/users", headers=h_admin,
                        json={"username": new_account, "nickname": "后台新建", "password": "abc12345"})
        check("后台创建账号", r.status_code == 200 and r.json()["data"]["username"] == new_account, r.text[:200])
        new_id = r.json()["data"]["id"]

        r = client.post("/admin/api/users", headers=h_admin,
                        json={"username": new_account, "nickname": "重复", "password": "abc12345"})
        check("重复账号被拦截", r.status_code == 409, r.text[:160])

        r = client.post("/admin/api/users", headers=h_admin,
                        json={"username": f"short{int(time.time())}", "password": "123"})
        check("过短密码被拦截", r.status_code == 422, r.text[:160])

        login = client.post("/auth/login", json={
            "username": new_account,
            "password_hash": password_prehash("abc12345"),
        })
        check("新账号可直接登录", login.status_code == 200 and login.json().get("access_token"), login.text[:200])
        new_token = login.json()["access_token"]
        h_new = {"Authorization": f"Bearer {new_token}"}

        # ---------- 联网搜索 ----------
        r = client.post("/api/search/online", headers=h_new,
                        json={"query": "重庆 旅游 攻略", "strength": "balanced"})
        check("联网搜索返回结果", r.status_code == 200 and r.json()["data"]["item_count"] >= 5, r.text[:240])
        data = r.json()["data"]
        sid = data["session_id"]
        check("强度=balanced 抓 4 篇正文", sum(1 for x in data["items"] if x["fetched"]) == 4,
              str([x["fetched"] for x in data["items"]]))
        check("结果含清洗摘要", any("山城步道" in (x["excerpt"] or "") for x in data["items"]), str(data["items"])[:200])
        check("结果字段完整", all(k in data["items"][0] for k in
                                  ("title", "url", "site", "snippet", "excerpt", "score", "tier")),
              str(data["items"][0]))

        r = client.get(f"/api/search/sessions/{sid}", headers=h_new)
        check("会话可读取", r.status_code == 200 and r.json()["data"]["session_id"] == sid, r.text[:160])
        r = client.post(f"/api/search/sessions/{sid}/close", headers=h_new)
        check("关闭即清除", r.status_code == 200 and r.json()["data"]["cleared"], r.text[:160])
        r = client.get(f"/api/search/sessions/{sid}", headers=h_new)
        check("清除后读取 404", r.status_code == 404, r.text[:160])
        with db() as conn:
            check("数据库无残留", conn.execute("SELECT COUNT(*) c FROM search_sessions").fetchone()["c"] == 0)

        # 过期清理：手动把 expires_at 改到过去，再跑清理
        r = client.post("/api/search/online", headers=h_new, json={"query": "过期测试", "strength": "fast"})
        sid2 = r.json()["data"]["session_id"]
        with tx() as conn:
            conn.execute("UPDATE search_sessions SET expires_at = ? WHERE id = ?", (int(time.time()) - 1, sid2))
        deleted = search_online.purge_expired()
        check("过期会话被清理", deleted == 1, str(deleted))
        r = client.get(f"/api/search/sessions/{sid2}", headers=h_new)
        check("过期后读取 404", r.status_code == 404, r.text[:160])

        # 非法强度
        r = client.post("/api/search/online", headers=h_new, json={"query": "x", "strength": "huge"})
        check("非法强度 422", r.status_code == 422, r.text[:160])

        # 强度分级：fast 不抓正文
        r = client.post("/api/search/online", headers=h_new, json={"query": "fast 测试", "strength": "fast"})
        check("fast 不抓正文", r.status_code == 200 and r.json()["data"]["result_count"] == 5
              and not any(x["fetched"] for x in r.json()["data"]["items"]), r.text[:200])

        # 全部清除 + 后台统计
        r = client.delete("/api/search/sessions", headers=h_new)
        check("一键清除全部会话", r.status_code == 200 and r.json()["data"]["deleted"] >= 1, r.text[:160])
        r = client.get("/admin/api/search/overview", headers=h_admin)
        check("后台搜索概况", r.status_code == 200 and r.json()["data"]["active_sessions"] == 0, r.text[:160])
        r = client.post("/admin/api/search/purge", headers=h_admin)
        check("后台一键清空", r.status_code == 200, r.text[:160])

        # 搜索未登录要 401
        r = client.post("/api/search/online", json={"query": "x", "strength": "fast"})
        check("未登录搜索被拒", r.status_code == 401, r.text[:160])

    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n=== {passed}/{len(results)} 通过 ===")
    failed = [f"{n}: {d}" for n, ok, d in results if not ok]
    for line in failed:
        print("未通过 ->", line)
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
