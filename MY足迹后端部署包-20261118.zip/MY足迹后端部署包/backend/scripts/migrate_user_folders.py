"""把旧的媒体布局迁移到「每个用户一个文件夹」。

旧：storage/media/{uid}/{sha2}/{sha}.ext、storage/avatars/{uid}/...、storage/covers/...
新：storage/users/{uid}/media|avatar|cover/{sha2}/{sha}.ext

默认只预览（dry-run），加 --apply 才真正移动文件并改写库里的 URL/rel_path。
脚本可重复执行：已经在新布局里的行会跳过。
"""
from __future__ import annotations

import argparse
import os
import shutil
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.config import settings  # noqa: E402

MOVES = [
    ("media", "media"),
    ("avatars", "avatar"),
    ("covers", "cover"),
]


def migrate_rel(storage: Path, rel: str, dry: bool) -> tuple[str, str] | None:
    """把 media/{uid}/ab/xx.ext 变成 users/{uid}/media/ab/xx.ext。"""
    parts = rel.split("/")
    if len(parts) < 3:
        return None
    legacy_dir = parts[0]
    mapping = {old: new for old, new in MOVES}
    if legacy_dir not in mapping:
        return None
    user_id = parts[1]
    new_rel = "/".join(["users", user_id, mapping[legacy_dir]] + parts[2:])
    src = storage / rel
    dst = storage / new_rel
    if not src.exists():
        return None
    if not dry:
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            src.unlink()
        else:
            shutil.move(str(src), str(dst))
    return new_rel, f"/uploads/{new_rel}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true", help="真正执行（默认只预览）")
    args = parser.parse_args()
    dry = not args.apply

    storage = settings.storage_path
    db_file = settings.db_file
    conn = sqlite3.connect(str(db_file))
    conn.row_factory = sqlite3.Row
    changed = 0

    rows = conn.execute("SELECT id, rel_path, url FROM media WHERE rel_path NOT LIKE 'users/%'").fetchall()
    for row in rows:
        moved = migrate_rel(storage, row["rel_path"], dry)
        if not moved:
            print(f"[skip] media#{row['id']} {row['rel_path']}（文件不存在或已迁移）")
            continue
        new_rel, new_url = moved
        print(f"[{'preview' if dry else 'move'}] media#{row['id']} {row['rel_path']} -> {new_rel}")
        if not dry:
            conn.execute("UPDATE media SET rel_path = ?, url = ? WHERE id = ?", (new_rel, new_url, row["id"]))
        changed += 1

    # 头像 / 攻略封面：URL 存在 users 表与 guides 表里
    for table, column in (("users", "avatar"), ("guides", "cover_image")):
        for row in conn.execute(f"SELECT id, {column} AS v FROM {table} WHERE {column} LIKE '/uploads/%'").fetchall():
            url = row["v"]
            if "/uploads/users/" in url:
                continue
            rel = url[len("/uploads/"):]
            moved = migrate_rel(storage, rel, dry)
            if not moved:
                continue
            print(f"[{'preview' if dry else 'move'}] {table}#{row['id']} {url} -> {moved[1]}")
            if not dry:
                conn.execute(f"UPDATE {table} SET {column} = ? WHERE id = ?", (moved[1], row["id"]))
            changed += 1

    if not dry:
        conn.commit()
        for legacy, _new in MOVES:
            base = storage / legacy
            if base.exists():
                for dirpath, dirnames, filenames in os.walk(base, topdown=False):
                    if not dirnames and not filenames:
                        os.rmdir(dirpath)
    conn.close()
    print(f"完成，{'待迁移' if dry else '已迁移'} {changed} 项；加 --apply 才真正执行")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
