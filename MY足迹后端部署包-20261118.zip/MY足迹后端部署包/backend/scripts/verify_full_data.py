"""全量数据链路自检（需要服务已启动）。

覆盖：
  1. 测试账号登录
  2. PUT /api/sync/collections/music  -> 通用分区
  3. POST /api/sync/archive          -> 全量档案（7 个分区）
  4. POST /api/sync/vault            -> 隐私空间密文块
  5. 后台登录 + /admin/api/users/{id}/data、/collections、/section、/vault、/files、/archive、/export

用法：
  python scripts/verify_full_data.py                       # 打 127.0.0.1:8000
  python scripts/verify_full_data.py --base http://192.168.0.142:8000
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time

import httpx

SALT = "myzuji_salt_v2"
ACCOUNT = "user1"
PASSWORD = "123456"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="http://127.0.0.1:8000")
    parser.add_argument("--admin", default="admin")
    parser.add_argument("--admin-password", default="admin-dev-2026")
    args = parser.parse_args()

    ok = 0
    bad = 0

    def check(name: str, cond: bool, extra: str = "") -> None:
        nonlocal ok, bad
        if cond:
            ok += 1
            print(f"[ok]   {name} {extra}")
        else:
            bad += 1
            print(f"[FAIL] {name} {extra}")

    c = httpx.Client(base_url=args.base, timeout=30)
    check("ping", c.get("/ping").status_code == 200)

    digest = hashlib.sha256(f"{SALT}:{PASSWORD}".encode()).hexdigest()
    r = c.post("/auth/login", json={"username": ACCOUNT, "password_hash": digest})
    check("login", r.status_code == 200, f"HTTP {r.status_code}")
    if r.status_code != 200:
        return 1
    token = r.json()["access_token"]
    H = {"Authorization": f"Bearer {token}"}
    uid = c.get("/auth/me", headers=H).json().get("id", 1)

    now = int(time.time() * 1000)
    music = {
        "items": [
            {"client_id": "verify-s1", "updated_at": now,
             "payload": {"title": "漠河舞厅", "artist": "柳爽", "duration": 312}},
            {"client_id": "verify-s2", "updated_at": now,
             "payload": {"title": "这世界那么多人", "artist": "莫文蔚"}},
        ],
        "deleted_client_ids": [],
    }
    r = c.put("/api/sync/collections/music", headers=H, json=music)
    check("PUT collections/music", r.status_code == 200, str(r.json() if r.status_code == 200 else r.text[:120]))

    sections = {
        "footprints": [{"id": 9001, "city": "重庆", "name": "洪崖洞", "note": "自检足迹", "date": "2026-11-17",
                        "x": 106.58, "y": 29.56}],
        "routes": [{"id": 9101, "title": "川渝四日", "year": 2026, "cities": ["重庆", "成都"]}],
        "plans": [{"id": 9201, "name": "周末去武隆", "destination": "武隆", "days": 2}],
        "music": {"favorites": [{"id": 1, "title": "漠河舞厅"}], "recent": [1], "play_counts": {"1": 3}},
        "comments": [{"id": 9301, "guide_id": 1, "content": "自检评论"}],
        "vault": {"configured": True, "items": [{"id": "v-verify", "name": "IMG_0001.jpg", "kind": "image", "size": 2048}]},
        "settings": {"theme": "dark"},
    }
    doc = {"schema_version": 2, "exported_at": now, "app": "MY足迹", "sections": sections}
    r = c.post("/api/sync/archive", headers=H, content=json.dumps(doc, ensure_ascii=False).encode())
    check("POST archive", r.status_code == 200, str(r.json() if r.status_code == 200 else r.text[:120]))
    meta = c.get("/api/sync/archive", headers=H).json()
    check("GET archive meta", meta.get("available") is True, f"sections={meta.get('sections')}")

    blob = os.urandom(64)
    r = c.post("/api/sync/vault", headers=H,
               files={"file": ("v-verify.bin", blob, "application/octet-stream")},
               data={"item_id": "v-verify", "name": "IMG_0001.jpg", "kind": "image"})
    check("POST vault", r.status_code == 200, str(r.json() if r.status_code == 200 else r.text[:120]))

    r = c.post("/admin/api/login", json={"username": args.admin, "password": args.admin_password})
    check("admin login", r.status_code == 200, f"HTTP {r.status_code}")
    if r.status_code != 200:
        return 1
    A = {"Authorization": f"Bearer {r.json()['access_token']}"}

    d = c.get(f"/admin/api/users/{uid}/data", headers=A)
    check("admin users/{id}/data", d.status_code == 200, str(d.json().get("counts") if d.status_code == 200 else ""))
    check("admin collections", c.get(f"/admin/api/users/{uid}/collections/music", headers=A).json().get("total", 0) >= 2)
    check("admin section footprints", c.get(f"/admin/api/users/{uid}/section/footprints", headers=A).json().get("available") is True)
    v = c.get(f"/admin/api/users/{uid}/vault", headers=A).json()
    check("admin vault", v.get("encrypted") is True and v.get("total", 0) >= 1)
    f = c.get(f"/admin/api/users/{uid}/files", headers=A).json()
    paths = [x["path"] for x in f.get("files", [])]
    check("admin files", any(p.startswith("data/") for p in paths) and any(p.startswith("vault/") for p in paths),
          f"{len(paths)} 个文件")
    check("admin archive", c.get(f"/admin/api/users/{uid}/archive", headers=A).status_code == 200)
    r = c.get(f"/admin/api/users/{uid}/export", headers=A)
    check("admin export zip", r.status_code == 200 and r.content[:2] == b"PK", f"{len(r.content)} 字节")

    print(f"\n通过 {ok} 项，失败 {bad} 项")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
