#!/usr/bin/env bash
# 开发/测试环境一键启动；生产请用 systemd 或 Docker。
set -euo pipefail
cd "$(dirname "$0")"

PYTHON="${PYTHON:-python3}"
if [ ! -d ".venv" ]; then
  "$PYTHON" -m venv .venv
fi
. .venv/bin/activate

if ! python -c "import fastapi, uvicorn" >/dev/null 2>&1; then
  pip install -r requirements.txt
fi

exec uvicorn app.main:app \
  --host "${HOST:-0.0.0.0}" \
  --port "${1:-8000}" \
  --proxy-headers
