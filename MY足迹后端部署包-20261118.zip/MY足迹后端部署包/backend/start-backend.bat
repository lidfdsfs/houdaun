@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"
set "PORT=%~1"
if "%PORT%"=="" set "PORT=8000"
title MY足迹 后端服务 · 端口 %PORT%

echo ==========================================================
echo   MY足迹 后端 · 一键启动
echo   目录：%CD%
echo ==========================================================
echo.

rem ---------- 1. 找可用的 Python ----------
set "PYEXE="
if exist ".venv\Scripts\python.exe" set "PYEXE=%CD%\.venv\Scripts\python.exe"

if not defined PYEXE (
  where py >nul 2>nul
  if !errorlevel! equ 0 (
    for /f "delims=" %%i in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
  )
)
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PYEXE (
  for /f "delims=" %%i in ('dir /b /s "C:\Program Files\Python3*\python.exe" 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
)
if not defined PYEXE (
  for /f "delims=" %%i in ('where python 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
)
if not defined PYEXE (
  echo [错误] 没找到 Python。请先装 Python 3.10 或更高版本，安装时勾选 "Add python.exe to PATH"。
  echo         https://www.python.org/downloads/
  echo.
  pause
  exit /b 1
)
echo Python    : !PYEXE!

rem ---------- 2. 服务是否已经在跑 ----------
set "BODY="
for /f "delims=" %%r in ('curl -s -m 2 "http://127.0.0.1:%PORT%/ping" 2^>nul') do set "BODY=%%r"
echo !BODY! | findstr /i "service" >nul
if not errorlevel 1 (
  echo 状态      : 已在运行，无需重复启动
  echo 后台      : http://127.0.0.1:%PORT%/admin
  if not defined MYZUJI_NO_BROWSER start http://127.0.0.1:%PORT%/admin
  echo.
  echo 如需重启：先关掉原来的服务窗口，再运行本脚本。
  ping -n 4 127.0.0.1 >nul
  exit /b 0
)

rem ---------- 3. 依赖 ----------
"!PYEXE!" -c "import fastapi, uvicorn, jwt, bcrypt, PIL, multipart, pydantic_settings" >nul 2>nul
if not errorlevel 1 goto :deps_ok

echo 依赖      : 缺失，正在准备（只做一次，约 1-2 分钟）
if not exist ".venv\Scripts\python.exe" (
  echo            创建虚拟环境 .venv ...
  "!PYEXE!" -m venv .venv
  if errorlevel 1 goto :deps_fail
)
set "PYEXE=%CD%\.venv\Scripts\python.exe"
"!PYEXE!" -m pip install --upgrade pip
"!PYEXE!" -m pip install -r requirements.txt
if errorlevel 1 goto :deps_fail
goto :deps_ok

:deps_fail
echo.
echo [错误] 依赖安装失败。请检查网络，或手动执行：
echo         "!PYEXE!" -m pip install -r requirements.txt
echo.
pause
exit /b 1

:deps_ok
echo 依赖      : OK

rem ---------- 4. 端口占用检查 ----------
netstat -ano | findstr /c:":%PORT% " | findstr /i "LISTENING" >nul
if not errorlevel 1 (
  echo.
  echo [错误] 端口 %PORT% 已被别的程序占用：
  netstat -ano | findstr /c:":%PORT% " | findstr /i "LISTENING"
  echo        换个端口启动：start-backend.bat 8001
  echo.
  pause
  exit /b 1
)

rem ---------- 5. 打印访问地址 ----------
echo 端口      : %PORT%
echo.
echo 本机：
echo   后台  http://127.0.0.1:%PORT%/admin
echo   接口  http://127.0.0.1:%PORT%/docs
echo   自检  http://127.0.0.1:%PORT%/ping
echo.
echo 手机（同一 Wi-Fi / 同一网段）：
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
  set "ip=%%a"
  set "ip=!ip: =!"
  if not "!ip:~0,8!"=="169.254." echo   http://!ip!:%PORT%/admin
)
echo.
echo 账号：App user1 / 123456     后台 admin / admin-dev-2026
echo 停止：在本窗口按 Ctrl+C，或直接关闭窗口
echo.

rem 5 秒后自动打开后台（设置 MYZUJI_NO_BROWSER 可跳过）
if not defined MYZUJI_NO_BROWSER start /b cmd /c "ping -n 6 127.0.0.1 >nul & start http://127.0.0.1:%PORT%/admin"

"!PYEXE!" -m uvicorn app.main:app --host 0.0.0.0 --port %PORT% --log-level info

echo.
echo 服务已退出（日志见上方输出）。
pause
